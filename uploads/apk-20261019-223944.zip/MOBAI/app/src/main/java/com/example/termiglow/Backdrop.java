package com.example.termiglow;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Soft pastel gradient with a few blurred color blobs, so frosted glass has something to blur. */
final class Backdrop extends Drawable {
    private final Paint base = new Paint();
    private final Paint[] blobs = new Paint[3];
    private final float[][] spec = {
            {0.12f, 0.10f, 0.62f}, {0.92f, 0.38f, 0.55f}, {0.28f, 0.96f, 0.66f}
    };
    private final int[] colors = {0xFFA9C7FF, 0xFFFFC6DE, 0xFFB8F0DA};

    Backdrop() {
        for (int i = 0; i < blobs.length; i++) blobs[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        float w = b.width(), h = b.height(), m = Math.max(w, h);
        base.setShader(new LinearGradient(0, 0, 0, h, 0xFFF8F9FC, 0xFFEEF1F7, Shader.TileMode.CLAMP));
        for (int i = 0; i < blobs.length; i++) {
            int c = colors[i];
            blobs[i].setShader(new RadialGradient(spec[i][0] * w, spec[i][1] * h, Math.max(1f, spec[i][2] * m),
                    (c & 0x00FFFFFF) | 0x80000000, c & 0x00FFFFFF, Shader.TileMode.CLAMP));
        }
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        canvas.drawRect(b, base);
        for (Paint p : blobs) canvas.drawRect(b, p);
    }

    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(ColorFilter colorFilter) { }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
