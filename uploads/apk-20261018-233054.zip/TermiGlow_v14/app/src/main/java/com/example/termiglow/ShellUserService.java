package com.example.termiglow;

import android.os.RemoteException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku UserService that stages the self-extracting main.sh as raw bytes,
 * then runs it under a native pseudo-terminal. Output is sent to the activity
 * as soon as it arrives, and user input is forwarded to the same PTY.
 */
public final class ShellUserService extends IShellUserService.Stub {
    private static final int MAX_SCRIPT_BYTES = 8 * 1024 * 1024;
    private static final int CHUNK_CHARS = 2048;

    private final Object stagingLock = new Object();
    private final Object processLock = new Object();

    private File stagedScriptFile;
    private OutputStream stagedScriptOutput;
    private int expectedScriptBytes;
    private int writtenScriptBytes;

    private volatile long activePtyHandle;

    public ShellUserService() {
        // Required no-argument constructor for Shizuku UserService.
    }

    @Override
    public void beginScript(int totalBytes) throws RemoteException {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
            if (totalBytes <= 0 || totalBytes > MAX_SCRIPT_BYTES) {
                throw new RemoteException("Invalid built-in script size: " + totalBytes);
            }
            File tempDirectory = new File("/data/local/tmp");
            if (!tempDirectory.isDirectory() || !tempDirectory.canWrite()) {
                throw new RemoteException("Shizuku UserService cannot write /data/local/tmp");
            }
            try {
                stagedScriptFile = File.createTempFile("termiglow-main-", ".sh", tempDirectory);
                stagedScriptOutput = new FileOutputStream(stagedScriptFile);
                expectedScriptBytes = totalBytes;
                writtenScriptBytes = 0;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to stage built-in script: " + e.getMessage());
            }
        }
    }

    @Override
    public void writeScriptChunk(byte[] chunk) throws RemoteException {
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script; beginScript must be called first");
            }
            if (chunk == null || writtenScriptBytes + chunk.length > expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Invalid script chunk length");
            }
            try {
                stagedScriptOutput.write(chunk);
                writtenScriptBytes += chunk.length;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to write script chunk: " + e.getMessage());
            }
        }
    }

    @Override
    public void startScript(String input, IShellOutputCallback callback) throws RemoteException {
        if (callback == null) throw new RemoteException("Missing output callback");

        final File scriptFile;
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script to execute");
            }
            try {
                stagedScriptOutput.close();
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to close staged script: " + e.getMessage());
            }
            stagedScriptOutput = null;
            if (writtenScriptBytes != expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Incomplete script transfer: expected "
                        + expectedScriptBytes + " bytes, received " + writtenScriptBytes);
            }
            scriptFile = stagedScriptFile;
            stagedScriptFile = null;
            expectedScriptBytes = 0;
            writtenScriptBytes = 0;
        }

        synchronized (processLock) {
            if (activePtyHandle != 0L) {
                scriptFile.delete();
                throw new RemoteException("A script is already running");
            }
        }

        String argument = input == null ? "" : input;
        String command = "exec /system/bin/sh " + shellQuote(scriptFile.getAbsolutePath())
                + " " + shellQuote(argument);
        final long handle;
        try {
            // PtyBridge creates a real /dev/ptmx-backed controlling terminal. A plain
            // ProcessBuilder pipe is not equivalent: this script's native payload uses
            // terminal behavior and may not flush prompts to a pipe.
            handle = PtyBridge.start(command, new File("/"), 48, 140);
        } catch (IOException | RuntimeException | LinkageError e) {
            scriptFile.delete();
            throw new RemoteException("Unable to start native PTY: " + e.getMessage());
        }

        synchronized (processLock) {
            activePtyHandle = handle;
        }
        Thread readerThread = new Thread(
                () -> streamPty(handle, scriptFile, callback),
                "TermiGlow-PtyOutput");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private void streamPty(long handle, File scriptFile, IShellOutputCallback callback) {
        int exitCode = -1;
        String streamError = null;
        boolean callbackAvailable = true;
        try (InputStream stream = PtyBridge.openInputStream(handle);
             Reader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            char[] buffer = new char[CHUNK_CHARS];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                if (count == 0) continue;
                if (callbackAvailable) {
                    try {
                        callback.onOutput(new String(buffer, 0, count));
                    } catch (RemoteException e) {
                        // Continue draining the PTY even if the Activity has gone away.
                        callbackAvailable = false;
                    }
                }
            }
        } catch (Exception e) {
            streamError = e.getClass().getSimpleName() + ": "
                    + (e.getMessage() == null ? "PTY output stream failed" : e.getMessage());
            PtyBridge.terminate(handle);
        } finally {
            try {
                exitCode = PtyBridge.waitFor(handle);
            } catch (Exception e) {
                if (streamError == null) {
                    streamError = e.getClass().getSimpleName() + ": "
                            + (e.getMessage() == null ? "PTY wait failed" : e.getMessage());
                }
            }
            if (scriptFile.exists()) scriptFile.delete();
            synchronized (processLock) {
                if (activePtyHandle == handle) {
                    activePtyHandle = 0L;
                }
            }
        }

        if (callbackAvailable) {
            try {
                if (streamError != null) callback.onError(streamError);
                callback.onExit(exitCode);
            } catch (RemoteException ignored) {
                // Activity may already have closed.
            }
        }
    }

    @Override
    public void writeInput(String text) throws RemoteException {
        final long handle;
        synchronized (processLock) {
            handle = activePtyHandle;
        }
        if (handle == 0L) throw new RemoteException("No interactive script is running");
        try {
            PtyBridge.writeLine(handle, text);
        } catch (IOException e) {
            throw new RemoteException("Unable to send input to the PTY: " + e.getMessage());
        }
    }

    @Override
    public void closeInput() throws RemoteException {
        final long handle;
        synchronized (processLock) {
            handle = activePtyHandle;
        }
        if (handle == 0L) return;
        try {
            PtyBridge.sendEof(handle);
        } catch (IOException e) {
            throw new RemoteException("Unable to send EOF to the PTY: " + e.getMessage());
        }
    }

    @Override
    public void abortScript() {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
        }
        final long handle;
        synchronized (processLock) {
            handle = activePtyHandle;
        }
        PtyBridge.terminate(handle);
    }

    @Override
    public void exit() {
        abortScript();
        System.exit(0);
    }

    @Override
    public void destroy() {
        exit();
    }
    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

}
