package com.example.termiglow;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * GhostLock 临时 root 集成管理器。
 *
 * 云更新流程（每次点击执行触发）：
 *   1. 读取 uname -r 获取当前内核版本
 *   2. 尝试从 CLOUD_BASE_URL 下载 <release>.conf → 缓存到 filesDir/kernel_profiles_cloud/
 *   3. 若下载成功，使用云端最新 profile 执行
 *   4. 若下载失败但本地缓存存在，使用缓存版本
 *   5. 若无缓存，回退到 assets 内置 profile
 *   6. 均无则返回 NO_PROFILE
 *
 * 共享文件（credential-6x.conf / kernelsnitch-6x.conf 等）同步逻辑相同。
 */
public final class GhostLockManager {
    private static final String TAG = "GhostLock";
    private static final String ASSET_DIR = "kernel_profiles";
    private static final String BIN_NAME  = "libGhostlock.so";

    // ─── 云更新常量 ───────────────────────────────────────────
    private static final String CLOUD_BASE_URL =
            "https://raw.githubusercontent.com/YuKongA/ghostlock-app/main"
            + "/app/src/main/assets/kernel_profiles/";
    private static final String CLOUD_CACHE_DIR = "kernel_profiles_cloud";
    private static final int    CLOUD_CONNECT_TIMEOUT_MS = 10_000;
    private static final int    CLOUD_READ_TIMEOUT_MS    = 20_000;

    /** 与 profile 一起需要同步的共享文件（被 include 引用）。 */
    private static final String[] SHARED_FILES = {
            "credential-6x.conf",
            "kernelsnitch-6x.conf",
            "execution-tuning.conf",
            "execution-select-stack.conf",
            "execution-tcp-zerocopy.conf",
    };

    // ─── 日志回调（供 UI 实时显示进度）────────────────────────
    public interface LogCallback {
        void log(String message);
    }

    // ─── 执行结果 ─────────────────────────────────────────────
    public enum Result {
        SUCCESS,
        EXEC_FAILED,
        NO_PROFILE,
        NO_BINARY,
        SHIZUKU_UNAVAILABLE,
        ERROR
    }

    public static final class Outcome {
        public final Result result;
        public final String kernelRelease;
        public final String detail;
        public final List<String> availableProfiles;
        public final boolean viaShizuku;

        Outcome(Result r, String kernel, String detail,
                List<String> profiles, boolean viaShizuku) {
            this.result           = r;
            this.kernelRelease    = kernel;
            this.detail           = detail;
            this.availableProfiles = profiles;
            this.viaShizuku       = viaShizuku;
        }
    }

    // ─── 实例字段 ─────────────────────────────────────────────
    private final Context             context;
    private final boolean             useShizuku;
    private final IShellUserService   shizukuService;

    public GhostLockManager(Context context) {
        this(context, true, null);
    }

    public GhostLockManager(Context context, boolean useShizuku,
                            IShellUserService shizukuService) {
        this.context        = context.getApplicationContext();
        this.useShizuku     = useShizuku;
        this.shizukuService = shizukuService;
    }

    // ─── 公共接口 ─────────────────────────────────────────────

    public String getKernelRelease() {
        try {
            Process p = new ProcessBuilder("uname", "-r")
                    .redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine();
            p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            return "";
        }
    }

    public List<String> listAvailableProfiles() {
        List<String> out = new ArrayList<>();
        try {
            String[] list = context.getAssets().list(ASSET_DIR);
            if (list == null) return out;
            for (String name : list) {
                if (name.endsWith(".conf"))
                    out.add(name.substring(0, name.length() - 5));
            }
        } catch (IOException e) {
            Log.w(TAG, "list profiles failed", e);
        }
        return out;
    }

    /** 无 UI 回调版本（向下兼容）。 */
    public Outcome run() {
        return run(msg -> Log.d(TAG, msg));
    }

    /**
     * 主入口：先云端拉取，再执行。
     *
     * @param log UI 回调，用于向终端面板输出进度信息
     */
    public Outcome run(LogCallback log) {
        String kernel = getKernelRelease();
        if (kernel.isEmpty()) {
            return new Outcome(Result.ERROR, kernel,
                    "無法讀取 uname -r", listAvailableProfiles(), useShizuku);
        }

        // 1. 尝试云端拉取（同步共享文件 + 本 release profile）
        File cloudProfile = fetchCloudProfile(kernel, log);

        // 2. 确认 profile 来源
        String assetPath = ASSET_DIR + "/" + kernel + ".conf";
        boolean hasAsset = assetExists(assetPath);

        if (cloudProfile == null && !hasAsset) {
            return new Outcome(Result.NO_PROFILE, kernel,
                    "當前內核 " + kernel + " 不在 GhostLock 支援列表，且雲端拉取失敗",
                    listAvailableProfiles(), useShizuku);
        }

        if (cloudProfile != null) {
            log.log("[雲更新] 使用雲端 profile：" + cloudProfile.getName());
        } else {
            log.log("[雲更新] 網路不可用，使用內置 profile");
        }

        if (useShizuku) {
            return runViaShizuku(kernel, assetPath, cloudProfile, log);
        } else {
            return runInProcess(kernel, assetPath, cloudProfile, log);
        }
    }

    // ─── 云端拉取 ─────────────────────────────────────────────

    /**
     * 拉取当前 kernel 的 profile 及所有共享文件。
     *
     * @return 下载成功（或已有最新缓存）时返回缓存文件；失败时返回 null
     */
    private File fetchCloudProfile(String kernel, LogCallback log) {
        File cacheDir = new File(context.getFilesDir(), CLOUD_CACHE_DIR);
        if (!cacheDir.exists()) cacheDir.mkdirs();

        log.log("[雲更新] 正在從雲端拉取 profile：" + kernel + " …");

        // 先同步共享文件（失败不阻塞主 profile 下载）
        for (String shared : SHARED_FILES) {
            try {
                downloadToCache(CLOUD_BASE_URL + shared,
                        new File(cacheDir, shared));
            } catch (Exception e) {
                Log.d(TAG, "shared file fetch skipped: " + shared + " — " + e.getMessage());
            }
        }

        // 下载主 profile
        String profileName = kernel + ".conf";
        File   dest        = new File(cacheDir, profileName);
        try {
            boolean updated = downloadToCache(CLOUD_BASE_URL + profileName, dest);
            log.log(updated
                    ? "[雲更新] ✓ 已拉取最新 profile"
                    : "[雲更新] ✓ 本地缓存已是最新，跳過下載");
            return dest;
        } catch (Exception e) {
            log.log("[雲更新] ✗ 下載失敗（" + e.getMessage() + "）");
            // 有旧缓存则返回旧缓存
            if (dest.exists() && dest.length() > 0) {
                log.log("[雲更新] 使用上次緩存版本");
                return dest;
            }
            return null;
        }
    }

    /**
     * 下载 URL 到目标文件。若目标已存在且大小与服务器 Content-Length 一致，跳过。
     *
     * @return true = 实际写入了新内容；false = 跳过（已是最新）
     */
    private boolean downloadToCache(String urlStr, File dest) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(CLOUD_CONNECT_TIMEOUT_MS);
        conn.setReadTimeout(CLOUD_READ_TIMEOUT_MS);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "MOBAI-CloudUpdate/1.0");

        int status = conn.getResponseCode();
        if (status == 404) throw new IOException("404 Not Found: " + urlStr);
        if (status != 200) throw new IOException("HTTP " + status);

        long remoteLen = conn.getContentLengthLong();
        if (dest.exists() && dest.length() > 0
                && remoteLen > 0 && dest.length() == remoteLen) {
            conn.disconnect();
            return false; // 跳过
        }

        try (InputStream in  = conn.getInputStream();
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } finally {
            conn.disconnect();
        }
        return true;
    }

    // ─── Shizuku 执行路径 ─────────────────────────────────────

    private Outcome runViaShizuku(String kernel, String assetPath,
                                  File cloudProfile, LogCallback log) {
        if (shizukuService == null) {
            return new Outcome(Result.SHIZUKU_UNAVAILABLE, kernel,
                    "Shizuku UserService 未連線", listAvailableProfiles(), true);
        }
        try {
            // 1. 读取二进制
            byte[] binBytes;
            File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
            if (!bin.isFile()) {
                return new Outcome(Result.NO_BINARY, kernel,
                        "nativeLibraryDir 中缺少 " + BIN_NAME,
                        listAvailableProfiles(), true);
            }
            try (InputStream in = new FileInputStream(bin);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                binBytes = out.toByteArray();
            }

            // 2. 读取 profile（云端缓存优先，回退 assets）
            // Shizuku 路径：ghostlock 解析 include 时找不到外部文件，
            // 因此把共享文件内容内联展开后拼接到主 profile 头部，
            // 同时移除主 profile 中的 include 指令。
            byte[] profileBytes;
            byte[] mainConf;
            if (cloudProfile != null && cloudProfile.exists()) {
                mainConf = readFileBytes(cloudProfile);
            } else {
                mainConf = readAssetBytes(assetPath);
            }
            // 内联展开共享文件
            File cloudCacheDir = cloudProfile != null ? cloudProfile.getParentFile() : null;
            ByteArrayOutputStream merged = new ByteArrayOutputStream();
            String mainStr = new String(mainConf, StandardCharsets.UTF_8);
            for (String shared : SHARED_FILES) {
                String includeDirective = "include \"" + shared + "\"";
                if (mainStr.contains(includeDirective)) {
                    // 读取共享文件内容
                    byte[] sharedBytes = null;
                    File cloudShared = cloudCacheDir != null ? new File(cloudCacheDir, shared) : null;
                    if (cloudShared != null && cloudShared.exists()) {
                        sharedBytes = readFileBytes(cloudShared);
                    } else if (assetExists(ASSET_DIR + "/" + shared)) {
                        sharedBytes = readAssetBytes(ASSET_DIR + "/" + shared);
                    }
                    if (sharedBytes != null) {
                        // 移除 include 行，将内容内联
                        mainStr = mainStr.replace(includeDirective + "\n", "")
                                         .replace(includeDirective, "");
                        merged.write(sharedBytes);
                        merged.write('\n');
                    }
                }
            }
            merged.write(mainStr.getBytes(StandardCharsets.UTF_8));
            profileBytes = merged.toByteArray();

            // 3. 通过 Shizuku 执行
            String raw = shizukuService.runGhostLock(binBytes, profileBytes);
            return parseShizukuResult(raw, kernel);
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles(), true);
        }
    }

    private Outcome parseShizukuResult(String raw, String kernel) {
        String output = raw == null ? "" : raw;
        boolean ok = output.startsWith("exit=0\n");
        return new Outcome(ok ? Result.SUCCESS : Result.EXEC_FAILED,
                kernel, output, listAvailableProfiles(), true);
    }

    // ─── In-process 执行路径 ──────────────────────────────────

    private Outcome runInProcess(String kernel, String assetPath,
                                 File cloudProfile, LogCallback log) {
        File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
        if (!bin.exists() || !bin.canExecute()) {
            return new Outcome(Result.NO_BINARY, kernel,
                    "未找到 " + BIN_NAME + "（請確認已放入 jniLibs/arm64-v8a/）",
                    listAvailableProfiles(), false);
        }

        // 建立隔離的臨時目錄，讓 include "credential-6x.conf" 等能正確解析
        // ghostlock 以主 profile 所在目錄為基準查找 include 文件
        File runDir = new File(context.getFilesDir(), "gl_run_" + kernel);
        File profileFile = new File(runDir, kernel + ".conf");
        try {
            if (!runDir.exists()) runDir.mkdirs();

            // 1. 複製共享文件（assets 優先，若雲端緩存有更新版本則覆蓋）
            File cloudCacheDir = cloudProfile != null ? cloudProfile.getParentFile() : null;
            for (String shared : SHARED_FILES) {
                File dest = new File(runDir, shared);
                File cloudShared = cloudCacheDir != null ? new File(cloudCacheDir, shared) : null;
                if (cloudShared != null && cloudShared.exists()) {
                    copyFileTo(dest, cloudShared);
                } else if (assetExists(ASSET_DIR + "/" + shared)) {
                    copyAssetTo(dest, ASSET_DIR + "/" + shared);
                }
            }

            // 2. 複製主 profile
            if (cloudProfile != null && cloudProfile.exists()) {
                copyFileTo(profileFile, cloudProfile);
            } else {
                copyAssetTo(profileFile, assetPath);
            }
        } catch (IOException e) {
            return new Outcome(Result.ERROR, kernel,
                    "釋放 profile 失敗: " + e.getMessage(),
                    listAvailableProfiles(), false);
        }

        Process proc = null;
        try {
            proc = new ProcessBuilder(
                    bin.getAbsolutePath(),
                    "--load-prebuilt-profile", profileFile.getAbsolutePath()
            ).redirectErrorStream(true).start();

            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            int code = proc.waitFor();
            String output = sb.toString().trim();
            if (code == 0) {
                return new Outcome(Result.SUCCESS, kernel, output,
                        listAvailableProfiles(), false);
            } else {
                return new Outcome(Result.EXEC_FAILED, kernel,
                        "exit " + code + (output.isEmpty() ? "" : ": " + output),
                        listAvailableProfiles(), false);
            }
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles(), false);
        } finally {
            if (proc != null) proc.destroy();
            // 清理整個臨時目錄
            deleteDir(runDir);
        }
    }

    private void deleteDir(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) f.delete();
        dir.delete();
    }

    // ─── 工具方法 ─────────────────────────────────────────────

    private byte[] readFileBytes(File f) throws IOException {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private byte[] readAssetBytes(String assetPath) throws IOException {
        try (InputStream in = context.getAssets().open(assetPath);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private void copyAssetTo(File dest, String assetPath) throws IOException {
        try (InputStream in = context.getAssets().open(assetPath);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
    }

    private void copyFileTo(File dest, File src) throws IOException {
        try (InputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
    }

    private boolean assetExists(String path) {
        try (InputStream ignored = context.getAssets().open(path)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
