package com.example.termiglow;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/**
 * iOS-style frosted glass panel: blurs whatever {@code source} draws behind it, then adds a white
 * tint and a thin highlight border. The blur is computed on a heavily down-scaled snapshot, so it
 * is cheap; call {@link #refresh()} when the content behind the panel changes.
 */
final class GlassLayout extends FrameLayout {
    private static final int SCALE = 8;
    private static final int BLUR_RADIUS = 3;

    private final float radius;
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint tintPaint = new Paint();
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF borderRect = new RectF();
    private View source;
    private Bitmap small;
    private boolean dirty = true;
    private long lastSnapshot;
    private boolean blurEnabled = true;
    private boolean liquidGlass = false;

    GlassLayout(Context context, float radiusPx) {
        super(context);
        radius = radiusPx;
        setWillNotDraw(false);
        tintPaint.setColor(0x8FFFFFFF);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density));
        borderPaint.setColor(0xB3FFFFFF);
        sheenPaint.setStyle(Paint.Style.FILL);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, android.graphics.Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        setClipToOutline(true);
    }

    void setSource(View view) {
        source = view;
        refresh();
    }

    void refresh() {
        dirty = true;
        invalidate();
    }

    /** Turns the frosted-glass blur on or off. When off, the panel falls back to a flat,
     *  opaque tint instead of sampling and blurring what's behind it — cheaper to draw. */
    void setBlurEnabled(boolean enabled) {
        if (blurEnabled == enabled) return;
        blurEnabled = enabled;
        dirty = true;
        invalidate();
    }

    /** Adds an iOS-style "liquid glass" sheen: a soft diagonal highlight across the panel,
     *  plus a brighter, slightly thicker rim light, on top of the regular frosted glass. */
    void setLiquidGlass(boolean enabled) {
        if (liquidGlass == enabled) return;
        liquidGlass = enabled;
        borderPaint.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density) * (enabled ? 1.4f : 1f));
        borderPaint.setColor(enabled ? 0xD9FFFFFF : 0xB3FFFFFF);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        small = null;
        dirty = true;
        if (w > 0 && h > 0) {
            sheenPaint.setShader(new LinearGradient(
                    0, 0, w * 0.55f, h * 1.1f,
                    0x80FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (blurEnabled && source != null && getWidth() > 0 && getHeight() > 0 && source.getWidth() > 0) {
            updateBackdrop();
            if (small != null) {
                canvas.drawBitmap(small, null, new Rect(0, 0, getWidth(), getHeight()), bitmapPaint);
            }
        } else if (!blurEnabled) {
            canvas.drawColor(0xFFF2F4F8);
        }
        canvas.drawRect(0, 0, getWidth(), getHeight(), tintPaint);
        if (liquidGlass) {
            canvas.drawRect(0, 0, getWidth(), getHeight(), sheenPaint);
        }
        float inset = borderPaint.getStrokeWidth() / 2f;
        borderRect.set(inset, inset, getWidth() - inset, getHeight() - inset);
        canvas.drawRoundRect(borderRect, radius, radius, borderPaint);
    }

    private void updateBackdrop() {
        if (!dirty && small != null) return;
        long now = SystemClock.uptimeMillis();
        if (small != null && now - lastSnapshot < 50) {
            postInvalidateDelayed(50);
            return;
        }
        lastSnapshot = now;
        dirty = false;
        int w = Math.max(1, getWidth() / SCALE);
        int h = Math.max(1, getHeight() / SCALE);
        if (small == null || small.getWidth() != w || small.getHeight() != h) {
            small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        }
        small.eraseColor(0xFFF2F4F8);
        Canvas cv = new Canvas(small);
        cv.scale(1f / SCALE, 1f / SCALE);
        cv.translate(-getLeft(), -getTop());
        try {
            source.draw(cv);
        } catch (RuntimeException ignored) {
            // A child that cannot draw into a software canvas just leaves the plain backdrop.
        }
        blur(small, BLUR_RADIUS);
    }

    private static void blur(Bitmap bmp, int r) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] a = new int[w * h];
        int[] b = new int[w * h];
        bmp.getPixels(a, 0, w, 0, 0, w, h);
        for (int pass = 0; pass < 2; pass++) {
            pass1(a, b, w, h, r, true);
            pass1(b, a, w, h, r, false);
        }
        bmp.setPixels(a, 0, w, 0, 0, w, h);
    }

    private static void pass1(int[] src, int[] dst, int w, int h, int r, boolean horizontal) {
        int lines = horizontal ? h : w;
        int len = horizontal ? w : h;
        int div = 2 * r + 1;
        for (int line = 0; line < lines; line++) {
            for (int i = 0; i < len; i++) {
                int sr = 0, sg = 0, sb = 0;
                for (int k = -r; k <= r; k++) {
                    int j = Math.min(len - 1, Math.max(0, i + k));
                    int px = horizontal ? src[line * w + j] : src[j * w + line];
                    sr += (px >> 16) & 0xff;
                    sg += (px >> 8) & 0xff;
                    sb += px & 0xff;
                }
                int out = 0xff000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                if (horizontal) dst[line * w + i] = out; else dst[i * w + line] = out;
            }
        }
    }
}
