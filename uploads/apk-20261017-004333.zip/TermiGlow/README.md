# TermiGlow — Android Java Shell Terminal

一個深色霓虹風格的 Android Studio Java 範例專案，可在 App 私有目錄中執行 `/system/bin/sh` 支援的 shell 指令與腳本。

## 功能
- 深色終端風格介面
- 多行 Shell 腳本編輯
- 執行腳本並即時顯示合併後的標準輸出與錯誤輸出
- 顯示程序結束代碼
- 清除輸出視窗
- 腳本保存在 App 私有儲存空間，不要求儲存空間或 root 權限

## 開啟方式
1. 解壓縮 `TermiGlow.zip`。
2. 在 Android Studio 選擇 **Open**，開啟 `TermiGlow` 專案資料夾。
3. 使用 Android Studio 建議的 Gradle JDK（通常是 JDK 17），等待 Gradle Sync。
4. 連接 Android 手機並開啟開發者選項與 USB 偵錯，或使用模擬器。
5. 按 Run 執行 `app`。

## 測試腳本
在編輯框輸入：
```sh
#!/system/bin/sh
echo "Hello from TermiGlow"
echo "Android API:"
getprop ro.build.version.release
echo "Current app directory:"
pwd
```
按「執行腳本」即可看到輸出。

## Android 限制與安全
- 這不是 root 終端。命令以 App 的 Android UID 執行，不能任意讀寫其他 App 的私有資料。
- Android shell 環境不是完整 Linux 發行版；`bash`、`apt`、`sudo` 等可能不存在。
- 目前範例會將腳本寫入 App 私有目錄，使用 `/system/bin/sh` 執行。它不會自動取得 root 權限。
- 僅執行你理解且信任的腳本。Shell 腳本可以刪除或修改 App 有權存取的資料。
- 若腳本依賴額外 Linux 工具、Python、Node.js 等，需要另行整合相應執行環境。

## 專案結構
```
TermiGlow/
├── settings.gradle
├── build.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/termiglow/MainActivity.java
```

## 技術資訊
- Java
- Android Gradle Plugin 8.7.3
- compileSdk 35 / targetSdk 28 / minSdk 23
- 不依賴第三方 UI 函式庫
