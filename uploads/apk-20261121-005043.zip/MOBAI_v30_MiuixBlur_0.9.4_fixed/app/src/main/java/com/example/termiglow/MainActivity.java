package com.example.termiglow;

import androidx.activity.ComponentActivity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends ComponentActivity {
    // Light theme palette.
    private static final int BG = Color.rgb(247, 247, 247);
    private static final int PANEL = Color.rgb(232, 232, 232);
    private static final int ACCENT = Color.rgb(37, 99, 235);
    private static final int TEXT = Color.rgb(24, 24, 27);
    private static final int MUTED = Color.rgb(113, 113, 122);
    private static final int BORDER = Color.rgb(232, 232, 232);
    private static final int ERROR = Color.rgb(220, 38, 38);

    private EditText inputBox;
    private TextView inputLabel;
    private TextView output;
    private TextView status;
    private Button runButton;
    private ScrollView outputScroll;
    private static final int MAX_TERMINAL_CHARS = 120_000;
    private static final int MAX_RECENT_CHARS = 4_000;
    private static final long OUTPUT_FLUSH_DELAY_MS = 40L;
    private static final Pattern MENU_OPTION_PATTERN =
            Pattern.compile("(?m)^\\s*\\[(\\d+)\\]\\s*(.+?)\\s*$");
    private static final Pattern EXIT_CODE_PATTERN =
            Pattern.compile("\\[process exited: (-?\\d+)\\]");

    private final AnsiRenderer ansi = new AnsiRenderer();
    private final Handler outputHandler = new Handler(Looper.getMainLooper());
    private final Object outputBufferLock = new Object();
    private final StringBuilder pendingOutput = new StringBuilder(4096);
    private boolean outputFlushScheduled;
    private volatile boolean activityDestroyed;
    private final Runnable outputFlushRunnable = this::flushPendingOutput;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile long activePtyHandle;
    // Default = PTY run as the app user, exactly like MT Manager's terminal; main.sh finds su/rish itself.
    private volatile boolean usePty = true;
    private volatile Process activeProcess;
    private volatile OutputStream activeProcessInput;
    private android.widget.Switch ptyBox;
    private TextView privilegeInfo;
    private LinearLayout quickBox;
    private LinearLayout quickBar;
    private String lastMenuSig = "";
    private final StringBuilder recentText = new StringBuilder();
    private View[] pages;
    private int currentPage = -1;
    private GlassLayout navGlass;
    private LiquidGlassNavigationView navCompose;
    private boolean wideLayout;
    private android.widget.FrameLayout rootLayout;
    private volatile float uiScale = 1f;
    private volatile boolean blurEnabled = true;
    private volatile boolean floatingNavBottom = false;
    private volatile boolean liquidGlassEnabled = false;
    private View customUiOverlay;
    private static final String DEFAULT_SCRIPT_URL =
            "https://raw.githubusercontent.com/MB-1428/update/main/update/main.sh";
    private volatile boolean scriptRunning = false;
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private volatile String executionMode = "normal";
    private volatile boolean shizukuPermissionRequestPending = false;
    private volatile boolean rootFallbackStarted = false;
    private volatile boolean rootAvailable = false;
    private volatile boolean userServiceBindInProgress = false;
    private volatile boolean userServiceBound = false;
    private volatile IShellUserService shizukuShellService;
    private volatile CountDownLatch userServiceReady = new CountDownLatch(1);
    private Shizuku.UserServiceArgs userServiceArgs;
    private volatile boolean ghostLockRunning = false;
    private volatile GhostLockManager.Result ghostLockLastResult = null;
    private GhostLockManager ghostLockManager;

    // GhostLock page UI references (for live status updates)
    private LinearLayout glStatusCard;
    private TextView glStatusTitle;
    private TextView glStatusSub;
    private TextView glStatusIcon;
    private android.widget.Switch glViaShizukuSwitch;
    private TextView glViaShizukuSub;
    private Button glRunBtn;
    private final StringBuilder ghostLockLog = new StringBuilder();

    private final IShellOutputCallback shellOutputCallback = new IShellOutputCallback.Stub() {
        @Override
        public void onOutput(String text) {
            appendOutput(text);
        }

        @Override
        public void onExit(int exitCode) {
            runOnUiThread(() -> completeScript(exitCode));
        }

        @Override
        public void onError(String message) {
            appendOutput("\n⚠ 輸出中斷：" + message + "\n");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener =
            (requestCode, grantResult) -> {
                if (requestCode != SHIZUKU_REQUEST_CODE) return;
                shizukuPermissionRequestPending = false;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    executionMode = "shizuku";
                    appendOutput("✔ 已取得 Shizuku 授權，正在連線…\n");
                    updatePrivilegeStatus("Shizuku 連線中");
                    bindShizukuUserService();
                } else {
                    appendOutput("未授權 Shizuku，改為嘗試 root。\n");
                    requestRootFallback();
                }
            };

    private final Shizuku.OnBinderReceivedListener shizukuBinderListener =
            () -> runOnUiThread(this::checkShizukuPermission);

    private final ServiceConnection userServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuShellService = IShellUserService.Stub.asInterface(service);
            userServiceBindInProgress = false;
            userServiceBound = true;
            userServiceReady.countDown();
            appendOutput("✔ Shizuku 已連線。\n");
            updatePrivilegeStatus("Shizuku 已就緒");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            shizukuShellService = null;
            userServiceBindInProgress = false;
            userServiceBound = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線中斷。\n");
            updatePrivilegeStatus("Shizuku 已中斷");
        }
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        int uiFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);

        installCrashRecorder();
        android.content.SharedPreferences prefs = getSharedPreferences("mobai_prefs", MODE_PRIVATE);
        uiScale = prefs.getFloat("ui_scale", 1f);
        blurEnabled = prefs.getBoolean("blur_enabled", true);
        floatingNavBottom = prefs.getBoolean("floating_nav_bottom", false);
        liquidGlassEnabled = prefs.getBoolean("liquid_glass_enabled", false);
        try {
            buildUi(state == null);
        } catch (Throwable t) {
            showFatalScreen("介面建立失敗", t);
            return;
        }
        showLastCrashIfAny();
        appendOutput("歡迎使用 MOBAI\n\n"
                + "使用步驟\n"
                + "① 按下方「開始運行」\n"
                + "② 出現選項時，點上方的按鈕即可\n"
                + "③ 看到「配置完成」，介面就會出現\n\n"
                + "小提示：若介面沒出現，可到左側「設置」更改運行方式後再試。\n\n");

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (shizukuShellService != null || shizukuPermissionRequestPending
                    || "shizuku".equals(executionMode)) return;
            if (Shizuku.pingBinder()) {
                checkShizukuPermission();
            } else {
                appendOutput("未偵測到 Shizuku，改為嘗試 root；沒有 root 會使用一般權限。\n");
                requestRootFallback();
            }
        }, 1500);
    }


    // ---- crash recorder: lets a non-developer see why the app closed ----
    private File crashFile() {
        return new File(getFilesDir(), "last_crash.txt");
    }

    private static String stackToString(Throwable t) {
        java.io.StringWriter sw = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(sw));
        return sw.toString();
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        final File file = crashFile();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
                out.write(("線程：" + thread.getName() + "\n" + stackToString(error))
                        .getBytes(StandardCharsets.UTF_8));
            } catch (Throwable ignored) {
                // Best effort only.
            }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private void showLastCrashIfAny() {
        File file = crashFile();
        if (!file.exists()) return;
        String text;
        try (java.io.FileInputStream in = new java.io.FileInputStream(file)) {
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
            text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return;
        }
        file.delete();
        TextView body = label(text, 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(8), dp(16), dp(8));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new android.app.AlertDialog.Builder(this)
                .setTitle("上次閃退的原因（可長按複製後貼給開發者）")
                .setView(scroll)
                .setPositiveButton("知道了", null)
                .show();
    }

    private void showFatalScreen(String title, Throwable t) {
        TextView body = label(title + "\n\n" + stackToString(t), 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(24), dp(16), dp(16));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.addView(body);
        setContentView(scroll);
    }

    private LinearLayout buildTerminalPage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));

        // Title row: large title on the left, clear pill on the right.
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(label("MOBAI", 30, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = actionButton("清除", Color.WHITE, TEXT);
        titleRow.addView(clear, new LinearLayout.LayoutParams(dp(76), dp(40)));
        page.addView(titleRow);

        // Status card, styled like a list item.
        LinearLayout item = new LinearLayout(this);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(14), dp(12), dp(16), dp(12));
        item.setBackground(glassBg(22));
        TextView icon = label(">_", 17, Color.WHITE, true);
        icon.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(Color.rgb(39, 39, 42), 14, Color.rgb(39, 39, 42), 0));
        item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(14), 0, dp(8), 0);
        names.addView(label("MOBAI 主程式", 16, TEXT, true));
        names.addView(label("按下方「開始運行」即可啟動", 12, MUTED, false));
        item.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("待命", 10, MUTED, true);
        status.setGravity(Gravity.END);
        item.addView(status, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
        itemLp.topMargin = dp(16);
        page.addView(item, itemLp);

        // Terminal card.
        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(glassBg(22));
        output = label("", 11, TEXT, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(16), dp(16), dp(16), dp(16));
        output.setTextIsSelectable(true);
        // Keep terminal lines unwrapped so ASCII art / menus stay aligned; scroll sideways if needed.
        output.setHorizontallyScrolling(true);
        android.widget.HorizontalScrollView hScroll = new android.widget.HorizontalScrollView(this);
        hScroll.setFillViewport(true);
        hScroll.addView(output);
        outputScroll.addView(hScroll);
        outputScroll.getViewTreeObserver().addOnScrollChangedListener(() -> {
            if (navGlass != null) navGlass.refresh();
        });
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(12);
        page.addView(outputScroll, outLp);

        quickBox = new LinearLayout(this);
        quickBox.setOrientation(LinearLayout.VERTICAL);
        quickBox.setVisibility(View.GONE);
        TextView quickHint = label("請選擇一個選項：", 12, MUTED, true);
        quickHint.setPadding(dp(6), 0, 0, dp(6));
        quickBox.addView(quickHint);
        android.widget.HorizontalScrollView quickScroll = new android.widget.HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        quickBar = new LinearLayout(this);
        quickScroll.addView(quickBar);
        quickBox.addView(quickScroll);
        LinearLayout.LayoutParams quickLp = new LinearLayout.LayoutParams(-1, -2);
        quickLp.topMargin = dp(12);
        page.addView(quickBox, quickLp);

        inputLabel = label("啟動參數（選填，一般不用填）", 11, MUTED, true);
        LinearLayout.LayoutParams inputLabelLp = new LinearLayout.LayoutParams(-1, -2);
        inputLabelLp.topMargin = dp(14);
        inputLabelLp.leftMargin = dp(6);
        page.addView(inputLabel, inputLabelLp);

        // Gray pill input, like the search bar in the reference.
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setBackground(round(PANEL, 28, PANEL, 0));
        LinearLayout.LayoutParams inputRowLp = new LinearLayout.LayoutParams(-1, dp(54));
        inputRowLp.topMargin = dp(6);
        page.addView(inputRow, inputRowLp);

        TextView prompt = label("$", 19, MUTED, true);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        prompt.setGravity(Gravity.CENTER);
        inputRow.addView(prompt, new LinearLayout.LayoutParams(dp(46), -1));

        inputBox = new EditText(this);
        inputBox.setTextSize(14);
        inputBox.setSingleLine(false);
        inputBox.setMinLines(1);
        inputBox.setMaxLines(2);
        inputBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        inputBox.setTypeface(Typeface.MONOSPACE);
        inputBox.setTextColor(TEXT);
        inputBox.setHintTextColor(MUTED);
        inputBox.setHint("一般請留空");
        inputBox.setBackground(null);
        inputBox.setPadding(0, 0, dp(18), 0);
        inputRow.addView(inputBox, new LinearLayout.LayoutParams(0, -1, 1));

        runButton = actionButton("▶  開始運行", ACCENT, Color.WHITE);
        LinearLayout.LayoutParams runLp = new LinearLayout.LayoutParams(-1, dp(52));
        runLp.topMargin = dp(10);
        page.addView(runButton, runLp);

        runButton.setOnClickListener(v -> {
            if (scriptRunning) sendInteractiveInput();
            else runBuiltInScript();
        });
        clear.setOnClickListener(v -> clearTerminalOutput());
        return page;
    }

    private LinearLayout newPage(String title) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));
        page.addView(label(title, 30, TEXT, true));
        return page;
    }

    /** White rounded list-item card: title + subtitle on the left, optional view on the right. */
    private LinearLayout listCard(String title, TextView sub, View right) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(14), dp(16), dp(14));
        card.setBackground(glassBg(22));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(label(title, 16, TEXT, true));
        names.addView(sub);
        card.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(12);
            card.addView(right, lp);
        }
        return card;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        return lp;
    }

    private LinearLayout buildSettingsPage() {
        LinearLayout page = newPage("設置");

        ptyBox = new android.widget.Switch(this);
        ptyBox.setChecked(usePty);
        ptyBox.setOnCheckedChangeListener((b, checked) -> usePty = checked);
        TextView modeSub = label("開啟＝建議方式\n如果介面沒出現或選項異常，可關閉後再試一次", 12, MUTED, false);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("運行方式", modeSub, ptyBox), first);

        privilegeInfo = label("偵測中…", 12, MUTED, false);
        page.addView(listCard("權限狀態", privilegeInfo, null), cardLp());

        TextView customUiSub = label("調整介面縮放等顯示選項", 12, MUTED, false);
        TextView customUiArrow = label("›", 18, MUTED, true);
        LinearLayout customUiCard = listCard("自定義介面", customUiSub, customUiArrow);
        customUiCard.setOnClickListener(v -> showCustomUiPage());
        page.addView(customUiCard, cardLp());

        TextView clearSub = label("每次按「開始運行」都會先清空畫面", 12, MUTED, false);
        TextView on = label("已啟用", 11, ACCENT, true);
        page.addView(listCard("開始前清空畫面", clearSub, on), cardLp());

        TextView note = label("運行中無法更改運行方式。", 11, MUTED, false);
        LinearLayout.LayoutParams noteLp = cardLp();
        noteLp.leftMargin = dp(6);
        page.addView(note, noteLp);

        return page;
    }

    private LinearLayout buildRootPage() {
        LinearLayout page = newPage("GhostLock");

        // ── STATUS CARD ──────────────────────────────────────────────
        boolean shizukuReady = shizukuShellService != null;
        int statusBg    = shizukuReady ? 0xFFDCFCE7 : 0xFFFEE2E2;
        int statusColor = shizukuReady ? 0xFF16A34A : 0xFFDC2626;

        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.HORIZONTAL);
        statusCard.setGravity(Gravity.CENTER_VERTICAL);
        statusCard.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable statusBgD = new GradientDrawable();
        statusBgD.setColor(statusBg);
        statusBgD.setCornerRadius(dp(18));
        statusCard.setBackground(statusBgD);

        LinearLayout textPart = new LinearLayout(this);
        textPart.setOrientation(LinearLayout.VERTICAL);
        glStatusTitle = label(shizukuReady ? "受支持" : "不支持", 20, statusColor, true);
        glStatusSub   = label(shizukuReady ? "Shizuku 已就緒" : "Shizuku 未就緒", 13, statusColor, false);
        glStatusSub.setAlpha(0.75f);
        textPart.addView(glStatusTitle);
        textPart.addView(glStatusSub);
        statusCard.addView(textPart, new LinearLayout.LayoutParams(0, -2, 1));

        // Circle check / X icon
        LinearLayout iconCircle = new LinearLayout(this);
        iconCircle.setGravity(Gravity.CENTER);
        int circleSize = dp(52);
        GradientDrawable circleD = new GradientDrawable();
        circleD.setShape(GradientDrawable.OVAL);
        circleD.setColor(statusColor);
        iconCircle.setBackground(circleD);
        glStatusIcon = label(shizukuReady ? "✓" : "✗", 24, Color.WHITE, true);
        iconCircle.addView(glStatusIcon);
        LinearLayout.LayoutParams circleLp = new LinearLayout.LayoutParams(circleSize, circleSize);
        statusCard.addView(iconCircle, circleLp);

        glStatusCard = statusCard;
        LinearLayout.LayoutParams statusLp = cardLp();
        statusLp.topMargin = dp(16);
        page.addView(statusCard, statusLp);

        // ── DEVICE INFO CARDS ─────────────────────────────────────────
        String deviceName = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
        page.addView(listCard("設備",   label(deviceName, 12, MUTED, false), null), cardLp());
        page.addView(listCard("芯片",   label(getSocName(), 12, MUTED, false), null), cardLp());

        String kernelVer = System.getProperty("os.version");
        if (kernelVer == null || kernelVer.isEmpty()) kernelVer = "未知";
        // Trim long kernel strings to fit the card
        if (kernelVer.length() > 40) kernelVer = kernelVer.substring(0, 37) + "…";
        page.addView(listCard("內核", label(kernelVer, 12, MUTED, false), null), cardLp());

        int cpuCores = Runtime.getRuntime().availableProcessors();
        String maxFreq = getMaxCpuFreq();
        TextView freqChip = null;
        if (!maxFreq.isEmpty()) {
            freqChip = label(maxFreq, 11, ACCENT, true);
            freqChip.setBackground(round(0x192563EB, 20, 0, 0));
            freqChip.setPadding(dp(10), dp(4), dp(10), dp(4));
        }
        page.addView(listCard("CPU 核心數", label(cpuCores + " 核心", 12, MUTED, false), freqChip), cardLp());

        // ── OPTIONS SECTION ───────────────────────────────────────────
        android.widget.Switch safeModeSwitch = new android.widget.Switch(this);
        safeModeSwitch.setChecked(false);
        TextView safeModeSub = label("禁用所有模組，僅執行基礎 Root 操作", 12, MUTED, false);
        page.addView(listCard("安全模式", safeModeSub, safeModeSwitch), cardLp());

        glViaShizukuSwitch = new android.widget.Switch(this);
        glViaShizukuSwitch.setChecked(shizukuReady);
        glViaShizukuSwitch.setEnabled(shizukuReady);
        glViaShizukuSub = label(shizukuReady ? "Shizuku 已就緒" : "Shizuku 未連線", 12, MUTED, false);
        page.addView(listCard("通過 Shizuku", glViaShizukuSub, glViaShizukuSwitch), cardLp());

        TextView advSub   = label("配置參數、自定義 profile 路徑等", 12, MUTED, false);
        TextView advArrow = label("›", 20, MUTED, true);
        LinearLayout advCard = listCard("高級選項", advSub, advArrow);
        advCard.setOnClickListener(v -> showCustomUiPage());
        page.addView(advCard, cardLp());

        // ── ACTION BUTTONS ────────────────────────────────────────────
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button logBtn = actionButton("查看日誌", Color.WHITE, ACCENT);
        logBtn.setOnClickListener(v -> showGhostLockLog());

        glRunBtn = actionButton("🔓  執行 Root", ACCENT, Color.WHITE);
        glRunBtn.setEnabled(!ghostLockRunning);
        glRunBtn.setOnClickListener(v -> runGhostLockNow());

        LinearLayout.LayoutParams leftBtnLp = new LinearLayout.LayoutParams(0, -2, 1);
        LinearLayout.LayoutParams rightBtnLp = new LinearLayout.LayoutParams(0, -2, 1);
        rightBtnLp.leftMargin = dp(12);
        btnRow.addView(logBtn,    leftBtnLp);
        btnRow.addView(glRunBtn,  rightBtnLp);

        LinearLayout.LayoutParams btnRowLp = cardLp();
        btnRowLp.topMargin = dp(24);
        page.addView(btnRow, btnRowLp);

        return page;
    }

    /** Refresh the GhostLock status card and Shizuku toggle after a status change. */
    private void refreshGhostLockStatus() {
        if (glStatusCard == null) return;
        boolean ready = shizukuShellService != null;
        int bg    = ready ? 0xFFDCFCE7 : 0xFFFEE2E2;
        int color = ready ? 0xFF16A34A : 0xFFDC2626;

        GradientDrawable bgD = new GradientDrawable();
        bgD.setColor(bg);
        bgD.setCornerRadius(dp(18));
        glStatusCard.setBackground(bgD);

        glStatusTitle.setText(ready ? "受支持" : "不支持");
        glStatusTitle.setTextColor(color);
        glStatusSub.setText(ready ? "Shizuku 已就緒" : "Shizuku 未就緒");
        glStatusSub.setTextColor(color);
        glStatusIcon.setText(ready ? "✓" : "✗");

        // Update the icon circle background
        if (glStatusCard.getChildCount() >= 2) {
            View iconCircle = glStatusCard.getChildAt(1);
            GradientDrawable circleD = new GradientDrawable();
            circleD.setShape(GradientDrawable.OVAL);
            circleD.setColor(color);
            iconCircle.setBackground(circleD);
        }

        if (glViaShizukuSwitch != null) {
            glViaShizukuSwitch.setChecked(ready);
            glViaShizukuSwitch.setEnabled(ready);
        }
        if (glViaShizukuSub != null) {
            glViaShizukuSub.setText(ready ? "Shizuku 已就緒" : "Shizuku 未連線");
        }
    }

    /** Shows a bottom dialog with the recent GhostLock execution log. */
    private void showGhostLockLog() {
        android.app.Dialog dlg = new android.app.Dialog(this);
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dlg.getWindow().setLayout(-1, -2);
            dlg.getWindow().setGravity(Gravity.BOTTOM);
        }

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable containerBg = new GradientDrawable();
        containerBg.setColor(Color.rgb(18, 18, 24));
        containerBg.setCornerRadii(new float[]{dp(20), dp(20), dp(20), dp(20), 0, 0, 0, 0});
        container.setBackground(containerBg);
        container.setPadding(dp(0), dp(4), dp(0), dp(16));

        // Drag handle
        LinearLayout handle = new LinearLayout(this);
        handle.setGravity(Gravity.CENTER);
        handle.setPadding(0, dp(10), 0, dp(10));
        GradientDrawable handleBar = new GradientDrawable();
        handleBar.setColor(0x44FFFFFF);
        handleBar.setCornerRadius(dp(3));
        android.widget.FrameLayout handleView = new android.widget.FrameLayout(this);
        handleView.setBackground(handleBar);
        handle.addView(handleView, new LinearLayout.LayoutParams(dp(36), dp(4)));
        container.addView(handle);

        // Title row
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(dp(20), dp(4), dp(16), dp(12));
        TextView titleLbl = label("日誌", 18, Color.WHITE, true);
        titleRow.addView(titleLbl, new LinearLayout.LayoutParams(0, -2, 1));
        Button closeBtn = new Button(this);
        closeBtn.setText("✕");
        closeBtn.setTextColor(0xAAFFFFFF);
        closeBtn.setTextSize(16);
        closeBtn.setAllCaps(false);
        closeBtn.setBackground(null);
        closeBtn.setOnClickListener(v -> dlg.dismiss());
        titleRow.addView(closeBtn, new LinearLayout.LayoutParams(dp(44), dp(44)));
        container.addView(titleRow);

        // Log content
        ScrollView scroll = new ScrollView(this);
        TextView logText = new TextView(this);
        logText.setTextSize(11);
        logText.setTextColor(0xFFD6E2EA);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setPadding(dp(16), dp(4), dp(16), dp(8));
        String logContent = ghostLockLog.length() > 0
                ? ghostLockLog.toString()
                : "尚無日誌。請先執行 Root。";
        logText.setText(logContent);
        scroll.addView(logText);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, dp(320));
        container.addView(scroll, scrollLp);

        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        dlg.setContentView(container);
        dlg.show();
    }

    /** Read the SoC / platform name from system properties or Build fields. */
    private String getSocName() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop", "ro.board.platform"});
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            if (line != null && !line.trim().isEmpty()) return line.trim().toUpperCase();
        } catch (Exception ignored) {}
        String board = android.os.Build.BOARD;
        if (board != null && !board.isEmpty() && !board.equalsIgnoreCase("unknown"))
            return board.toUpperCase();
        return android.os.Build.HARDWARE;
    }

    /** Read the highest CPU max-frequency from sysfs and return as a GHz string. */
    private String getMaxCpuFreq() {
        long maxKhz = 0;
        for (int i = 0; i < 16; i++) {
            java.io.File f = new java.io.File(
                    "/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (!f.exists()) continue;
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(f));
                String line = br.readLine();
                br.close();
                if (line != null) {
                    long khz = Long.parseLong(line.trim());
                    if (khz > maxKhz) maxKhz = khz;
                }
            } catch (Exception ignored) {}
        }
        if (maxKhz == 0) return "";
        return String.format("%.2f GHz", maxKhz / 1_000_000.0);
    }

    /** Full-screen overlay (back arrow + title, like the Root settings sub-page style). */
    private View buildCustomUiPage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BG);
        page.setPadding(dp(18), dp(18), dp(18), dp(18));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("←", 22, TEXT, true);
        back.setPadding(dp(4), dp(4), dp(16), dp(4));
        back.setOnClickListener(v -> hideCustomUiPage());
        titleRow.addView(back);
        titleRow.addView(label("自定義介面", 20, TEXT, true));
        page.addView(titleRow);

        android.widget.Switch blurSwitch = new android.widget.Switch(this);
        blurSwitch.setChecked(blurEnabled);
        blurSwitch.setOnCheckedChangeListener((b, checked) -> saveBlurEnabled(checked));
        TextView blurSub = label("啟用導覽列的毛玻璃模糊效果；關閉後改為不透明面板，較省效能", 12, MUTED, false);
        LinearLayout.LayoutParams blurLp = cardLp();
        blurLp.topMargin = dp(20);
        page.addView(listCard("模糊", blurSub, blurSwitch), blurLp);

        android.widget.Switch floatSwitch = new android.widget.Switch(this);
        floatSwitch.setChecked(floatingNavBottom);
        floatSwitch.setOnCheckedChangeListener((b, checked) -> saveFloatingNavBottom(checked));
        TextView floatSub = label("分頁切換列移到下方，直接懸浮在頁面上方（平板也會改用此樣式）", 12, MUTED, false);
        page.addView(listCard("懸浮底欄", floatSub, floatSwitch), cardLp());

        android.widget.Switch liquidSwitch = new android.widget.Switch(this);
        liquidSwitch.setChecked(liquidGlassEnabled);
        liquidSwitch.setOnCheckedChangeListener((b, checked) -> saveLiquidGlassEnabled(checked));
        TextView liquidSub = label("為懸浮底欄加上 iOS 風格的液態玻璃光澤效果", 12, MUTED, false);
        page.addView(listCard("液態玻璃", liquidSub, liquidSwitch), cardLp());

        TextView scaleTitle = label("界面縮放", 16, TEXT, true);
        LinearLayout.LayoutParams scaleTitleLp = cardLp();
        scaleTitleLp.topMargin = dp(24);
        page.addView(scaleTitle, scaleTitleLp);
        TextView scaleSub = label("調整全局顯示比例，變更後需要重新整理介面", 12, MUTED, false);
        page.addView(scaleSub, cardLp());

        TextView scaleValue = label(Math.round(uiScale * 100) + "%", 14, ACCENT, true);
        android.widget.SeekBar seek = new android.widget.SeekBar(this);
        seek.setMax(50); // 80% .. 130%, step 1%
        seek.setProgress(Math.round((uiScale - 0.8f) * 100));
        LinearLayout.LayoutParams seekLp = cardLp();
        seekLp.topMargin = dp(12);
        page.addView(scaleValue, cardLp());
        page.addView(seek, seekLp);
        seek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                float scale = 0.8f + progress / 100f;
                scaleValue.setText(Math.round(scale * 100) + "%");
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar sb) { }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar sb) {
                float scale = 0.8f + sb.getProgress() / 100f;
                saveUiScale(scale);
                recreate();
            }
        });

        return page;
    }

    private void showCustomUiPage() {
        if (rootLayout == null) return;
        if (customUiOverlay == null) customUiOverlay = buildCustomUiPage();
        else if (customUiOverlay.getParent() != null) return;
        customUiOverlay.setAlpha(0f);
        rootLayout.addView(customUiOverlay, new android.widget.FrameLayout.LayoutParams(-1, -1));
        customUiOverlay.animate().alpha(1f).setDuration(200).start();
    }

    private void hideCustomUiPage() {
        if (customUiOverlay == null || customUiOverlay.getParent() == null) return;
        customUiOverlay.animate().alpha(0f).setDuration(150)
                .withEndAction(() -> rootLayout.removeView(customUiOverlay)).start();
    }

    private void runGhostLockNow() {
        if (ghostLockRunning) return;
        ghostLockRunning = true;
        if (glRunBtn != null) glRunBtn.setEnabled(false);
        ghostLockLog.setLength(0);
        executor.execute(() -> {
            // 每次都用當前 Shizuku 連線狀態建立實例（避免緩存到 null service）
            boolean hasShizuku = shizukuShellService != null;
            ghostLockManager = new GhostLockManager(
                    MainActivity.this, hasShizuku, shizukuShellService);
            GhostLockManager.Outcome outcome = ghostLockManager.run(msg -> runOnUiThread(() -> {
                appendOutput(msg + "\n");
                ghostLockLog.append(msg).append("\n");
                if (ghostLockLog.length() > 32000)
                    ghostLockLog.delete(0, ghostLockLog.length() - 24000);
            }));
            final GhostLockManager.Result result = outcome.result;
            final String detail = outcome.detail;
            final String kernel = outcome.kernelRelease;
            final java.util.List<String> profiles = outcome.availableProfiles;
            runOnUiThread(() -> {
                ghostLockRunning = false;
                ghostLockLastResult = result;
                if (glRunBtn != null) glRunBtn.setEnabled(true);
                String statusText;
                switch (result) {
                    case SUCCESS:
                        statusText = "✔ GhostLock 執行成功";
                        break;
                    case EXEC_FAILED:
                        statusText = "⚠ GhostLock 執行失敗";
                        break;
                    case NO_PROFILE:
                        statusText = "⚠ 目前内核沒有對應的 GhostLock profile";
                        break;
                    case NO_BINARY:
                        statusText = "⚠ 找不到 libghostlock.so，請確認已放入 jniLibs/arm64-v8a/";
                        break;
                    case SHIZUKU_UNAVAILABLE:
                        statusText = "⚠ GhostLock 尚未啟用：目前沒有可用的 Shizuku 執行服務";
                        break;
                    case ERROR:
                    default:
                        statusText = "⚠ GhostLock 發生錯誤";
                        break;
                }
                updatePrivilegeStatus(statusText);
                String logFooter = "\n[GhostLock] 結果：" + statusText + "\n";
                appendOutput(logFooter);
                ghostLockLog.append(logFooter);
                if (detail != null) {
                    appendOutput("[GhostLock] " + detail + "\n");
                    ghostLockLog.append("[GhostLock] ").append(detail).append("\n");
                }
                if (kernel != null && !kernel.isEmpty()) {
                    appendOutput("[GhostLock] kernel：" + kernel + "\n");
                    ghostLockLog.append("[GhostLock] kernel：").append(kernel).append("\n");
                }
                if (profiles != null && !profiles.isEmpty()) {
                    StringBuilder sb = new StringBuilder("[GhostLock] 可用 profiles：");
                    for (String p : profiles) sb.append(p).append(", ");
                    appendOutput(sb.toString() + "\n");
                    ghostLockLog.append(sb).append("\n");
                }
            });
        });
    }

    /** The script address is fixed at build time; users cannot change it. */
    private String getScriptUrl() {
        return DEFAULT_SCRIPT_URL;
    }

    /** Turns a GitHub "blob" page link into the raw file link so the app downloads the script, not HTML. */
    private static String normalizeScriptUrl(String url) {
        if (url == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^https://github\\.com/([^/]+)/([^/]+)/blob/(.+)$").matcher(url.trim());
        if (m.find()) {
            return "https://raw.githubusercontent.com/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3);
        }
        return url.trim();
    }

    private LinearLayout buildAboutPage() {
        LinearLayout page = newPage("關於");
        TextView ver = label("v2.8", 12, MUTED, false);
        TextView tag = label("MOBAI", 11, ACCENT, true);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("版本", ver, tag), first);

        TextView steps = label("① 到「終端」按「開始運行」\n② 出現選項時，點上方的按鈕\n③ 看到「配置完成」，介面就會出現", 12, MUTED, false);
        page.addView(listCard("使用步驟", steps, null), cardLp());

        TextView about = label("MOBAI 會啟動內建的主程式，並顯示運行過程。", 12, MUTED, false);
        page.addView(listCard("說明", about, null), cardLp());

        TextView perm = label("會依序嘗試 Shizuku → root → 一般權限。\n請只在信任的來源使用。", 12, MUTED, false);
        page.addView(listCard("權限", perm, null), cardLp());

        TextView pkg = label(getPackageName(), 12, MUTED, false);
        page.addView(listCard("套件名稱", pkg, null), cardLp());
        return page;
    }

    private static void appendSpan(android.text.SpannableStringBuilder sb, String text, int color, boolean bold) {
        int start = sb.length();
        sb.append(text);
        sb.setSpan(new android.text.style.ForegroundColorSpan(color), start, sb.length(),
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) {
            sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), start, sb.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    /** Boot-log lines: device facts are real; module lines are only for show. */
    private java.util.List<String[]> buildBootLines() {
        java.util.List<String[]> l = new java.util.ArrayList<>();
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        String abi = android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "?";
        String kernel = System.getProperty("os.version");
        l.add(new String[] {"HEAD", "MOBAI Boot Loader v2.9"});
        l.add(new String[] {"INFO", "bootloader: cold start"});
        l.add(new String[] {"DEBUG", "package   = " + getPackageName()});
        l.add(new String[] {"DEBUG", "device    = " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL});
        l.add(new String[] {"DEBUG", "board     = " + android.os.Build.BOARD + " / " + android.os.Build.HARDWARE});
        l.add(new String[] {"DEBUG", "android   = " + android.os.Build.VERSION.RELEASE
                + " (API " + android.os.Build.VERSION.SDK_INT + ")"});
        l.add(new String[] {"DEBUG", "kernel    = " + (kernel == null ? "?" : kernel)});
        l.add(new String[] {"DEBUG", "abi       = " + abi});
        l.add(new String[] {"DEBUG", "cpu cores = " + Runtime.getRuntime().availableProcessors()});
        l.add(new String[] {"DEBUG", "heap max  = " + (Runtime.getRuntime().maxMemory() / (1024 * 1024)) + " MB"});
        l.add(new String[] {"DEBUG", "display   = " + dm.widthPixels + "x" + dm.heightPixels
                + " @" + dm.densityDpi + "dpi"});
        l.add(new String[] {"DEBUG", "locale    = " + java.util.Locale.getDefault()});
        l.add(new String[] {"DEBUG", "layout    = " + (wideLayout ? "wide (sidebar)" : "compact (bottom bar)")});
        l.add(new String[] {"BLANK", ""});
        l.add(new String[] {"INFO", "starting subsystems"});
        l.add(new String[] {"OK", "register crash recorder"});
        l.add(new String[] {"DEBUG", "crash log dir = files/"});
        l.add(new String[] {"OK", "init terminal core"});
        l.add(new String[] {"DEBUG", "terminal window = 48 x 140"});
        l.add(new String[] {"OK", "load pty bridge"});
        l.add(new String[] {"DEBUG", "pty: forkpty ready, utf-8"});
        l.add(new String[] {"OK", "load ansi renderer"});
        l.add(new String[] {"DEBUG", "ansi: sgr 16 / 256 / truecolor"});
        l.add(new String[] {"OK", "init quick-reply parser"});
        l.add(new String[] {"DEBUG", "menu pattern compiled"});
        l.add(new String[] {"OK", "build backdrop layers"});
        l.add(new String[] {"DEBUG", "blobs = 3, gradient = 2 stops"});
        l.add(new String[] {"OK", "start glass renderer"});
        l.add(new String[] {"DEBUG", "blur: scale 1/8, radius 3, passes 2"});
        l.add(new String[] {"OK", "init navigation"});
        l.add(new String[] {"DEBUG", "pages = terminal, settings, root, about"});
        l.add(new String[] {"OK", "init network stack"});
        l.add(new String[] {"DEBUG", "tls = https only, timeout 15s"});
        l.add(new String[] {"OK", "resolve script source"});
        l.add(new String[] {"DEBUG", "cache = files/main.sh.cached"});
        l.add(new String[] {"OK", "prepare shizuku / root probe"});
        l.add(new String[] {"OK", "mount user interface"});
        l.add(new String[] {"BLANK", ""});
        l.add(new String[] {"INFO", "all subsystems started"});
        l.add(new String[] {"READY", "MOBAI ready._"});
        return l;
    }

    private View scrolled(LinearLayout page) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(page);
        return sv;
    }

    private void showPage(int index) {
        if (index == currentPage) return;
        final int old = currentPage;
        currentPage = index;
        if (navCompose != null) navCompose.setSelectedIndex(index);
        for (int i = 0; i < pages.length; i++) {
            pages[i].animate().cancel();
            pages[i].setAlpha(1f);
            pages[i].setTranslationX(0f);
            pages[i].setTranslationY(0f);
            if (i != index && i != old) pages[i].setVisibility(View.GONE);
        }
        final View in = pages[index];
        in.setVisibility(View.VISIBLE);
        if (old < 0) return;
        final View out = pages[old];
        float dir = index > old ? 1f : -1f;
        final float offset = dp(28) * dir;
        in.setAlpha(0f);
        if (wideLayout) in.setTranslationY(offset); else in.setTranslationX(offset);
        android.view.animation.DecelerateInterpolator ease = new android.view.animation.DecelerateInterpolator(1.6f);
        in.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(320).setInterpolator(ease)
                .setUpdateListener(a -> { if (navGlass != null) navGlass.refresh(); }).start();
        out.animate().alpha(0f).translationX(wideLayout ? 0f : -offset).translationY(wideLayout ? -offset : 0f)
                .setDuration(220).setInterpolator(ease).withEndAction(() -> {
                    if (currentPage != pages.length && pages[currentPage] != out) {
                        out.setVisibility(View.GONE);
                    }
                    out.setAlpha(1f);
                    out.setTranslationX(0f);
                    out.setTranslationY(0f);
                }).start();
    }

    private void buildUi(boolean playSplash) {
        wideLayout = !floatingNavBottom && getResources().getConfiguration().screenWidthDp >= 600;
        final android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        rootLayout = root;
        root.setBackgroundColor(BG);

        // Content layer: soft gradient backdrop; this is what the glass panels blur.
        android.widget.FrameLayout content = new android.widget.FrameLayout(this);
        content.setBackground(new Backdrop());
        if (wideLayout) content.setPadding(dp(204), 0, 0, 0);
        else if (!floatingNavBottom) content.setPadding(0, 0, 0, dp(94));
        // When floatingNavBottom is on, content is left full-bleed on purpose: the nav
        // bar floats directly on top of it (true overlay), instead of reserving space.
        pages = new View[] {buildTerminalPage(), scrolled(buildSettingsPage()), scrolled(buildRootPage()), scrolled(buildAboutPage())};
        for (View p : pages) {
            content.addView(p, new android.widget.FrameLayout.LayoutParams(-1, -1));
        }
        root.addView(content, new android.widget.FrameLayout.LayoutParams(-1, -1));

        // Java captures the real page pixels; Compose feeds that snapshot to Miuix LayerBackdrop.
        // API 33+ uses Miuix textureBlur, while older Android versions receive a pre-blurred fallback.
        navGlass = new GlassLayout(this, dp(wideLayout ? 28 : 32));
        navGlass.setBlurEnabled(blurEnabled);
        navGlass.setLiquidGlass(liquidGlassEnabled);
        navCompose = new LiquidGlassNavigationView(
                this, Math.max(0, currentPage), wideLayout, blurEnabled, liquidGlassEnabled,
                index -> showPage(index));
        navGlass.setBackdropListener(navCompose::setBackdropBitmap);
        navGlass.setSource(content);
        navGlass.addView(navCompose, new android.widget.FrameLayout.LayoutParams(-1, -1));

        android.widget.FrameLayout.LayoutParams glassLp;
        if (wideLayout) {
            glassLp = new android.widget.FrameLayout.LayoutParams(dp(180), -1, Gravity.START);
            glassLp.setMargins(dp(12), dp(12), 0, dp(12));
        } else {
            // Cap the floating pill's width so it stays a compact capsule instead of
            // stretching edge-to-edge on wide/tablet screens (it only matters there —
            // on a normal phone width the cap never kicks in).
            int screenWidthDp = getResources().getConfiguration().screenWidthDp;
            int maxBarWidthDp = 480;
            if (screenWidthDp - 32 > maxBarWidthDp) {
                glassLp = new android.widget.FrameLayout.LayoutParams(
                        dp(maxBarWidthDp), dp(68), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
                glassLp.setMargins(0, 0, 0, dp(14));
            } else {
                glassLp = new android.widget.FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM);
                glassLp.setMargins(dp(16), 0, dp(16), dp(14));
            }
        }
        root.addView(navGlass, glassLp);

        // Launch animation: computer-style boot log with debug lines (tap to skip).
        if (playSplash) {
            final android.widget.FrameLayout splash = new android.widget.FrameLayout(this);
            splash.setBackgroundColor(0xFF0B0F14);
            splash.setClickable(true);
            final TextView log = label("", 11, 0xFFD6E2EA, false);
            log.setTypeface(Typeface.MONOSPACE);
            log.setLineSpacing(0f, 1.25f);
            log.setPadding(dp(16), dp(44), dp(16), dp(52));
            final ScrollView logScroll = new ScrollView(this);
            logScroll.setVerticalScrollBarEnabled(false);
            logScroll.addView(log);
            splash.addView(logScroll, new android.widget.FrameLayout.LayoutParams(-1, -1));
            TextView hint = label("點擊畫面可跳過", 11, 0xFF6B7A86, false);
            hint.setGravity(Gravity.CENTER);
            splash.addView(hint, new android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
            hint.setPadding(0, 0, 0, dp(18));
            root.addView(splash, new android.widget.FrameLayout.LayoutParams(-1, -1));

            final java.util.List<String[]> lines = buildBootLines();
            final android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
            final java.util.Random random = new java.util.Random();
            final long t0 = android.os.SystemClock.elapsedRealtime();
            final boolean[] done = {false};
            final int[] index = {0};
            final Runnable finish = () -> {
                if (done[0]) return;
                done[0] = true;
                splash.animate().alpha(0f).setDuration(450).withEndAction(() -> root.removeView(splash)).start();
            };
            splash.setOnClickListener(v -> finish.run());
            final Runnable step = new Runnable() {
                @Override
                public void run() {
                    if (done[0]) return;
                    if (index[0] >= lines.size()) {
                        handler.postDelayed(finish, 900);
                        return;
                    }
                    String[] line = lines.get(index[0]++);
                    String level = line[0];
                    String text = line[1];
                    double seconds = (android.os.SystemClock.elapsedRealtime() - t0) / 1000.0;
                    if (!"BLANK".equals(level)) {
                        appendSpan(sb, String.format(java.util.Locale.US, "[%7.3f] ", seconds), 0xFF5E6C78, false);
                    }
                    switch (level) {
                        case "HEAD":
                            appendSpan(sb, text, 0xFFFFFFFF, true);
                            break;
                        case "OK":
                            StringBuilder padded = new StringBuilder(text);
                            while (padded.length() < 30) padded.append('.');
                            appendSpan(sb, "[ INFO ] ", 0xFF7DCFFF, false);
                            appendSpan(sb, padded + " ", 0xFFD6E2EA, false);
                            appendSpan(sb, "[  OK  ]", 0xFF4DFF88, true);
                            break;
                        case "DEBUG":
                            appendSpan(sb, "[DEBUG] ", 0xFF7AA2F7, false);
                            appendSpan(sb, text, 0xFF9AA8B4, false);
                            break;
                        case "INFO":
                            appendSpan(sb, "[ INFO ] ", 0xFF7DCFFF, false);
                            appendSpan(sb, text, 0xFFD6E2EA, false);
                            break;
                        case "READY":
                            appendSpan(sb, text, 0xFF4DFF88, true);
                            break;
                        default:
                            break;
                    }
                    sb.append('\n');
                    log.setText(sb);
                    logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
                    int delay = "OK".equals(level) ? 170 + random.nextInt(130)
                            : 90 + random.nextInt(90);
                    if ("READY".equals(level) || "HEAD".equals(level)) delay = 380;
                    handler.postDelayed(this, delay);
                }
            };
            handler.postDelayed(step, 350);
        }

        setContentView(root);
        showPage(0);
    }

    private void runBuiltInScript() {
        if (scriptRunning) {
            sendInteractiveInput();
            return;
        }
        clearTerminalOutput();
        final String input = inputBox.getText().toString();
        final boolean pty = usePty;
        ptyBox.setEnabled(false);
        runButton.setEnabled(false);
        status.setText("啟動中");
        status.setTextColor(ACCENT);
        appendOutput("▶ 開始運行 MOBAI…\n");
        if (!input.isEmpty()) appendOutput("啟動參數：" + input + "\n");

        executor.execute(() -> {
            File localScript = null;
            long localPtyHandle = 0L;
            Process localProc = null;
            boolean localPtyWaitCompleted = false;
            try {
                // main.sh contains an ELF payload: keep and transfer its raw bytes.
                byte[] scriptBytes = loadScriptBytes();
                if ("shizuku".equals(executionMode)) {
                    IShellUserService service = shizukuShellService;
                    if (service == null) {
                        CountDownLatch latch = userServiceReady;
                        latch.await(10, TimeUnit.SECONDS);
                        service = shizukuShellService;
                    }
                    if (service == null) {
                        throw new IllegalStateException(
                                "Shizuku UserService 尚未連線。請確認 Shizuku 正在執行且已授權，再重試。");
                    }

                    appendOutput("使用 Shizuku 權限運行\n");
                    service.setUsePty(pty);
                    service.beginScript(scriptBytes.length);
                    boolean started = false;
                    try {
                        final int chunkSize = 64 * 1024;
                        for (int offset = 0; offset < scriptBytes.length; offset += chunkSize) {
                            int end = Math.min(scriptBytes.length, offset + chunkSize);
                            service.writeScriptChunk(Arrays.copyOfRange(scriptBytes, offset, end));
                        }
                        // Queue the UI state before start: the first output or exit callback
                        // must never be overwritten by a later "running" state update.
                        runOnUiThread(() -> {
                            inputBox.setText("");
                            setInteractiveMode(true);
                        });
                        service.startScript(input, shellOutputCallback);
                        started = true;
                    } finally {
                        if (!started) {
                            try { service.abortScript(); } catch (Exception ignored) { }
                        }
                    }
                    return;
                }

                localScript = new File(getCacheDir(), "main.sh");
                try (FileOutputStream out = new FileOutputStream(localScript)) {
                    out.write(scriptBytes);
                    out.flush();
                }

                appendOutput("使用 " + ("root".equals(executionMode) ? "root 權限" : "一般權限") + " 運行\n");
                if (pty) {
                    localPtyHandle = startLocalProcess(localScript, input);
                    activePtyHandle = localPtyHandle;
                    final long runningHandle = localPtyHandle;
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    try (InputStream stream = PtyBridge.openInputStream(runningHandle);
                         InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                        char[] buffer = new char[2048];
                        int count;
                        while ((count = reader.read(buffer)) != -1) {
                            if (count > 0) appendOutput(new String(buffer, 0, count));
                        }
                    }
                    int code = PtyBridge.waitFor(runningHandle);
                    localPtyWaitCompleted = true;
                    activePtyHandle = 0L;
                    runOnUiThread(() -> completeScript(code));
                } else {
                    final Process proc = startLocalPipeProcess(localScript, input);
                    localProc = proc;
                    activeProcess = proc;
                    activeProcessInput = proc.getOutputStream();
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    Thread reader = new Thread(() -> {
                        try (InputStream stream = proc.getInputStream();
                             InputStreamReader r = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                            char[] buffer = new char[2048];
                            int count;
                            while ((count = r.read(buffer)) != -1) {
                                if (count > 0) appendOutput(new String(buffer, 0, count));
                            }
                        } catch (Exception ignored) {
                            // Stream closed.
                        }
                    }, "TermiGlow-PipeReader");
                    reader.setDaemon(true);
                    reader.start();
                    int code = proc.waitFor();
                    reader.join(1500);
                    localPtyWaitCompleted = true;
                    activeProcess = null;
                    activeProcessInput = null;
                    runOnUiThread(() -> completeScript(code));
                }
            } catch (Exception e) {
                if (localProc != null && !localPtyWaitCompleted) localProc.destroy();
                activeProcess = null;
                activeProcessInput = null;
                if (localPtyHandle > 0L && !localPtyWaitCompleted) {
                    PtyBridge.terminate(localPtyHandle);
                    try { PtyBridge.waitFor(localPtyHandle); } catch (Exception ignored) { }
                }
                activePtyHandle = 0L;
                String message = describeError(e);
                runOnUiThread(() -> finishWithError(message));
            } finally {
                if (localScript != null && localScript.exists()) localScript.delete();
            }
        });
    }


    /** Shows tap-to-answer buttons when the program is waiting at a numbered menu. */
    private void updateQuickReplies() {
        if (quickBox == null) return;
        String t = recentText.toString();
        int idx = Math.max(t.lastIndexOf("请选择"), t.lastIndexOf("請選擇"));
        boolean waiting = scriptRunning && idx >= 0 && t.indexOf('\n', idx) < 0;
        java.util.LinkedHashMap<String, String> opts = new java.util.LinkedHashMap<>();
        if (waiting) {
            String before = t.substring(Math.max(0, idx - 900), idx);
            java.util.regex.Matcher m = MENU_OPTION_PATTERN.matcher(before);
            while (m.find()) opts.put(m.group(1), m.group(2));
        }
        if (opts.isEmpty()) {
            quickBox.setVisibility(View.GONE);
            lastMenuSig = "";
            return;
        }
        String sig = opts.toString();
        if (sig.equals(lastMenuSig) && quickBox.getVisibility() == View.VISIBLE) return;
        lastMenuSig = sig;
        quickBar.removeAllViews();
        for (java.util.Map.Entry<String, String> e : opts.entrySet()) {
            addQuickChip(e.getKey() + "．" + friendlyOption(e.getValue()), e.getKey(), false);
        }
        addQuickChip("使用預設", "", true);
        quickBox.setVisibility(View.VISIBLE);
    }

    private void addQuickChip(String label, String reply, boolean primary) {
        Button chip = actionButton(label, primary ? ACCENT : Color.WHITE, primary ? Color.WHITE : TEXT);
        chip.setOnClickListener(v -> {
            inputBox.setText(reply);
            sendInteractiveInput();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.rightMargin = dp(8);
        quickBar.addView(chip, lp);
    }

    private String friendlyOption(String raw) {
        if (raw.contains("无后台") || raw.contains("無後台")) {
            if (raw.contains("开启") || raw.contains("開啟")) return "關閉程式時，介面一起關閉（推薦）";
            if (raw.contains("关闭") || raw.contains("關閉")) return "介面留在背景，關閉程式後仍繼續顯示";
        }
        return raw;
    }

    /** Send one line to a running script instead of starting it again. */
    private void sendInteractiveInput() {
        if (!scriptRunning) return;
        final String line = inputBox.getText().toString();
        try {
            if ("shizuku".equals(executionMode)) {
                IShellUserService service = shizukuShellService;
                if (service == null) throw new IllegalStateException("Shizuku UserService 已斷線。");
                service.writeInput(line);
            } else {
                long handle = activePtyHandle;
                OutputStream pipeIn = activeProcessInput;
                if (handle != 0L) {
                    PtyBridge.writeLine(handle, line);
                } else if (pipeIn != null) {
                    pipeIn.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                    pipeIn.flush();
                } else {
                    throw new IllegalStateException("目前沒有可接收輸入的程序。");
                }
            }
            // A real PTY supplies normal terminal echo; do not duplicate the line here.
            inputBox.setText("");
            inputBox.requestFocus();
        } catch (Exception e) {
            appendOutput("\n⚠ 送出失敗：" + describeError(e) + "\n");
        }
    }

    private void setInteractiveMode(boolean running) {
        scriptRunning = running;
        runButton.setEnabled(true);
        if (ptyBox != null) ptyBox.setEnabled(!running);
        if (running) {
            runButton.setText("↵  送出");
            inputLabel.setText("回覆程式的提問");
            inputBox.setHint("輸入選項數字（例如 1），再按「送出」；直接按送出＝使用預設");
            status.setText("運行中");
            status.setTextColor(ACCENT);
        } else {
            runButton.setText("▶  開始運行");
            inputLabel.setText("啟動參數（選填，一般不用填）");
            inputBox.setHint("一般請留空");
        }
    }

    private void completeScript(int exitCode) {
        scriptRunning = false;
        activePtyHandle = 0L;
        appendOutput(exitCode == 0 ? "\n✔ 程式已結束。\n" : "\n⚠ 程式已結束（代碼 " + exitCode + "）。\n");
        updateExitStatus(exitCode);
        setInteractiveMode(false);
    }

    private byte[] readBuiltInScriptBytes() throws Exception {
        try (InputStream in = getAssets().open("main.sh");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    /** Downloads main.sh when a URL is set (falls back to the last download), else uses the bundled copy. */
    private byte[] loadScriptBytes() throws Exception {
        String url = getScriptUrl();
        if (url.isEmpty()) {
            appendOutput("未設定主程式網址，使用內建版本。\n");
            return readBuiltInScriptBytes();
        }
        File cache = new File(getFilesDir(), "main.sh.cached");
        appendOutput("正在下載主程式…\n");
        try {
            if (!url.startsWith("https://")) throw new IllegalStateException("網址必須以 https:// 開頭");
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            int status = conn.getResponseCode();
            if (status != 200) throw new IllegalStateException("伺服器回應 " + status);
            byte[] data;
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16384];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                data = out.toByteArray();
            } finally {
                conn.disconnect();
            }
            if (data.length < 64) throw new IllegalStateException("下載的檔案太小");
            try (FileOutputStream out = new FileOutputStream(cache)) {
                out.write(data);
            }
            appendOutput("✔ 下載完成（" + (data.length / 1024) + " KB）\n");
            return data;
        } catch (Exception e) {
            if (cache.exists()) {
                appendOutput("⚠ 下載失敗（" + describeError(e) + "），改用上次下載的版本。\n");
                try (InputStream in = new java.io.FileInputStream(cache); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[16384];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    return out.toByteArray();
                }
            }
            throw new IllegalStateException("下載主程式失敗：" + describeError(e));
        }
    }

    private int findBytes(byte[] source, byte[] target) {
        if (target.length == 0 || source.length < target.length) return -1;
        outer: for (int i = 0; i <= source.length - target.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (source[i + j] != target[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private Process startLocalPipeProcess(File script, String input) throws Exception {
        String arg = input == null ? "" : input;
        ProcessBuilder builder;
        if ("root".equals(executionMode)) {
            builder = new ProcessBuilder("su", "-c",
                    "/system/bin/sh " + shellQuote(script.getAbsolutePath()) + " " + shellQuote(arg));
        } else {
            builder = new ProcessBuilder("/system/bin/sh", script.getAbsolutePath(), arg);
        }
        builder.directory(getFilesDir());
        builder.redirectErrorStream(true);
        return builder.start();
    }

    private long startLocalProcess(File script, String input) throws Exception {
        // Same as typing `sh main.sh` in MT Manager's terminal: run as the app user inside the PTY.
        // main.sh detects root / su / Shizuku rish by itself and only elevates the ELF launch.
        String command = "exec /system/bin/sh " + shellQuote(script.getAbsolutePath())
                + " " + shellQuote(input == null ? "" : input);
        return PtyBridge.start(command, getFilesDir(), 48, 140);
    }

    private void checkShizukuPermission() {
        if (!Shizuku.pingBinder()) return;
        if (shizukuPermissionRequestPending || shizukuShellService != null
                || userServiceBindInProgress || "shizuku".equals(executionMode)) return;
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                executionMode = "shizuku";
                appendOutput("✔ 已有 Shizuku 授權，正在連線…\n");
                bindShizukuUserService();
            } else {
                shizukuPermissionRequestPending = true;
                appendOutput("正在請求 Shizuku 授權…\n");
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Exception e) {
            shizukuPermissionRequestPending = false;
            appendOutput("Shizuku 無法使用：" + describeError(e) + "\n");
            requestRootFallback();
        }
    }

    private void bindShizukuUserService() {
        if (shizukuShellService != null || userServiceBindInProgress) return;
        try {
            userServiceBindInProgress = true;
            userServiceReady = new CountDownLatch(1);
            userServiceArgs = new Shizuku.UserServiceArgs(
                    new ComponentName(this, ShellUserService.class))
                    // Shizuku API 13.1.5 requires a non-null process-name suffix.
                    .processNameSuffix("mobai_shell")
                    .tag("termiglow-shell-user-service")
                    .version(5)
                    .daemon(false);
            Shizuku.bindUserService(userServiceArgs, userServiceConnection);
            appendOutput("正在連線 Shizuku…\n");
        } catch (Exception e) {
            userServiceBindInProgress = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線失敗：" + describeError(e) + "\n");
            executionMode = rootAvailable ? "root" : "normal";
            requestRootFallback();
        }
    }

    private void requestRootFallback() {
        if (rootFallbackStarted || "shizuku".equals(executionMode)) return;
        rootFallbackStarted = true;
        executor.execute(() -> {
            Process probe = null;
            try {
                probe = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        probe.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line).append('\n');
                }
                int code = probe.waitFor();
                if ("shizuku".equals(executionMode)) return;
                if (code == 0 && result.toString().contains("uid=0")) {
                    rootAvailable = true;
                    executionMode = "root";
                    runOnUiThread(() -> {
                        appendOutput("✔ 已取得 root 授權。\n");
                        updatePrivilegeStatus("root 已就緒");
                    });
                } else {
                    rootAvailable = false;
                    executionMode = "normal";
                    runOnUiThread(() -> {
                        appendOutput("未取得 root，將使用一般權限。\n");
                        updatePrivilegeStatus("一般權限");
                    });
                }
            } catch (Exception e) {
                if ("shizuku".equals(executionMode)) return;
                rootAvailable = false;
                executionMode = "normal";
                runOnUiThread(() -> {
                    appendOutput("此裝置沒有 root，將使用一般權限。\n");
                    updatePrivilegeStatus("一般權限");
                });
            } finally {
                if (probe != null) probe.destroy();
            }
        });
    }

    private int extractExitCode(String transcript) {
        Matcher matcher = EXIT_CODE_PATTERN.matcher(transcript);
        int result = Integer.MIN_VALUE;
        while (matcher.find()) {
            try {
                result = Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return Integer.MIN_VALUE;
            }
        }
        return result;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private String describeError(Throwable error) {
        Throwable deepest = error;
        while (deepest.getCause() != null && deepest.getCause() != deepest) {
            deepest = deepest.getCause();
        }
        String message = deepest.getMessage();
        if (message == null || message.trim().isEmpty()) message = deepest.getClass().getSimpleName();
        return error.getClass().getSimpleName() + ": " + message;
    }

    private void updatePrivilegeStatus(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> updatePrivilegeStatus(text));
            return;
        }
        if (privilegeInfo != null) privilegeInfo.setText(text);
        if (status != null) {
            status.setText("" + text);
            status.setTextColor(ACCENT);
        }
        // Also refresh the GhostLock page status card
        refreshGhostLockStatus();
    }

    private void updateExitStatus(int code) {
        status.setText(code == 0 ? "已完成" : "異常結束 (" + code + ")");
        status.setTextColor(code == 0 ? ACCENT : ERROR);
    }

    private void finishWithError(String message) {
        appendOutput("⚠ " + message + "\n");
        status.setText("發生錯誤");
        status.setTextColor(ERROR);
        setInteractiveMode(false);
        runButton.setEnabled(true);
    }

    /**
     * Queue terminal output and render it in short batches. PTY callbacks can arrive
     * dozens of times per second; updating TextView, menu chips and the glass snapshot
     * for every tiny chunk needlessly overloads the main thread.
     */
    private void appendOutput(String text) {
        if (text == null || text.isEmpty() || activityDestroyed) return;
        synchronized (outputBufferLock) {
            pendingOutput.append(text);
            if (!outputFlushScheduled) {
                outputFlushScheduled = true;
                outputHandler.postDelayed(outputFlushRunnable, OUTPUT_FLUSH_DELAY_MS);
            }
        }
    }

    /** Must run on the main thread. Concatenating before ANSI parsing preserves escape
     * sequences that are split across native read callbacks. */
    private void flushPendingOutput() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            outputHandler.post(this::flushPendingOutput);
            return;
        }

        final String batch;
        synchronized (outputBufferLock) {
            if (pendingOutput.length() == 0) {
                outputFlushScheduled = false;
                return;
            }
            batch = pendingOutput.toString();
            pendingOutput.setLength(0);
            outputFlushScheduled = false;
        }

        if (output == null) return;
        boolean followOutput = isOutputNearBottom();
        CharSequence styled = ansi.feed(batch);
        output.append(styled);
        recentText.append(styled);

        if (recentText.length() > MAX_RECENT_CHARS) {
            recentText.delete(0, recentText.length() - 3_000);
        }

        CharSequence all = output.getText();
        if (all instanceof android.text.Editable && all.length() > MAX_TERMINAL_CHARS) {
            ((android.text.Editable) all).delete(0, all.length() - MAX_TERMINAL_CHARS);
        }

        updateQuickReplies();
        if (navGlass != null) navGlass.refresh();
        if (followOutput && outputScroll != null) {
            outputScroll.post(() -> outputScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    /** Returns true when the reader is already at the end of the terminal. */
    private boolean isOutputNearBottom() {
        if (outputScroll == null || outputScroll.getChildCount() == 0) return true;
        View content = outputScroll.getChildAt(0);
        int remaining = content.getBottom()
                - (outputScroll.getScrollY() + outputScroll.getHeight());
        return remaining <= dp(24);
    }

    /** Clear both rendered and queued output so an old callback cannot reappear later. */
    private void clearTerminalOutput() {
        outputHandler.removeCallbacks(outputFlushRunnable);
        flushPendingOutput();
        synchronized (outputBufferLock) {
            pendingOutput.setLength(0);
            outputFlushScheduled = false;
        }
        if (output != null) output.setText("");
        ansi.reset();
        recentText.setLength(0);
        lastMenuSig = "";
        updateQuickReplies();
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(fg);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        boolean light = bg == Color.WHITE;
        button.setBackground(round(light ? 0xB3FFFFFF : bg, 26, light ? 0xCCFFFFFF : bg, light ? 1 : 0));
        return button;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private GradientDrawable glassBg(int radius) {
        return round(0xB3FFFFFF, radius, 0xCCFFFFFF, 1);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density * uiScale + 0.5f);
    }

    private void saveUiScale(float scale) {
        uiScale = scale;
        getSharedPreferences("mobai_prefs", MODE_PRIVATE).edit().putFloat("ui_scale", scale).apply();
    }

    private void saveBlurEnabled(boolean enabled) {
        blurEnabled = enabled;
        getSharedPreferences("mobai_prefs", MODE_PRIVATE).edit().putBoolean("blur_enabled", enabled).apply();
        if (navGlass != null) navGlass.setBlurEnabled(enabled);
        if (navCompose != null) navCompose.setBlurEnabled(enabled);
    }

    /** Moves the tab bar to a bottom floating pill (even on tablets) that overlaps the page
     *  content instead of reserving space for it. Needs a rebuild since it changes layout. */
    private void saveFloatingNavBottom(boolean enabled) {
        floatingNavBottom = enabled;
        getSharedPreferences("mobai_prefs", MODE_PRIVATE).edit().putBoolean("floating_nav_bottom", enabled).apply();
        recreate();
    }

    private void saveLiquidGlassEnabled(boolean enabled) {
        liquidGlassEnabled = enabled;
        getSharedPreferences("mobai_prefs", MODE_PRIVATE).edit().putBoolean("liquid_glass_enabled", enabled).apply();
        if (navGlass != null) navGlass.setLiquidGlass(enabled);
        if (navCompose != null) navCompose.setLiquidGlassEnabled(enabled);
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        outputHandler.removeCallbacks(outputFlushRunnable);
        flushPendingOutput();
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderListener);
        if (userServiceArgs != null && userServiceBound) {
            try {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true);
            } catch (Exception ignored) {
                // Shizuku may already have been stopped while the Activity was closing.
            }
        }
        long handle = activePtyHandle;
        if (handle > 0L) PtyBridge.terminate(handle);
        Process pipeProc = activeProcess;
        if (pipeProc != null) pipeProc.destroy();
        if (scriptRunning && shizukuShellService != null) {
            try { shizukuShellService.abortScript(); } catch (Exception ignored) { }
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}