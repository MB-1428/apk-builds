package com.example.termiglow;

interface IShellUserService {
    // Reserved transaction used by Shizuku to stop a UserService.
    void destroy() = 16777114;
    void exit() = 1;
    void beginScript(int totalBytes) = 2;
    void writeScriptChunk(in byte[] chunk) = 3;
    String executeScript(String input) = 4;
    void abortScript() = 5;
}
