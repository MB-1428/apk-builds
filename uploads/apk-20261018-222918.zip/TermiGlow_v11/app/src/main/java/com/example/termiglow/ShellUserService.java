package com.example.termiglow;

import android.os.RemoteException;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku UserService. The embedded main.sh is a self-extracting binary file,
 * so it is transferred as raw bytes in small AIDL calls rather than UTF-8 text.
 */
public final class ShellUserService extends IShellUserService.Stub {
    private static final int MAX_OUTPUT_CHARS = 240_000;
    private static final int MAX_SCRIPT_BYTES = 8 * 1024 * 1024;
    private final Object stagingLock = new Object();
    private File stagedScriptFile;
    private OutputStream stagedScriptOutput;
    private int expectedScriptBytes;
    private int writtenScriptBytes;

    public ShellUserService() {
        // Required no-argument constructor for Shizuku UserService.
    }

    @Override
    public void beginScript(int totalBytes) throws RemoteException {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
            if (totalBytes <= 0 || totalBytes > MAX_SCRIPT_BYTES) {
                throw new RemoteException("Invalid built-in script size: " + totalBytes);
            }
            File tempDirectory = new File("/data/local/tmp");
            if (!tempDirectory.isDirectory() || !tempDirectory.canWrite()) {
                throw new RemoteException("Shizuku UserService cannot write /data/local/tmp");
            }
            try {
                stagedScriptFile = File.createTempFile("termiglow-main-", ".sh", tempDirectory);
                stagedScriptOutput = new FileOutputStream(stagedScriptFile);
                expectedScriptBytes = totalBytes;
                writtenScriptBytes = 0;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to stage built-in script: " + e.getMessage());
            }
        }
    }

    @Override
    public void writeScriptChunk(byte[] chunk) throws RemoteException {
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script; beginScript must be called first");
            }
            if (chunk == null || writtenScriptBytes + chunk.length > expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Invalid script chunk length");
            }
            try {
                stagedScriptOutput.write(chunk);
                writtenScriptBytes += chunk.length;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to write script chunk: " + e.getMessage());
            }
        }
    }

    @Override
    public String executeScript(String input) throws RemoteException {
        final File scriptFile;
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script to execute");
            }
            try {
                stagedScriptOutput.close();
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to close staged script: " + e.getMessage());
            }
            stagedScriptOutput = null;
            if (writtenScriptBytes != expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Incomplete script transfer: expected "
                        + expectedScriptBytes + " bytes, received " + writtenScriptBytes);
            }
            scriptFile = stagedScriptFile;
            stagedScriptFile = null;
            expectedScriptBytes = 0;
            writtenScriptBytes = 0;
        }

        Process process = null;
        try {
            ProcessBuilder builder = new ProcessBuilder(
                    "/system/bin/sh", scriptFile.getAbsolutePath(), input == null ? "" : input);
            builder.directory(new File("/"));
            builder.redirectErrorStream(true);
            process = builder.start();

            StringBuilder output = new StringBuilder();
            boolean truncated = false;
            try (InputStream stream = process.getInputStream();
                 InputStreamReader inputStreamReader = new InputStreamReader(stream, StandardCharsets.UTF_8);
                 BufferedReader reader = new BufferedReader(inputStreamReader)) {
                char[] buffer = new char[4096];
                int count;
                while ((count = reader.read(buffer)) != -1) {
                    int room = MAX_OUTPUT_CHARS - output.length();
                    if (room > 0) {
                        output.append(buffer, 0, Math.min(count, room));
                    }
                    if (count > room) truncated = true;
                }
            }

            int exitCode = process.waitFor();
            if (truncated) output.append("\n[output truncated: display limit reached]\n");
            output.append("\n[process exited: ").append(exitCode).append("]\n");
            return output.toString();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroy();
            throw new RemoteException("Shell execution was interrupted: " + e.getMessage());
        } catch (IOException e) {
            throw new RemoteException("Unable to execute staged shell script: " + e.getMessage());
        } finally {
            if (process != null) process.destroy();
            // Script contains the native payload; remove it once it has finished.
            // main.sh's own trap removes its temporary ELF runtime directory.
            if (scriptFile.exists() && !scriptFile.delete()) {
                // Best effort; /data/local/tmp is managed by the device shell.
            }
        }
    }

    @Override
    public void abortScript() {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
        }
    }

    private void clearStagedScriptLocked() {
        if (stagedScriptOutput != null) {
            try { stagedScriptOutput.close(); } catch (IOException ignored) { }
            stagedScriptOutput = null;
        }
        if (stagedScriptFile != null) {
            // Best-effort cleanup of incomplete transfers.
            stagedScriptFile.delete();
            stagedScriptFile = null;
        }
        expectedScriptBytes = 0;
        writtenScriptBytes = 0;
    }

    @Override
    public void exit() {
        abortScript();
        System.exit(0);
    }

    @Override
    public void destroy() {
        exit();
    }
}
