# TermiGlow v1.9 — 白色主題 / Shizuku UserService

本版重點是保留使用者上傳的原始 `main.sh`，不改寫其 Shell 前綴、`PAYLOAD_OFFSET` 或內嵌 ELF。程式從 Android assets 以 `byte[]` 讀取並按原始位元組傳輸，執行前會檢查 ELF magic、偏移量、64-bit little-endian 與 AArch64 `e_machine`，避免再次以一般文字方式處理包含二進位資料的檔案。

## 原始 main.sh 檔案校驗

- 大小：1,528,706 bytes
- SHA-256：`7ebee22da06fcb296059e145d44c3b0d25b89d54fa8b28551dc582f72ecac818`
- ELF payload 起點：8250（0-based byte offset）
- ELF `e_machine`：`b700`（AArch64）
- 專案資產 `app/src/main/assets/main.sh` 與上傳檔案逐位元組一致。

## 改動

- 保留 v1.8 的 Shizuku UserService + AIDL 執行架構，並保留 `.processNameSuffix("termiglow_shell")`。
- 保留白色主題及底部 `$` 輸入列。輸入文字仍作為原始 `main.sh` 的 `$1`。
- 執行前印出 `main.sh` 的大小與 ELF 偏移驗證結果；如資產被意外改寫，會給出明確錯誤而不是盲目執行。
- Android `minSdk 24`。

## 建置

1. 用 Android Studio 開啟此專案，使用 JDK 17。
2. 等待 Gradle Sync。
3. 執行 `assembleDebug` 或在 GitHub Actions 執行 APK workflow。

## 權限與執行環境

- Shizuku UserService 一般以 Android `shell` 身分執行；是否有 root 權限取決於裝置與 Shizuku 的實際執行環境。
- 沒有可用 Shizuku 或 root 時，程式會退回一般 App 權限。原始 `main.sh` 需要其自身所檢查的特權環境，普通 App UID 不等於 root。
- 此執行環境無 Android SDK/Gradle，未在此完成 APK 編譯或手機實測；建置成功後仍需在裝置上驗證。
