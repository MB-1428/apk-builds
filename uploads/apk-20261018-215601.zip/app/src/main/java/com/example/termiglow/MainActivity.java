package com.example.termiglow;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 14, 24);
    private final int PANEL = Color.rgb(14, 27, 43);
    private final int GREEN = Color.rgb(39, 230, 166);
    private final int WHITE = Color.rgb(226, 239, 250);
    private final int MUTED = Color.rgb(133, 158, 181);
    private EditText inputBox;
    private TextView output, status;
    private Button runButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile Process activeProcess;
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private volatile String executionMode = "normal";
    private boolean privilegeFlowStarted = false;

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener =
            (requestCode, grantResult) -> {
                if (requestCode != SHIZUKU_REQUEST_CODE) return;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    executionMode = "shizuku";
                    appendOutput("[permission] Shizuku 已授權，將使用 Shizuku 執行內置腳本。\n");
                    updatePrivilegeStatus("SHIZUKU READY");
                } else {
                    appendOutput("[permission] Shizuku 權限未授予，改為嘗試申請 root。\n");
                    requestRootFallback();
                }
            };

    private final Shizuku.OnBinderReceivedListener shizukuBinderListener =
            () -> runOnUiThread(this::checkShizukuPermission);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        appendOutput("TermiGlow v1.3  •  Built-in Shell\n");
        appendOutput("只會執行 App 內置的 main.sh。\n");
        appendOutput("在輸入框輸入內容，再按「執行內置腳本」。\n\n");
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!privilegeFlowStarted) {
                privilegeFlowStarted = true;
                appendOutput("[permission] 未偵測到 Shizuku 服務，嘗試申請 root；若裝置沒有 root，會退回一般權限。\n");
                requestRootFallback();
            }
        }, 1500);
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(14), dp(18), dp(12));
        page.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label(">_", 24, GREEN, true);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(PANEL, 14, GREEN, 1));
        header.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(label("TermiGlow", 22, WHITE, true));
        titles.addView(label("BUILT-IN SHELL WORKSPACE", 10, MUTED, true));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(label("● READY", 11, GREEN, true));
        page.addView(header);

        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(24);
        page.addView(label("你的行動終端", 19, WHITE, true), introLp);
        page.addView(label("只執行內置腳本 · 輸入參數 · 即時輸出", 12, MUTED, false));

        TextView inputLabel = label("INPUT", 11, GREEN, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(22);
        page.addView(inputLabel, labelLp);

        inputBox = new EditText(this);
        inputBox.setTextSize(14);
        inputBox.setSingleLine(false);
        inputBox.setMinLines(2);
        inputBox.setMaxLines(4);
        inputBox.setGravity(Gravity.TOP | Gravity.START);
        inputBox.setTypeface(Typeface.MONOSPACE);
        inputBox.setTextColor(WHITE);
        inputBox.setHintTextColor(MUTED);
        inputBox.setHint("在這裡輸入要傳給腳本的內容…");
        inputBox.setPadding(dp(14), dp(13), dp(14), dp(13));
        inputBox.setBackground(round(PANEL, 14, Color.rgb(34, 58, 79), 1));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, dp(100));
        inputLp.topMargin = dp(8);
        page.addView(inputBox, inputLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, -2);
        actionsLp.topMargin = dp(12);
        page.addView(actions, actionsLp);
        runButton = actionButton("▶  執行內置腳本", GREEN, BG);
        actions.addView(runButton, new LinearLayout.LayoutParams(0, dp(48), 1.25f));
        Button clear = actionButton("清除輸出", PANEL, WHITE);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, dp(48), 1);
        clearLp.leftMargin = dp(9);
        actions.addView(clear, clearLp);

        LinearLayout outHeader = new LinearLayout(this);
        outHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ohp = new LinearLayout.LayoutParams(-1, -2);
        ohp.topMargin = dp(22);
        page.addView(outHeader, ohp);
        outHeader.addView(label("TERMINAL OUTPUT", 11, GREEN, true), new LinearLayout.LayoutParams(0, -2, 1));
        status = label("● IDLE", 10, MUTED, true);
        outHeader.addView(status);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(round(Color.rgb(3, 8, 14), 14, Color.rgb(29, 49, 66), 1));
        output = label("", 12, GREEN, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(14), dp(14), dp(14), dp(14));
        output.setTextIsSelectable(true);
        scroll.addView(output);
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(10);
        page.addView(scroll, outLp);

        TextView footer = label("本機執行環境  •  不提供 root 權限", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(12);
        page.addView(footer, footerLp);

        runButton.setOnClickListener(v -> runBuiltInScript());
        clear.setOnClickListener(v -> output.setText(""));
        setContentView(page);
    }

    private void runBuiltInScript() {
        final String input = inputBox.getText().toString();
        runButton.setEnabled(false);
        status.setText("● RUNNING");
        status.setTextColor(GREEN);
        appendOutput("\n$ [run built-in main.sh]\n");
        executor.execute(() -> {
            File script = new File(getCacheDir(), "main.sh");
            try (InputStream in = getAssets().open("main.sh");
                 FileOutputStream out = new FileOutputStream(script)) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            } catch (Exception e) {
                final String msg = e.toString();
                runOnUiThread(() -> finishWithError(msg));
                return;
            }

            try {
                activeProcess = startBuiltInProcess(script, input);
                BufferedReader reader = new BufferedReader(new InputStreamReader(activeProcess.getInputStream(), "UTF-8"));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String lineOut = line;
                    runOnUiThread(() -> appendOutput(lineOut + "\n"));
                }
                int code = activeProcess.waitFor();
                runOnUiThread(() -> {
                    appendOutput("\n[process exited: " + code + "]\n");
                    status.setText(code == 0 ? "● SUCCESS" : "● EXIT " + code);
                    status.setTextColor(code == 0 ? GREEN : Color.rgb(255, 111, 120));
                    runButton.setEnabled(true);
                });
            } catch (Exception e) {
                final String msg = e.toString();
                runOnUiThread(() -> finishWithError(msg));
            } finally {
                activeProcess = null;
            }
        });
    }

    private void checkShizukuPermission() {
        if (privilegeFlowStarted && !"normal".equals(executionMode)) return;
        privilegeFlowStarted = true;
        try {
            if (!Shizuku.pingBinder()) {
                requestRootFallback();
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                executionMode = "shizuku";
                appendOutput("[permission] Shizuku 權限已存在。\n");
                updatePrivilegeStatus("SHIZUKU READY");
            } else {
                appendOutput("[permission] 正在請求 Shizuku 權限…\n");
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Exception e) {
            appendOutput("[permission] Shizuku 無法使用：" + e + "\n");
            requestRootFallback();
        }
    }

    private void requestRootFallback() {
        executor.execute(() -> {
            Process probe = null;
            try {
                probe = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(probe.getInputStream(), "UTF-8"));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) result.append(line).append('\n');
                int code = probe.waitFor();
                if (code == 0 && result.toString().contains("uid=0")) {
                    executionMode = "root";
                    runOnUiThread(() -> {
                        appendOutput("[permission] 已取得 root 授權。請只執行你信任的內置腳本。\n");
                        updatePrivilegeStatus("ROOT READY");
                    });
                } else {
                    executionMode = "normal";
                    runOnUiThread(() -> {
                        appendOutput("[permission] 未取得 root；將以一般 Android 權限執行。\n");
                        updatePrivilegeStatus("NORMAL MODE");
                    });
                }
            } catch (Exception e) {
                executionMode = "normal";
                runOnUiThread(() -> {
                    appendOutput("[permission] 裝置未提供可用的 su/root；使用一般權限。\n");
                    updatePrivilegeStatus("NORMAL MODE");
                });
            } finally {
                if (probe != null) probe.destroy();
            }
        });
    }

    private Process startBuiltInProcess(File script, String input) throws Exception {
        if ("shizuku".equals(executionMode)) {
            if (!Shizuku.pingBinder()
                    || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                executionMode = "normal";
                appendOutput("[permission] Shizuku 服務不可用，這次改用一般權限。\n");
            } else {
                appendOutput("[mode] Shizuku\n");
                return startShizukuProcess(
                        new String[]{"/system/bin/sh", script.getAbsolutePath(), input},
                        getFilesDir().getAbsolutePath());
            }
        }
        if ("root".equals(executionMode)) {
            appendOutput("[mode] root（已由系統 su 授權）\n");
            String command = "/system/bin/sh " + shellQuote(script.getAbsolutePath())
                    + " " + shellQuote(input);
            ProcessBuilder pb = new ProcessBuilder("su", "-c", command);
            pb.directory(getFilesDir());
            pb.redirectErrorStream(true);
            return pb.start();
        }
        appendOutput("[mode] Android 一般權限\n");
        ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", script.getAbsolutePath(), input);
        pb.directory(getFilesDir());
        pb.redirectErrorStream(true);
        return pb.start();
    }

    /**
     * Shizuku API 13.1.5 marks newProcess as private, so direct Java calls do not compile.
     * Invoke the existing API method reflectively to retain compatibility with this pinned API.
     */
    private Process startShizukuProcess(String[] command, String workingDirectory) throws Exception {
        java.lang.reflect.Method method = Shizuku.class.getDeclaredMethod(
                "newProcess", String[].class, String[].class, String.class);
        method.setAccessible(true);
        Object result = method.invoke(null, new Object[]{command, null, workingDirectory});
        if (!(result instanceof Process)) {
            throw new IllegalStateException("Shizuku newProcess did not return a Process");
        }
        return (Process) result;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private void updatePrivilegeStatus(String text) {
        if (status != null) {
            status.setText("● " + text);
            status.setTextColor(GREEN);
        }
    }

    private void finishWithError(String message) {
        appendOutput("[error] " + message + "\n");
        status.setText("● ERROR");
        status.setTextColor(Color.rgb(255, 111, 120));
        runButton.setEnabled(true);
    }

    private void appendOutput(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> appendOutput(text));
            return;
        }
        output.append(text);
        if (output.getParent() instanceof ScrollView) {
            ScrollView scroll = (ScrollView) output.getParent();
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(fg);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(bg, 13, bg == GREEN ? GREEN : Color.rgb(37, 61, 82), 1));
        return b;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderListener);
        super.onDestroy();
        if (activeProcess != null) activeProcess.destroy();
        executor.shutdownNow();
    }
}
