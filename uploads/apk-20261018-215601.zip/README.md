# TermiGlow v6 — Shizuku / Root 內置 Shell 執行器

這個版本只執行 App 內置的 `app/src/main/assets/main.sh`，不提供路徑選擇或執行外部 `.sh` 的功能。

## 系統需求
- 最低 Android 7.0（API 24）。Shizuku API 13.1.5 的最低版本要求為 API 24。

## 使用方式
1. 用 Android Studio 開啟此資料夾。
2. 使用 JDK 17，等待 Gradle Sync。
3. 連接 Android 手機或啟動模擬器，按 Run。
4. 在輸入框輸入文字，按「執行內置腳本」。
5. 下方終端會顯示內置腳本輸出。

輸入框的文字會作為第一個參數傳給內置腳本，也就是 `$1`。

## 限制
- 使用 Android `/system/bin/sh`，不需要 root。
- 不是完整 Linux 環境；依賴 Bash、apt、sudo 或額外程式的腳本不一定能執行。
- 此專案尚未在實際 Android Studio/裝置上編譯驗證。

## 啟動時權限流程
- 啟動時先偵測 Shizuku 服務並請求 App 的 Shizuku 授權。
- 如果 Shizuku 未運行、不可用或使用者拒絕授權，App 會嘗試執行 `su -c id`，由裝置的 root 管理器決定是否顯示授權提示。
- 若裝置沒有 root 或授權失敗，會退回 Android 一般權限模式。
- Shizuku 必須先由使用者自行安裝並啟動服務；App 無法自行替使用者開啟 Shizuku 服務。
- Root/Shizuku 權限會提升腳本能力，請只執行你自己檢查並信任的內置腳本。


### v1.5 build fix
- Fixed Java compilation failure caused by direct access to Shizuku API 13.1.5 `newProcess` (private visibility) by invoking the method reflectively. This avoids the compile-time access error; runtime behavior still needs testing on a device with Shizuku running and permission granted.
