# TermiGlow v1.6 — 白色主題 / Shizuku UserService

這個版本修正舊版透過反射呼叫 Shizuku `newProcess()` 而在執行時出現 `InvocationTargetException` 的問題。現在使用 Shizuku 官方建議的 `UserService` + AIDL 架構，不再反射呼叫 `private` API。

## 主要改動
- 改用官方 `Shizuku.bindUserService()` 和 AIDL 遠端介面執行內置腳本。
- 白色背景、淺色面板、深色文字。
- 終端輸出移到主要區域；輸入框移至最下方，左側顯示 `$` 提示符。
- 保留啟動時申請 Shizuku 權限；Shizuku 不可用或授權被拒時嘗試 `su`，失敗則退回一般權限。
- `minSdk 24`，最低 Android 7.0。

## 建置
1. 用 Android Studio 開啟專案。
2. 使用 JDK 17，等待 Gradle Sync。
3. 執行 `assembleDebug` 或透過 GitHub Actions 建置 APK。

## 使用方式
1. 開啟 App 並授予 Shizuku 權限（若使用 Shizuku）。
2. 在終端輸出區下方的 `$` 輸入列輸入參數。
3. 按「執行內置腳本」。輸入文字會作為內置 `main.sh` 的 `$1`。

## 限制和安全
- App 只執行 `app/src/main/assets/main.sh`，不提供任意外部腳本路徑。
- Shizuku 以 shell 身分啟動時，通常是 UID 2000；只有 Shizuku 後端本身以 root 身分啟動時，UserService 才會以 root 執行。Shizuku 授權不代表一定有 root。
- 若裝置沒有 Shizuku 或可用的 root，會退回 Android 一般權限模式。
- 本專案尚未在實際 Android 裝置上測試；請用 GitHub Actions/Android Studio 建置確認。如果還有錯誤，請提供新日誌中的第一個 `error:`。
