package com.example.termiglow;

interface IShellUserService {
    // Reserved transaction used by Shizuku to stop a UserService.
    void destroy() = 16777114;
    void exit() = 1;
    String runScript(String scriptText, String input) = 2;
}
