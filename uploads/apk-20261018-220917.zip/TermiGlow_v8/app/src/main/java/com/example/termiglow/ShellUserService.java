package com.example.termiglow;

import android.os.RemoteException;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku UserService process. Shizuku launches this class as shell (ADB-started
 * service) or root (root-started service). All commands here are sourced from
 * the application's built-in main.sh asset, not from arbitrary paths.
 */
public final class ShellUserService extends IShellUserService.Stub {
    private static final int MAX_OUTPUT_CHARS = 240_000;

    public ShellUserService() {
        // Required no-argument constructor for Shizuku UserService.
    }

    @Override
    public String runScript(String scriptText, String input) throws RemoteException {
        Process process = null;
        try {
            // Feed the fixed, bundled script through stdin. Passing input as an
            // argv entry keeps it a single positional parameter and avoids shell quoting bugs.
            ProcessBuilder builder = new ProcessBuilder(
                    "/system/bin/sh", "-s", "--", input == null ? "" : input);
            builder.directory(new File("/"));
            builder.redirectErrorStream(true);
            process = builder.start();

            try (OutputStream stdin = process.getOutputStream()) {
                stdin.write((scriptText == null ? "" : scriptText).getBytes(StandardCharsets.UTF_8));
            }

            StringBuilder output = new StringBuilder();
            boolean truncated = false;
            try (InputStream stream = process.getInputStream();
                 InputStreamReader inputStreamReader = new InputStreamReader(stream, StandardCharsets.UTF_8);
                 BufferedReader reader = new BufferedReader(inputStreamReader)) {
                char[] buffer = new char[4096];
                int count;
                while ((count = reader.read(buffer)) != -1) {
                    int room = MAX_OUTPUT_CHARS - output.length();
                    if (room > 0) {
                        output.append(buffer, 0, Math.min(count, room));
                    }
                    if (count > room) truncated = true;
                }
            }

            int exitCode = process.waitFor();
            if (truncated) output.append("\n[output truncated: display limit reached]\n");
            output.append("\n[process exited: ").append(exitCode).append("]\n");
            return output.toString();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RemoteException("Shell execution was interrupted: " + e.getMessage());
        } catch (IOException e) {
            throw new RemoteException("Unable to execute built-in shell script: " + e.getMessage());
        } finally {
            if (process != null) process.destroy();
        }
    }

    @Override
    public void exit() {
        System.exit(0);
    }

    @Override
    public void destroy() {
        exit();
    }
}
