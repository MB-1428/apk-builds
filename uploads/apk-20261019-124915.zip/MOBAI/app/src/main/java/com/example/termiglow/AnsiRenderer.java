package com.example.termiglow;

import android.graphics.Color;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

/**
 * Converts raw PTY text (with ANSI/VT escape sequences) into styled text.
 * - SGR colors (16 / 256 / truecolor) and bold become spans.
 * - Other control sequences (cursor movement, erase, OSC titles...) are dropped.
 * - Sequences split across read chunks are buffered until complete.
 * Colors are darkened when too bright so they stay readable on the white theme.
 */
final class AnsiRenderer {
    private static final int[] BASE16 = {
            0x000000, 0xcd3131, 0x0d8f3c, 0x949800, 0x1f5fd1, 0xbc3fbc, 0x0e8a9c, 0x555555,
            0x666666, 0xe0463e, 0x16a34a, 0xb08a00, 0x2f6fe0, 0xd946d9, 0x0891b2, 0x1e293b
    };

    private final StringBuilder pending = new StringBuilder();
    private int fg = 0;          // 0 = default (TextView color)
    private boolean bold = false;
    private boolean lastWasCr = false;

    void reset() {
        pending.setLength(0);
        fg = 0;
        bold = false;
        lastWasCr = false;
    }

    CharSequence feed(String chunk) {
        String data;
        if (pending.length() > 0) {
            data = pending.append(chunk).toString();
            pending.setLength(0);
        } else {
            data = chunk;
        }
        SpannableStringBuilder out = new SpannableStringBuilder();
        StringBuilder run = new StringBuilder();
        int n = data.length();
        int i = 0;
        while (i < n) {
            char c = data.charAt(i);
            if (c == '\u001b') {
                if (i + 1 >= n) { pending.append(data, i, n); break; }
                char k = data.charAt(i + 1);
                if (k == '[') {
                    int j = i + 2;
                    while (j < n && (data.charAt(j) < 0x40 || data.charAt(j) > 0x7e)) j++;
                    if (j >= n) { pending.append(data, i, n); break; }
                    flush(out, run);
                    if (data.charAt(j) == 'm') applySgr(data.substring(i + 2, j));
                    i = j + 1;
                } else if (k == ']') {
                    int j = i + 2;
                    int end = -1;
                    while (j < n) {
                        char d = data.charAt(j);
                        if (d == '\u0007') { end = j + 1; break; }
                        if (d == '\u001b' && j + 1 < n && data.charAt(j + 1) == '\\') { end = j + 2; break; }
                        j++;
                    }
                    if (end < 0) { pending.append(data, i, n); break; }
                    i = end;
                } else {
                    i += 2; // two-character escape, e.g. ESC ( B or ESC =
                    if ((k == '(' || k == ')') && i < n) i++;
                }
                continue;
            }
            i++;
            if (c == '\r') { lastWasCr = true; continue; }
            if (c == '\n') { run.append('\n'); lastWasCr = false; continue; }
            if (c == '\u0007' || c == '\u0000') continue;
            if (c < 0x20 && c != '\t') continue;
            lastWasCr = false;
            run.append(c);
        }
        flush(out, run);
        return out;
    }

    private void flush(SpannableStringBuilder out, StringBuilder run) {
        if (run.length() == 0) return;
        int start = out.length();
        out.append(run);
        int end = out.length();
        if (fg != 0) out.setSpan(new ForegroundColorSpan(fg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) out.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        run.setLength(0);
    }

    private void applySgr(String params) {
        if (params.isEmpty()) { fg = 0; bold = false; return; }
        String[] p = params.split("[;:]", -1);
        for (int i = 0; i < p.length; i++) {
            int v = parse(p[i]);
            if (v == 0) { fg = 0; bold = false; }
            else if (v == 1) bold = true;
            else if (v == 22) bold = false;
            else if (v >= 30 && v <= 37) fg = fit(BASE16[v - 30]);
            else if (v >= 90 && v <= 97) fg = fit(BASE16[v - 90 + 8]);
            else if (v == 39) fg = 0;
            else if (v == 38 || v == 48) {
                boolean isFg = v == 38;
                if (i + 1 < p.length) {
                    int mode = parse(p[i + 1]);
                    if (mode == 2 && i + 4 < p.length) {
                        int color = fit(Color.rgb(clamp(parse(p[i + 2])), clamp(parse(p[i + 3])),
                                clamp(parse(p[i + 4]))));
                        if (isFg) fg = color;
                        i += 4;
                    } else if (mode == 5 && i + 2 < p.length) {
                        if (isFg) fg = fit(xterm256(parse(p[i + 2])));
                        i += 2;
                    } else {
                        i += 1;
                    }
                }
            }
            // background colors and other attributes are ignored on the white theme
        }
    }

    private static int parse(String s) {
        if (s.isEmpty()) return 0;
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return 0; }
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    private static int xterm256(int n) {
        n = clamp(n);
        if (n < 16) return BASE16[n] | 0xff000000;
        if (n >= 232) { int g = 8 + (n - 232) * 10; return Color.rgb(g, g, g); }
        n -= 16;
        int[] lv = {0, 95, 135, 175, 215, 255};
        return Color.rgb(lv[n / 36], lv[(n / 6) % 6], lv[n % 6]);
    }

    /** Darken colors that would be hard to read on a white background. */
    private static int fit(int color) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        for (int k = 0; k < 12 && luminance(r, g, b) > 0.42; k++) {
            r = r * 88 / 100; g = g * 88 / 100; b = b * 88 / 100;
        }
        return Color.rgb(r, g, b);
    }

    private static double luminance(int r, int g, int b) {
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
    }
}
