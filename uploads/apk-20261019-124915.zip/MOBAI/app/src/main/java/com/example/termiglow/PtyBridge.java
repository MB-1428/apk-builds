package com.example.termiglow;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Small native PTY bridge. Unlike ProcessBuilder pipes, this allocates a real
 * pseudo-terminal so programs that check isatty(), read /dev/tty, or buffer
 * prompts differently when stdout is redirected behave like they do in MT.
 */
final class PtyBridge {
    private static final int NATIVE_EOF = -100000;
    private static final Throwable LOAD_FAILURE;

    static {
        Throwable failure = null;
        try {
            System.loadLibrary("termiglowpty");
        } catch (Throwable error) {
            failure = error;
        }
        LOAD_FAILURE = failure;
    }

    private PtyBridge() { }

    static long start(String command, File directory, int rows, int columns) throws IOException {
        ensureLoaded();
        if (command == null || command.trim().isEmpty()) {
            throw new IOException("PTY command is empty");
        }
        String workingDirectory = directory == null ? "/" : directory.getAbsolutePath();
        long handle;
        try {
            handle = nativeStart(command, workingDirectory, rows, columns);
        } catch (LinkageError error) {
            throw new IOException("Native PTY could not start: " + error.getMessage(), error);
        }
        if (handle <= 0L) {
            throw new IOException("Could not allocate PTY (errno=" + (-handle) + ")");
        }
        return handle;
    }

    static InputStream openInputStream(long handle) throws IOException {
        ensureLoaded();
        if (handle <= 0L) throw new IOException("Invalid PTY handle");
        return new InputStream() {
            private boolean closed;
            private final byte[] oneByte = new byte[1];

            @Override
            public int read() throws IOException {
                int count = read(oneByte, 0, 1);
                return count == -1 ? -1 : oneByte[0] & 0xff;
            }

            @Override
            public int read(byte[] buffer, int offset, int length) throws IOException {
                if (buffer == null) throw new NullPointerException("buffer");
                if (offset < 0 || length < 0 || length > buffer.length - offset) {
                    throw new IndexOutOfBoundsException();
                }
                if (length == 0) return 0;
                if (closed) return -1;
                int result = nativeRead(handle, buffer, offset, length);
                if (result == NATIVE_EOF) return -1;
                if (result < 0) {
                    throw new IOException("PTY read failed (errno=" + (-result) + ")");
                }
                return result;
            }

            @Override
            public void close() {
                // The PTY master stays open until waitFor() reaps the child.
                closed = true;
            }
        };
    }

    static void writeLine(long handle, String text) throws IOException {
        ensureLoaded();
        if (handle <= 0L) throw new IOException("No active PTY");
        String value = text == null ? "" : text;
        if (!value.endsWith("\n")) value += "\n";
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        int result = nativeWrite(handle, bytes, 0, bytes.length);
        if (result < 0) throw new IOException("PTY write failed (errno=" + (-result) + ")");
        if (result != bytes.length) throw new IOException("PTY accepted only " + result + " of " + bytes.length + " bytes");
    }

    static void sendEof(long handle) throws IOException {
        ensureLoaded();
        if (handle <= 0L) return;
        byte[] eof = new byte[] { 4 };
        int result = nativeWrite(handle, eof, 0, eof.length);
        if (result < 0) throw new IOException("PTY EOF send failed (errno=" + (-result) + ")");
    }

    static int waitFor(long handle) throws IOException {
        ensureLoaded();
        if (handle <= 0L) throw new IOException("Invalid PTY handle");
        int result = nativeWaitFor(handle);
        if (result < 0) throw new IOException("PTY wait failed (errno=" + (-result) + ")");
        return result;
    }

    static void terminate(long handle) {
        if (handle <= 0L || LOAD_FAILURE != null) return;
        try {
            nativeTerminate(handle);
        } catch (Throwable ignored) {
            // Best effort during Activity/service teardown.
        }
    }

    private static void ensureLoaded() throws IOException {
        if (LOAD_FAILURE != null) {
            throw new IOException("Built-in PTY library failed to load: "
                    + LOAD_FAILURE.getClass().getSimpleName() + ": "
                    + (LOAD_FAILURE.getMessage() == null ? "unknown error" : LOAD_FAILURE.getMessage()),
                    LOAD_FAILURE);
        }
    }

    private static native long nativeStart(String command, String workingDirectory,
                                           int rows, int columns);
    private static native int nativeRead(long handle, byte[] buffer, int offset, int length);
    private static native int nativeWrite(long handle, byte[] buffer, int offset, int length);
    private static native int nativeWaitFor(long handle);
    private static native void nativeTerminate(long handle);
}
