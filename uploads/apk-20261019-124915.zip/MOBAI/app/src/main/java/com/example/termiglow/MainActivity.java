package com.example.termiglow;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    // Light theme palette.
    private static final int BG = Color.rgb(247, 247, 247);
    private static final int PANEL = Color.rgb(232, 232, 232);
    private static final int ACCENT = Color.rgb(37, 99, 235);
    private static final int TEXT = Color.rgb(24, 24, 27);
    private static final int MUTED = Color.rgb(113, 113, 122);
    private static final int BORDER = Color.rgb(232, 232, 232);
    private static final int ERROR = Color.rgb(220, 38, 38);

    private EditText inputBox;
    private TextView inputLabel;
    private TextView output;
    private TextView status;
    private Button runButton;
    private ScrollView outputScroll;
    private final AnsiRenderer ansi = new AnsiRenderer();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile long activePtyHandle;
    // Default = PTY run as the app user, exactly like MT Manager's terminal; main.sh finds su/rish itself.
    private volatile boolean usePty = true;
    private volatile Process activeProcess;
    private volatile OutputStream activeProcessInput;
    private android.widget.Switch ptyBox;
    private TextView privilegeInfo;
    private LinearLayout quickBox;
    private LinearLayout quickBar;
    private String lastMenuSig = "";
    private final StringBuilder recentText = new StringBuilder();
    private LinearLayout[] pages;
    private LinearLayout[] navItems;
    private volatile boolean scriptRunning = false;
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private volatile String executionMode = "normal";
    private volatile boolean shizukuPermissionRequestPending = false;
    private volatile boolean rootFallbackStarted = false;
    private volatile boolean rootAvailable = false;
    private volatile boolean userServiceBindInProgress = false;
    private volatile boolean userServiceBound = false;
    private volatile IShellUserService shizukuShellService;
    private volatile CountDownLatch userServiceReady = new CountDownLatch(1);
    private Shizuku.UserServiceArgs userServiceArgs;

    private final IShellOutputCallback shellOutputCallback = new IShellOutputCallback.Stub() {
        @Override
        public void onOutput(String text) {
            appendOutput(text);
        }

        @Override
        public void onExit(int exitCode) {
            runOnUiThread(() -> completeScript(exitCode));
        }

        @Override
        public void onError(String message) {
            appendOutput("\n⚠ 輸出中斷：" + message + "\n");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener =
            (requestCode, grantResult) -> {
                if (requestCode != SHIZUKU_REQUEST_CODE) return;
                shizukuPermissionRequestPending = false;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    executionMode = "shizuku";
                    appendOutput("✔ 已取得 Shizuku 授權，正在連線…\n");
                    updatePrivilegeStatus("Shizuku 連線中");
                    bindShizukuUserService();
                } else {
                    appendOutput("未授權 Shizuku，改為嘗試 root。\n");
                    requestRootFallback();
                }
            };

    private final Shizuku.OnBinderReceivedListener shizukuBinderListener =
            () -> runOnUiThread(this::checkShizukuPermission);

    private final ServiceConnection userServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuShellService = IShellUserService.Stub.asInterface(service);
            userServiceBindInProgress = false;
            userServiceBound = true;
            userServiceReady.countDown();
            appendOutput("✔ Shizuku 已連線。\n");
            updatePrivilegeStatus("Shizuku 已就緒");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            shizukuShellService = null;
            userServiceBindInProgress = false;
            userServiceBound = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線中斷。\n");
            updatePrivilegeStatus("Shizuku 已中斷");
        }
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        int uiFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);

        installCrashRecorder();
        try {
            buildUi();
        } catch (Throwable t) {
            showFatalScreen("介面建立失敗", t);
            return;
        }
        showLastCrashIfAny();
        appendOutput("歡迎使用 MOBAI\n\n"
                + "使用步驟\n"
                + "① 按下方「開始運行」\n"
                + "② 出現選項時，點上方的按鈕即可\n"
                + "③ 看到「配置完成」，介面就會出現\n\n"
                + "小提示：若介面沒出現，可到左側「設置」更改運行方式後再試。\n\n");

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (shizukuShellService != null || shizukuPermissionRequestPending
                    || "shizuku".equals(executionMode)) return;
            if (Shizuku.pingBinder()) {
                checkShizukuPermission();
            } else {
                appendOutput("未偵測到 Shizuku，改為嘗試 root；沒有 root 會使用一般權限。\n");
                requestRootFallback();
            }
        }, 1500);
    }


    // ---- crash recorder: lets a non-developer see why the app closed ----
    private File crashFile() {
        return new File(getFilesDir(), "last_crash.txt");
    }

    private static String stackToString(Throwable t) {
        java.io.StringWriter sw = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(sw));
        return sw.toString();
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        final File file = crashFile();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
                out.write(("線程：" + thread.getName() + "\n" + stackToString(error))
                        .getBytes(StandardCharsets.UTF_8));
            } catch (Throwable ignored) {
                // Best effort only.
            }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private void showLastCrashIfAny() {
        File file = crashFile();
        if (!file.exists()) return;
        String text;
        try (java.io.FileInputStream in = new java.io.FileInputStream(file)) {
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
            text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return;
        }
        file.delete();
        TextView body = label(text, 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(8), dp(16), dp(8));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new android.app.AlertDialog.Builder(this)
                .setTitle("上次閃退的原因（可長按複製後貼給開發者）")
                .setView(scroll)
                .setPositiveButton("知道了", null)
                .show();
    }

    private void showFatalScreen(String title, Throwable t) {
        TextView body = label(title + "\n\n" + stackToString(t), 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(24), dp(16), dp(16));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.addView(body);
        setContentView(scroll);
    }

    private LinearLayout buildTerminalPage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));
        page.setBackgroundColor(BG);

        // Title row: large title on the left, clear pill on the right.
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(label("MOBAI", 30, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = actionButton("清除", Color.WHITE, TEXT);
        clear.setElevation(dp(1));
        titleRow.addView(clear, new LinearLayout.LayoutParams(dp(76), dp(40)));
        page.addView(titleRow);

        // Status card, styled like a list item.
        LinearLayout item = new LinearLayout(this);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(14), dp(12), dp(16), dp(12));
        item.setBackground(round(Color.WHITE, 22, Color.WHITE, 0));
        item.setElevation(dp(1));
        TextView icon = label(">_", 17, Color.WHITE, true);
        icon.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(Color.rgb(39, 39, 42), 14, Color.rgb(39, 39, 42), 0));
        item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(14), 0, dp(8), 0);
        names.addView(label("MOBAI 主程式", 16, TEXT, true));
        names.addView(label("按下方「開始運行」即可啟動", 12, MUTED, false));
        item.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("待命", 10, MUTED, true);
        status.setGravity(Gravity.END);
        item.addView(status, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
        itemLp.topMargin = dp(16);
        page.addView(item, itemLp);

        // Terminal card.
        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(round(Color.WHITE, 22, Color.WHITE, 0));
        outputScroll.setElevation(dp(1));
        output = label("", 11, TEXT, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(16), dp(16), dp(16), dp(16));
        output.setTextIsSelectable(true);
        // Keep terminal lines unwrapped so ASCII art / menus stay aligned; scroll sideways if needed.
        output.setHorizontallyScrolling(true);
        android.widget.HorizontalScrollView hScroll = new android.widget.HorizontalScrollView(this);
        hScroll.setFillViewport(true);
        hScroll.addView(output);
        outputScroll.addView(hScroll);
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(12);
        page.addView(outputScroll, outLp);

        quickBox = new LinearLayout(this);
        quickBox.setOrientation(LinearLayout.VERTICAL);
        quickBox.setVisibility(View.GONE);
        TextView quickHint = label("請選擇一個選項：", 12, MUTED, true);
        quickHint.setPadding(dp(6), 0, 0, dp(6));
        quickBox.addView(quickHint);
        android.widget.HorizontalScrollView quickScroll = new android.widget.HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        quickBar = new LinearLayout(this);
        quickScroll.addView(quickBar);
        quickBox.addView(quickScroll);
        LinearLayout.LayoutParams quickLp = new LinearLayout.LayoutParams(-1, -2);
        quickLp.topMargin = dp(12);
        page.addView(quickBox, quickLp);

        inputLabel = label("啟動參數（選填，一般不用填）", 11, MUTED, true);
        LinearLayout.LayoutParams inputLabelLp = new LinearLayout.LayoutParams(-1, -2);
        inputLabelLp.topMargin = dp(14);
        inputLabelLp.leftMargin = dp(6);
        page.addView(inputLabel, inputLabelLp);

        // Gray pill input, like the search bar in the reference.
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setBackground(round(PANEL, 28, PANEL, 0));
        LinearLayout.LayoutParams inputRowLp = new LinearLayout.LayoutParams(-1, dp(54));
        inputRowLp.topMargin = dp(6);
        page.addView(inputRow, inputRowLp);

        TextView prompt = label("$", 19, MUTED, true);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        prompt.setGravity(Gravity.CENTER);
        inputRow.addView(prompt, new LinearLayout.LayoutParams(dp(46), -1));

        inputBox = new EditText(this);
        inputBox.setTextSize(14);
        inputBox.setSingleLine(false);
        inputBox.setMinLines(1);
        inputBox.setMaxLines(2);
        inputBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        inputBox.setTypeface(Typeface.MONOSPACE);
        inputBox.setTextColor(TEXT);
        inputBox.setHintTextColor(MUTED);
        inputBox.setHint("一般請留空");
        inputBox.setBackground(null);
        inputBox.setPadding(0, 0, dp(18), 0);
        inputRow.addView(inputBox, new LinearLayout.LayoutParams(0, -1, 1));

        runButton = actionButton("▶  開始運行", ACCENT, Color.WHITE);
        LinearLayout.LayoutParams runLp = new LinearLayout.LayoutParams(-1, dp(52));
        runLp.topMargin = dp(10);
        page.addView(runButton, runLp);

        runButton.setOnClickListener(v -> {
            if (scriptRunning) sendInteractiveInput();
            else runBuiltInScript();
        });
        clear.setOnClickListener(v -> { output.setText(""); ansi.reset(); recentText.setLength(0); updateQuickReplies(); });
        return page;
    }

    private LinearLayout newPage(String title) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));
        page.setBackgroundColor(BG);
        page.addView(label(title, 30, TEXT, true));
        return page;
    }

    /** White rounded list-item card: title + subtitle on the left, optional view on the right. */
    private LinearLayout listCard(String title, TextView sub, View right) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(14), dp(16), dp(14));
        card.setBackground(round(Color.WHITE, 22, Color.WHITE, 0));
        card.setElevation(dp(1));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(label(title, 16, TEXT, true));
        names.addView(sub);
        card.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(12);
            card.addView(right, lp);
        }
        return card;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        return lp;
    }

    private LinearLayout buildSettingsPage() {
        LinearLayout page = newPage("設置");

        ptyBox = new android.widget.Switch(this);
        ptyBox.setChecked(usePty);
        ptyBox.setOnCheckedChangeListener((b, checked) -> usePty = checked);
        TextView modeSub = label("開啟＝建議方式\n如果介面沒出現或選項異常，可關閉後再試一次", 12, MUTED, false);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("運行方式", modeSub, ptyBox), first);

        privilegeInfo = label("偵測中…", 12, MUTED, false);
        page.addView(listCard("權限狀態", privilegeInfo, null), cardLp());

        TextView clearSub = label("每次按「開始運行」都會先清空畫面", 12, MUTED, false);
        TextView on = label("已啟用", 11, ACCENT, true);
        page.addView(listCard("開始前清空畫面", clearSub, on), cardLp());

        TextView note = label("運行中無法更改運行方式。", 11, MUTED, false);
        LinearLayout.LayoutParams noteLp = cardLp();
        noteLp.leftMargin = dp(6);
        page.addView(note, noteLp);
        return page;
    }

    private LinearLayout buildAboutPage() {
        LinearLayout page = newPage("關於");
        TextView ver = label("v2.6", 12, MUTED, false);
        TextView tag = label("MOBAI", 11, ACCENT, true);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("版本", ver, tag), first);

        TextView steps = label("① 到「終端」按「開始運行」\n② 出現選項時，點上方的按鈕\n③ 看到「配置完成」，介面就會出現", 12, MUTED, false);
        page.addView(listCard("使用步驟", steps, null), cardLp());

        TextView about = label("MOBAI 會啟動內建的主程式，並顯示運行過程。", 12, MUTED, false);
        page.addView(listCard("說明", about, null), cardLp());

        TextView perm = label("會依序嘗試 Shizuku → root → 一般權限。\n請只在信任的來源使用。", 12, MUTED, false);
        page.addView(listCard("權限", perm, null), cardLp());

        TextView pkg = label(getPackageName(), 12, MUTED, false);
        page.addView(listCard("套件名稱", pkg, null), cardLp());
        return page;
    }

    private void showPage(int index) {
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            navItems[i].setBackground(i == index ? round(PANEL, 22, PANEL, 0) : null);
        }
    }

    private void buildUi() {
        boolean wide = getResources().getConfiguration().screenWidthDp >= 600;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(BG);

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(dp(10), dp(26), dp(10), dp(12));
        String[] names = {"終端", "設置", "關於"};
        String[] glyphs = {">_", "⚙", "i"};
        navItems = new LinearLayout[names.length];
        for (int i = 0; i < names.length; i++) {
            LinearLayout nav = new LinearLayout(this);
            nav.setGravity(Gravity.CENTER_VERTICAL | (wide ? Gravity.START : Gravity.CENTER_HORIZONTAL));
            nav.setPadding(dp(wide ? 16 : 0), 0, dp(wide ? 12 : 0), 0);
            TextView glyph = label(glyphs[i], 18, TEXT, true);
            glyph.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            glyph.setGravity(Gravity.CENTER);
            nav.addView(glyph, new LinearLayout.LayoutParams(dp(30), -2));
            if (wide) {
                TextView name = label(names[i], 15, TEXT, true);
                name.setPadding(dp(12), 0, 0, 0);
                nav.addView(name);
            }
            final int index = i;
            nav.setOnClickListener(v -> showPage(index));
            LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, dp(54));
            navLp.topMargin = dp(6);
            side.addView(nav, navLp);
            navItems[i] = nav;
        }
        root.addView(side, new LinearLayout.LayoutParams(dp(wide ? 190 : 64), -1));

        View divider = new View(this);
        divider.setBackgroundColor(BORDER);
        root.addView(divider, new LinearLayout.LayoutParams(dp(1), -1));

        android.widget.FrameLayout content = new android.widget.FrameLayout(this);
        pages = new LinearLayout[] {buildTerminalPage(), buildSettingsPage(), buildAboutPage()};
        for (LinearLayout p : pages) {
            content.addView(p, new android.widget.FrameLayout.LayoutParams(-1, -1));
        }
        root.addView(content, new LinearLayout.LayoutParams(0, -1, 1));
        setContentView(root);
        showPage(0);
    }

    private void runBuiltInScript() {
        if (scriptRunning) {
            sendInteractiveInput();
            return;
        }
        output.setText("");
        ansi.reset();
        recentText.setLength(0);
        updateQuickReplies();
        final String input = inputBox.getText().toString();
        final boolean pty = usePty;
        ptyBox.setEnabled(false);
        runButton.setEnabled(false);
        status.setText("啟動中");
        status.setTextColor(ACCENT);
        appendOutput("▶ 開始運行 MOBAI…\n");
        if (!input.isEmpty()) appendOutput("啟動參數：" + input + "\n");

        executor.execute(() -> {
            File localScript = null;
            long localPtyHandle = 0L;
            Process localProc = null;
            boolean localPtyWaitCompleted = false;
            try {
                // main.sh contains an ELF payload: keep and transfer its raw bytes.
                byte[] scriptBytes = readBuiltInScriptBytes();
                validateSelfExtractingScript(scriptBytes);
                appendOutput("✔ 程式檔案檢查通過\n");
                if ("shizuku".equals(executionMode)) {
                    IShellUserService service = shizukuShellService;
                    if (service == null) {
                        CountDownLatch latch = userServiceReady;
                        latch.await(10, TimeUnit.SECONDS);
                        service = shizukuShellService;
                    }
                    if (service == null) {
                        throw new IllegalStateException(
                                "Shizuku UserService 尚未連線。請確認 Shizuku 正在執行且已授權，再重試。");
                    }

                    appendOutput("使用 Shizuku 權限運行\n");
                    service.setUsePty(pty);
                    service.beginScript(scriptBytes.length);
                    boolean started = false;
                    try {
                        final int chunkSize = 64 * 1024;
                        for (int offset = 0; offset < scriptBytes.length; offset += chunkSize) {
                            int end = Math.min(scriptBytes.length, offset + chunkSize);
                            service.writeScriptChunk(Arrays.copyOfRange(scriptBytes, offset, end));
                        }
                        // Queue the UI state before start: the first output or exit callback
                        // must never be overwritten by a later "running" state update.
                        runOnUiThread(() -> {
                            inputBox.setText("");
                            setInteractiveMode(true);
                        });
                        service.startScript(input, shellOutputCallback);
                        started = true;
                    } finally {
                        if (!started) {
                            try { service.abortScript(); } catch (Exception ignored) { }
                        }
                    }
                    return;
                }

                localScript = new File(getCacheDir(), "main.sh");
                try (FileOutputStream out = new FileOutputStream(localScript)) {
                    out.write(scriptBytes);
                    out.flush();
                }

                appendOutput("使用 " + ("root".equals(executionMode) ? "root 權限" : "一般權限") + " 運行\n");
                if (pty) {
                    localPtyHandle = startLocalProcess(localScript, input);
                    activePtyHandle = localPtyHandle;
                    final long runningHandle = localPtyHandle;
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    try (InputStream stream = PtyBridge.openInputStream(runningHandle);
                         InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                        char[] buffer = new char[2048];
                        int count;
                        while ((count = reader.read(buffer)) != -1) {
                            if (count > 0) appendOutput(new String(buffer, 0, count));
                        }
                    }
                    int code = PtyBridge.waitFor(runningHandle);
                    localPtyWaitCompleted = true;
                    activePtyHandle = 0L;
                    runOnUiThread(() -> completeScript(code));
                } else {
                    final Process proc = startLocalPipeProcess(localScript, input);
                    localProc = proc;
                    activeProcess = proc;
                    activeProcessInput = proc.getOutputStream();
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    Thread reader = new Thread(() -> {
                        try (InputStream stream = proc.getInputStream();
                             InputStreamReader r = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                            char[] buffer = new char[2048];
                            int count;
                            while ((count = r.read(buffer)) != -1) {
                                if (count > 0) appendOutput(new String(buffer, 0, count));
                            }
                        } catch (Exception ignored) {
                            // Stream closed.
                        }
                    }, "TermiGlow-PipeReader");
                    reader.setDaemon(true);
                    reader.start();
                    int code = proc.waitFor();
                    reader.join(1500);
                    localPtyWaitCompleted = true;
                    activeProcess = null;
                    activeProcessInput = null;
                    runOnUiThread(() -> completeScript(code));
                }
            } catch (Exception e) {
                if (localProc != null && !localPtyWaitCompleted) localProc.destroy();
                activeProcess = null;
                activeProcessInput = null;
                if (localPtyHandle > 0L && !localPtyWaitCompleted) {
                    PtyBridge.terminate(localPtyHandle);
                    try { PtyBridge.waitFor(localPtyHandle); } catch (Exception ignored) { }
                }
                activePtyHandle = 0L;
                String message = describeError(e);
                runOnUiThread(() -> finishWithError(message));
            } finally {
                if (localScript != null && localScript.exists()) localScript.delete();
            }
        });
    }


    /** Shows tap-to-answer buttons when the program is waiting at a numbered menu. */
    private void updateQuickReplies() {
        if (quickBox == null) return;
        String t = recentText.toString();
        int idx = Math.max(t.lastIndexOf("请选择"), t.lastIndexOf("請選擇"));
        boolean waiting = scriptRunning && idx >= 0 && t.indexOf('\n', idx) < 0;
        java.util.LinkedHashMap<String, String> opts = new java.util.LinkedHashMap<>();
        if (waiting) {
            String before = t.substring(Math.max(0, idx - 900), idx);
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?m)^\\s*\\[(\\d+)\\]\\s*(.+?)\\s*$").matcher(before);
            while (m.find()) opts.put(m.group(1), m.group(2));
        }
        if (opts.isEmpty()) {
            quickBox.setVisibility(View.GONE);
            lastMenuSig = "";
            return;
        }
        String sig = opts.toString();
        if (sig.equals(lastMenuSig) && quickBox.getVisibility() == View.VISIBLE) return;
        lastMenuSig = sig;
        quickBar.removeAllViews();
        for (java.util.Map.Entry<String, String> e : opts.entrySet()) {
            addQuickChip(e.getKey() + "．" + friendlyOption(e.getValue()), e.getKey(), false);
        }
        addQuickChip("使用預設", "", true);
        quickBox.setVisibility(View.VISIBLE);
    }

    private void addQuickChip(String label, String reply, boolean primary) {
        Button chip = actionButton(label, primary ? ACCENT : Color.WHITE, primary ? Color.WHITE : TEXT);
        chip.setElevation(dp(1));
        chip.setOnClickListener(v -> {
            inputBox.setText(reply);
            sendInteractiveInput();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.rightMargin = dp(8);
        quickBar.addView(chip, lp);
    }

    private String friendlyOption(String raw) {
        if (raw.contains("无后台") || raw.contains("無後台")) {
            if (raw.contains("开启") || raw.contains("開啟")) return "關閉程式時，介面一起關閉（推薦）";
            if (raw.contains("关闭") || raw.contains("關閉")) return "介面留在背景，關閉程式後仍繼續顯示";
        }
        return raw;
    }

    /** Send one line to a running script instead of starting it again. */
    private void sendInteractiveInput() {
        if (!scriptRunning) return;
        final String line = inputBox.getText().toString();
        try {
            if ("shizuku".equals(executionMode)) {
                IShellUserService service = shizukuShellService;
                if (service == null) throw new IllegalStateException("Shizuku UserService 已斷線。");
                service.writeInput(line);
            } else {
                long handle = activePtyHandle;
                OutputStream pipeIn = activeProcessInput;
                if (handle != 0L) {
                    PtyBridge.writeLine(handle, line);
                } else if (pipeIn != null) {
                    pipeIn.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                    pipeIn.flush();
                } else {
                    throw new IllegalStateException("目前沒有可接收輸入的程序。");
                }
            }
            // A real PTY supplies normal terminal echo; do not duplicate the line here.
            inputBox.setText("");
            inputBox.requestFocus();
        } catch (Exception e) {
            appendOutput("\n⚠ 送出失敗：" + describeError(e) + "\n");
        }
    }

    private void setInteractiveMode(boolean running) {
        scriptRunning = running;
        runButton.setEnabled(true);
        if (ptyBox != null) ptyBox.setEnabled(!running);
        if (running) {
            runButton.setText("↵  送出");
            inputLabel.setText("回覆程式的提問");
            inputBox.setHint("輸入選項數字（例如 1），再按「送出」；直接按送出＝使用預設");
            status.setText("運行中");
            status.setTextColor(ACCENT);
        } else {
            runButton.setText("▶  開始運行");
            inputLabel.setText("啟動參數（選填，一般不用填）");
            inputBox.setHint("一般請留空");
        }
    }

    private void completeScript(int exitCode) {
        scriptRunning = false;
        activePtyHandle = 0L;
        appendOutput(exitCode == 0 ? "\n✔ 程式已結束。\n" : "\n⚠ 程式已結束（代碼 " + exitCode + "）。\n");
        updateExitStatus(exitCode);
        setInteractiveMode(false);
    }

    private byte[] readBuiltInScriptBytes() throws Exception {
        try (InputStream in = getAssets().open("main.sh");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    /**
     * main.sh is a self-extracting script with a raw ELF appended to its text header.
     * Check the asset before execution so a packaging/editing mistake is reported clearly.
     * The script bytes are not rewritten or normalized here.
     */
    private String validateSelfExtractingScript(byte[] bytes) {
        if (bytes == null || bytes.length < 64) {
            throw new IllegalStateException("內置 main.sh 太短或讀取失敗。");
        }
        final byte[] elfMagic = new byte[] { 0x7f, 'E', 'L', 'F' };
        int actualOffset = findBytes(bytes, elfMagic);
        if (actualOffset < 0) {
            throw new IllegalStateException("內置 main.sh 找不到 ELF payload；檔案可能被文字編輯器改寫。");
        }
        String header = new String(bytes, 0, actualOffset, StandardCharsets.UTF_8);
        Matcher offsetMatcher = Pattern.compile("(?m)^PAYLOAD_OFFSET=\\$\\(\\(\\s*(\\d+)\\)\\)\\s*$").matcher(header);
        if (!offsetMatcher.find()) {
            throw new IllegalStateException("main.sh 找不到 PAYLOAD_OFFSET 標記；請使用原始檔案。");
        }
        final int declaredOffset;
        try {
            declaredOffset = Integer.parseInt(offsetMatcher.group(1));
        } catch (NumberFormatException e) {
            throw new IllegalStateException("main.sh 的 PAYLOAD_OFFSET 無效。");
        }
        if (declaredOffset != actualOffset) {
            throw new IllegalStateException("main.sh payload offset 不一致：標記=" + declaredOffset
                    + "，實際 ELF=" + actualOffset + "。請確認沒有修改原始 main.sh。");
        }
        if (actualOffset + 20 > bytes.length) {
            throw new IllegalStateException("main.sh 的 ELF payload 不完整。");
        }
        int elfClass = bytes[actualOffset + 4] & 0xff;
        int elfData = bytes[actualOffset + 5] & 0xff;
        int machineLow = bytes[actualOffset + 18] & 0xff;
        int machineHigh = bytes[actualOffset + 19] & 0xff;
        if (elfClass != 2 || elfData != 1 || machineLow != 0xb7 || machineHigh != 0x00) {
            throw new IllegalStateException(String.format(java.util.Locale.ROOT,
                    "內置 ELF 檔頭與腳本預期不符（class=%02x, data=%02x, e_machine=%02x%02x）。",
                    elfClass, elfData, machineHigh, machineLow));
        }
        return "原始 main.sh 位元組載入成功（" + bytes.length + " bytes；ELF offset="
                + actualOffset + "；AArch64）。";
    }

    private int findBytes(byte[] source, byte[] target) {
        if (target.length == 0 || source.length < target.length) return -1;
        outer: for (int i = 0; i <= source.length - target.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (source[i + j] != target[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private Process startLocalPipeProcess(File script, String input) throws Exception {
        String arg = input == null ? "" : input;
        ProcessBuilder builder;
        if ("root".equals(executionMode)) {
            builder = new ProcessBuilder("su", "-c",
                    "/system/bin/sh " + shellQuote(script.getAbsolutePath()) + " " + shellQuote(arg));
        } else {
            builder = new ProcessBuilder("/system/bin/sh", script.getAbsolutePath(), arg);
        }
        builder.directory(getFilesDir());
        builder.redirectErrorStream(true);
        return builder.start();
    }

    private long startLocalProcess(File script, String input) throws Exception {
        // Same as typing `sh main.sh` in MT Manager's terminal: run as the app user inside the PTY.
        // main.sh detects root / su / Shizuku rish by itself and only elevates the ELF launch.
        String command = "exec /system/bin/sh " + shellQuote(script.getAbsolutePath())
                + " " + shellQuote(input == null ? "" : input);
        return PtyBridge.start(command, getFilesDir(), 48, 140);
    }

    private void checkShizukuPermission() {
        if (!Shizuku.pingBinder()) return;
        if (shizukuPermissionRequestPending || shizukuShellService != null
                || userServiceBindInProgress || "shizuku".equals(executionMode)) return;
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                executionMode = "shizuku";
                appendOutput("✔ 已有 Shizuku 授權，正在連線…\n");
                bindShizukuUserService();
            } else {
                shizukuPermissionRequestPending = true;
                appendOutput("正在請求 Shizuku 授權…\n");
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Exception e) {
            shizukuPermissionRequestPending = false;
            appendOutput("Shizuku 無法使用：" + describeError(e) + "\n");
            requestRootFallback();
        }
    }

    private void bindShizukuUserService() {
        if (shizukuShellService != null || userServiceBindInProgress) return;
        try {
            userServiceBindInProgress = true;
            userServiceReady = new CountDownLatch(1);
            userServiceArgs = new Shizuku.UserServiceArgs(
                    new ComponentName(this, ShellUserService.class))
                    // Shizuku API 13.1.5 requires a non-null process-name suffix.
                    .processNameSuffix("mobai_shell")
                    .tag("termiglow-shell-user-service")
                    .version(5)
                    .daemon(false);
            Shizuku.bindUserService(userServiceArgs, userServiceConnection);
            appendOutput("正在連線 Shizuku…\n");
        } catch (Exception e) {
            userServiceBindInProgress = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線失敗：" + describeError(e) + "\n");
            executionMode = rootAvailable ? "root" : "normal";
            requestRootFallback();
        }
    }

    private void requestRootFallback() {
        if (rootFallbackStarted || "shizuku".equals(executionMode)) return;
        rootFallbackStarted = true;
        executor.execute(() -> {
            Process probe = null;
            try {
                probe = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        probe.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line).append('\n');
                }
                int code = probe.waitFor();
                if ("shizuku".equals(executionMode)) return;
                if (code == 0 && result.toString().contains("uid=0")) {
                    rootAvailable = true;
                    executionMode = "root";
                    runOnUiThread(() -> {
                        appendOutput("✔ 已取得 root 授權。\n");
                        updatePrivilegeStatus("root 已就緒");
                    });
                } else {
                    rootAvailable = false;
                    executionMode = "normal";
                    runOnUiThread(() -> {
                        appendOutput("未取得 root，將使用一般權限。\n");
                        updatePrivilegeStatus("一般權限");
                    });
                }
            } catch (Exception e) {
                if ("shizuku".equals(executionMode)) return;
                rootAvailable = false;
                executionMode = "normal";
                runOnUiThread(() -> {
                    appendOutput("此裝置沒有 root，將使用一般權限。\n");
                    updatePrivilegeStatus("一般權限");
                });
            } finally {
                if (probe != null) probe.destroy();
            }
        });
    }

    private int extractExitCode(String transcript) {
        Matcher matcher = Pattern.compile("\\[process exited: (-?\\d+)\\]").matcher(transcript);
        int result = Integer.MIN_VALUE;
        while (matcher.find()) {
            try {
                result = Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return Integer.MIN_VALUE;
            }
        }
        return result;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private String describeError(Throwable error) {
        Throwable deepest = error;
        while (deepest.getCause() != null && deepest.getCause() != deepest) {
            deepest = deepest.getCause();
        }
        String message = deepest.getMessage();
        if (message == null || message.trim().isEmpty()) message = deepest.getClass().getSimpleName();
        return error.getClass().getSimpleName() + ": " + message;
    }

    private void updatePrivilegeStatus(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> updatePrivilegeStatus(text));
            return;
        }
        if (privilegeInfo != null) privilegeInfo.setText(text);
        if (status == null) return;
        status.setText("" + text);
        status.setTextColor(ACCENT);
    }

    private void updateExitStatus(int code) {
        status.setText(code == 0 ? "已完成" : "異常結束 (" + code + ")");
        status.setTextColor(code == 0 ? ACCENT : ERROR);
    }

    private void finishWithError(String message) {
        appendOutput("⚠ " + message + "\n");
        status.setText("發生錯誤");
        status.setTextColor(ERROR);
        setInteractiveMode(false);
        runButton.setEnabled(true);
    }

    private void appendOutput(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> appendOutput(text));
            return;
        }
        CharSequence plain = ansi.feed(text);
        output.append(plain);
        recentText.append(plain);
        if (recentText.length() > 4000) recentText.delete(0, recentText.length() - 3000);
        updateQuickReplies();
        CharSequence all = output.getText();
        if (all instanceof android.text.Editable && all.length() > 160000) {
            ((android.text.Editable) all).delete(0, all.length() - 120000);
        }
        if (outputScroll != null) {
            outputScroll.post(() -> outputScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(fg);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(round(bg, 26, bg, 0));
        return button;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderListener);
        if (userServiceArgs != null && userServiceBound) {
            try {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true);
            } catch (Exception ignored) {
                // Shizuku may already have been stopped while the Activity was closing.
            }
        }
        long handle = activePtyHandle;
        if (handle > 0L) PtyBridge.terminate(handle);
        Process pipeProc = activeProcess;
        if (pipeProc != null) pipeProc.destroy();
        if (scriptRunning && shizukuShellService != null) {
            try { shizukuShellService.abortScript(); } catch (Exception ignored) { }
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
