package com.example.termiglow;

import android.os.RemoteException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku UserService that stages the self-extracting main.sh as raw bytes,
 * then runs it under a native pseudo-terminal. Output is sent to the activity
 * as soon as it arrives, and user input is forwarded to the same PTY.
 */
public final class ShellUserService extends IShellUserService.Stub {
    private static final int MAX_SCRIPT_BYTES = 8 * 1024 * 1024;
    private static final int CHUNK_CHARS = 2048;

    private final Object stagingLock = new Object();
    private final Object processLock = new Object();

    private File stagedScriptFile;
    private OutputStream stagedScriptOutput;
    private int expectedScriptBytes;
    private int writtenScriptBytes;

    private volatile long activePtyHandle;
    // Default = plain pipes (same behavior as v12). PTY is optional.
    private volatile boolean usePty = false;
    private Process activeProcess;
    private OutputStream activeProcessInput;

    @Override
    public void setUsePty(boolean value) {
        usePty = value;
    }

    public ShellUserService() {
        // Required no-argument constructor for Shizuku UserService.
    }

    @Override
    public void beginScript(int totalBytes) throws RemoteException {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
            if (totalBytes <= 0 || totalBytes > MAX_SCRIPT_BYTES) {
                throw new RemoteException("Invalid built-in script size: " + totalBytes);
            }
            File tempDirectory = new File("/data/local/tmp");
            if (!tempDirectory.isDirectory() || !tempDirectory.canWrite()) {
                throw new RemoteException("Shizuku UserService cannot write /data/local/tmp");
            }
            try {
                stagedScriptFile = File.createTempFile("termiglow-main-", ".sh", tempDirectory);
                stagedScriptOutput = new FileOutputStream(stagedScriptFile);
                expectedScriptBytes = totalBytes;
                writtenScriptBytes = 0;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to stage built-in script: " + e.getMessage());
            }
        }
    }

    @Override
    public void writeScriptChunk(byte[] chunk) throws RemoteException {
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script; beginScript must be called first");
            }
            if (chunk == null || writtenScriptBytes + chunk.length > expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Invalid script chunk length");
            }
            try {
                stagedScriptOutput.write(chunk);
                writtenScriptBytes += chunk.length;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to write script chunk: " + e.getMessage());
            }
        }
    }

    @Override
    public void startScript(String input, IShellOutputCallback callback) throws RemoteException {
        if (callback == null) throw new RemoteException("Missing output callback");

        final File scriptFile;
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script to execute");
            }
            try {
                stagedScriptOutput.close();
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to close staged script: " + e.getMessage());
            }
            stagedScriptOutput = null;
            if (writtenScriptBytes != expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Incomplete script transfer: expected "
                        + expectedScriptBytes + " bytes, received " + writtenScriptBytes);
            }
            scriptFile = stagedScriptFile;
            stagedScriptFile = null;
            expectedScriptBytes = 0;
            writtenScriptBytes = 0;
        }

        synchronized (processLock) {
            if (activePtyHandle != 0L || activeProcess != null) {
                scriptFile.delete();
                throw new RemoteException("A script is already running");
            }
        }

        String argument = input == null ? "" : input;

        if (!usePty) {
            final Process proc;
            try {
                ProcessBuilder builder = new ProcessBuilder(
                        "/system/bin/sh", scriptFile.getAbsolutePath(), argument);
                builder.directory(new File("/"));
                builder.redirectErrorStream(true);
                proc = builder.start();
            } catch (IOException | RuntimeException e) {
                scriptFile.delete();
                throw new RemoteException("Unable to start script: " + e.getMessage());
            }
            synchronized (processLock) {
                activeProcess = proc;
                activeProcessInput = proc.getOutputStream();
            }
            Thread pipeThread = new Thread(
                    () -> streamPipe(proc, scriptFile, callback), "TermiGlow-PipeOutput");
            pipeThread.setDaemon(true);
            pipeThread.start();
            return;
        }
        String command = "exec /system/bin/sh " + shellQuote(scriptFile.getAbsolutePath())
                + " " + shellQuote(argument);
        final long handle;
        try {
            // PtyBridge creates a real /dev/ptmx-backed controlling terminal. A plain
            // ProcessBuilder pipe is not equivalent: this script's native payload uses
            // terminal behavior and may not flush prompts to a pipe.
            handle = PtyBridge.start(command, new File("/"), 48, 140);
        } catch (IOException | RuntimeException | LinkageError e) {
            scriptFile.delete();
            throw new RemoteException("Unable to start native PTY: " + e.getMessage());
        }

        synchronized (processLock) {
            activePtyHandle = handle;
        }
        Thread readerThread = new Thread(
                () -> streamPty(handle, scriptFile, callback),
                "TermiGlow-PtyOutput");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private void streamPty(long handle, File scriptFile, IShellOutputCallback callback) {
        int exitCode = -1;
        String streamError = null;
        boolean callbackAvailable = true;
        try (InputStream stream = PtyBridge.openInputStream(handle);
             Reader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            char[] buffer = new char[CHUNK_CHARS];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                if (count == 0) continue;
                if (callbackAvailable) {
                    try {
                        callback.onOutput(new String(buffer, 0, count));
                    } catch (RemoteException e) {
                        // Continue draining the PTY even if the Activity has gone away.
                        callbackAvailable = false;
                    }
                }
            }
        } catch (Exception e) {
            streamError = e.getClass().getSimpleName() + ": "
                    + (e.getMessage() == null ? "PTY output stream failed" : e.getMessage());
            PtyBridge.terminate(handle);
        } finally {
            try {
                exitCode = PtyBridge.waitFor(handle);
            } catch (Exception e) {
                if (streamError == null) {
                    streamError = e.getClass().getSimpleName() + ": "
                            + (e.getMessage() == null ? "PTY wait failed" : e.getMessage());
                }
            }
            if (scriptFile.exists()) scriptFile.delete();
            synchronized (processLock) {
                if (activePtyHandle == handle) {
                    activePtyHandle = 0L;
                }
            }
        }

        if (callbackAvailable) {
            try {
                if (streamError != null) callback.onError(streamError);
                callback.onExit(exitCode);
            } catch (RemoteException ignored) {
                // Activity may already have closed.
            }
        }
    }

    private void streamPipe(Process proc, File scriptFile, IShellOutputCallback callback) {
        final boolean[] callbackAvailable = { true };
        Thread reader = new Thread(() -> {
            try (InputStream s = proc.getInputStream();
                 Reader r = new InputStreamReader(s, StandardCharsets.UTF_8)) {
                char[] buf = new char[CHUNK_CHARS];
                int n;
                while ((n = r.read(buf)) != -1) {
                    if (n == 0) continue;
                    if (callbackAvailable[0]) {
                        try {
                            callback.onOutput(new String(buf, 0, n));
                        } catch (RemoteException e) {
                            callbackAvailable[0] = false;
                        }
                    }
                }
            } catch (Exception ignored) {
                // Stream closed.
            }
        }, "TermiGlow-PipeReader");
        reader.setDaemon(true);
        reader.start();

        int exitCode = -1;
        try {
            exitCode = proc.waitFor();
        } catch (InterruptedException e) {
            proc.destroy();
        }
        try { reader.join(1500); } catch (InterruptedException ignored) { }
        if (scriptFile.exists()) scriptFile.delete();
        synchronized (processLock) {
            if (activeProcess == proc) {
                activeProcess = null;
                activeProcessInput = null;
            }
        }
        if (callbackAvailable[0]) {
            try {
                callback.onExit(exitCode);
            } catch (RemoteException ignored) {
                // Activity may already have closed.
            }
        }
    }

    @Override
    public void writeInput(String text) throws RemoteException {
        final long handle;
        final OutputStream pipeIn;
        synchronized (processLock) {
            handle = activePtyHandle;
            pipeIn = activeProcessInput;
        }
        if (handle == 0L && pipeIn != null) {
            try {
                String value = text == null ? "" : text;
                if (!value.endsWith("\n")) value += "\n";
                pipeIn.write(value.getBytes(StandardCharsets.UTF_8));
                pipeIn.flush();
            } catch (IOException e) {
                throw new RemoteException("Unable to send input: " + e.getMessage());
            }
            return;
        }
        if (handle == 0L) throw new RemoteException("No interactive script is running");
        try {
            PtyBridge.writeLine(handle, text);
        } catch (IOException e) {
            throw new RemoteException("Unable to send input to the PTY: " + e.getMessage());
        }
    }

    @Override
    public void closeInput() throws RemoteException {
        final long handle;
        final OutputStream pipeIn;
        synchronized (processLock) {
            handle = activePtyHandle;
            pipeIn = activeProcessInput;
        }
        if (handle == 0L) {
            if (pipeIn != null) {
                try { pipeIn.close(); } catch (IOException ignored) { }
            }
            return;
        }
        try {
            PtyBridge.sendEof(handle);
        } catch (IOException e) {
            throw new RemoteException("Unable to send EOF to the PTY: " + e.getMessage());
        }
    }

    @Override
    public void abortScript() {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
        }
        final long handle;
        final Process pipeProc;
        synchronized (processLock) {
            handle = activePtyHandle;
            pipeProc = activeProcess;
        }
        if (pipeProc != null) pipeProc.destroy();
        if (handle != 0L) PtyBridge.terminate(handle);
    }

    @Override
    public void exit() {
        abortScript();
        System.exit(0);
    }

    @Override
    public void destroy() {
        exit();
    }
    /**
     * Clears any partially or fully staged script. The caller must hold
     * stagingLock so begin/write/start/abort cannot race with cleanup.
     */
    private void clearStagedScriptLocked() {
        if (stagedScriptOutput != null) {
            try {
                stagedScriptOutput.close();
            } catch (IOException ignored) {
                // Cleanup is best-effort; preserve the original failure when present.
            }
            stagedScriptOutput = null;
        }

        if (stagedScriptFile != null) {
            try {
                if (stagedScriptFile.exists()) {
                    // A failed delete is harmless here; the OS will reclaim the temp
                    // file on cleanup/reboot, and it must not hide the primary error.
                    stagedScriptFile.delete();
                }
            } catch (SecurityException ignored) {
                // Best-effort cleanup only.
            }
            stagedScriptFile = null;
        }

        expectedScriptBytes = 0;
        writtenScriptBytes = 0;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

}
