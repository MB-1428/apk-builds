#define _GNU_SOURCE
#include <jni.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#ifndef TIOCSCTTY
#define TIOCSCTTY 0x540E
#endif

#define PTY_EOF_SENTINEL (-100000)

extern char **environ;

static jlong make_handle(pid_t child, int master_fd) {
    uint64_t packed = ((uint64_t)(uint32_t)child << 32) | (uint32_t)master_fd;
    return (jlong)packed;
}

static pid_t handle_pid(jlong handle) {
    return (pid_t)(uint32_t)(((uint64_t)handle) >> 32);
}

static int handle_fd(jlong handle) {
    return (int)(uint32_t)((uint64_t)handle & UINT32_MAX);
}

static jlong errno_handle(void) {
    int value = errno;
    if (value <= 0) value = EIO;
    return (jlong)(-value);
}

JNIEXPORT jlong JNICALL
Java_com_example_termiglow_PtyBridge_nativeStart(JNIEnv *env, jclass clazz,
                                                  jstring command_value,
                                                  jstring directory_value,
                                                  jint rows, jint columns) {
    (void)clazz;
    if (command_value == NULL || directory_value == NULL) return -(jlong)EINVAL;

    const char *command_utf = (*env)->GetStringUTFChars(env, command_value, NULL);
    if (command_utf == NULL) return -(jlong)ENOMEM;
    const char *directory_utf = (*env)->GetStringUTFChars(env, directory_value, NULL);
    if (directory_utf == NULL) {
        (*env)->ReleaseStringUTFChars(env, command_value, command_utf);
        return -(jlong)ENOMEM;
    }

    char *command = strdup(command_utf);
    char *directory = strdup(directory_utf);
    (*env)->ReleaseStringUTFChars(env, command_value, command_utf);
    (*env)->ReleaseStringUTFChars(env, directory_value, directory_utf);
    if (command == NULL || directory == NULL) {
        free(command);
        free(directory);
        return -(jlong)ENOMEM;
    }

    // Set a terminal type for terminal-aware programs before fork so the child
    // does not need to call non-async-signal-safe environment functions.
    if (setenv("TERM", "xterm-256color", 1) != 0) {
        jlong error = errno_handle();
        free(command);
        free(directory);
        return error;
    }

    int master_fd = posix_openpt(O_RDWR | O_NOCTTY | O_CLOEXEC);
    if (master_fd < 0) {
        jlong error = errno_handle();
        free(command);
        free(directory);
        return error;
    }
    if (grantpt(master_fd) != 0 || unlockpt(master_fd) != 0) {
        jlong error = errno_handle();
        close(master_fd);
        free(command);
        free(directory);
        return error;
    }

    char *slave_name_value = ptsname(master_fd);
    if (slave_name_value == NULL) {
        jlong error = errno_handle();
        close(master_fd);
        free(command);
        free(directory);
        return error;
    }
    char *slave_name = strdup(slave_name_value);
    if (slave_name == NULL) {
        close(master_fd);
        free(command);
        free(directory);
        return -(jlong)ENOMEM;
    }

    struct winsize window_size;
    memset(&window_size, 0, sizeof(window_size));
    window_size.ws_row = (unsigned short)(rows > 0 ? rows : 40);
    window_size.ws_col = (unsigned short)(columns > 0 ? columns : 120);
    (void)ioctl(master_fd, TIOCSWINSZ, &window_size);

    pid_t child = fork();
    if (child < 0) {
        jlong error = errno_handle();
        close(master_fd);
        free(command);
        free(directory);
        free(slave_name);
        return error;
    }

    if (child == 0) {
        close(master_fd);
        if (setsid() < 0) _exit(125);
        int slave_fd = open(slave_name, O_RDWR | O_NOCTTY);
        if (slave_fd < 0) _exit(125);
        (void)ioctl(slave_fd, TIOCSWINSZ, &window_size);
        if (dup2(slave_fd, STDIN_FILENO) < 0
                || dup2(slave_fd, STDOUT_FILENO) < 0
                || dup2(slave_fd, STDERR_FILENO) < 0) {
            _exit(125);
        }
        if (slave_fd > STDERR_FILENO) close(slave_fd);
        if (ioctl(STDIN_FILENO, TIOCSCTTY, 0) != 0) {
            static const char message[] = "TermiGlow PTY: TIOCSCTTY failed\r\n";
            (void)write(STDERR_FILENO, message, sizeof(message) - 1);
            _exit(125);
        }
        if (chdir(directory) != 0) {
            static const char message[] = "TermiGlow PTY: chdir failed\r\n";
            (void)write(STDERR_FILENO, message, sizeof(message) - 1);
            _exit(126);
        }

        char *const arguments[] = {
            (char *)"/system/bin/sh",
            (char *)"-c",
            command,
            NULL
        };
        execve("/system/bin/sh", arguments, environ);
        _exit(127);
    }

    free(command);
    free(directory);
    free(slave_name);
    return make_handle(child, master_fd);
}

JNIEXPORT jint JNICALL
Java_com_example_termiglow_PtyBridge_nativeRead(JNIEnv *env, jclass clazz,
                                                 jlong handle, jbyteArray array,
                                                 jint offset, jint length) {
    (void)clazz;
    if (array == NULL || offset < 0 || length < 0
            || offset > (*env)->GetArrayLength(env, array) - length) return -EINVAL;
    if (length == 0) return 0;
    int fd = handle_fd(handle);
    jbyte *bytes = (*env)->GetByteArrayElements(env, array, NULL);
    if (bytes == NULL) return -ENOMEM;

    ssize_t count;
    do {
        count = read(fd, bytes + offset, (size_t)length);
    } while (count < 0 && errno == EINTR);

    int result;
    if (count > 0) {
        result = (int)count;
    } else if (count == 0 || errno == EIO || errno == EBADF) {
        result = PTY_EOF_SENTINEL;
    } else {
        result = -errno;
    }
    (*env)->ReleaseByteArrayElements(env, array, bytes,
            result > 0 ? 0 : JNI_ABORT);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_example_termiglow_PtyBridge_nativeWrite(JNIEnv *env, jclass clazz,
                                                  jlong handle, jbyteArray array,
                                                  jint offset, jint length) {
    (void)clazz;
    if (array == NULL || offset < 0 || length < 0
            || offset > (*env)->GetArrayLength(env, array) - length) return -EINVAL;
    if (length == 0) return 0;
    int fd = handle_fd(handle);
    jbyte *bytes = (*env)->GetByteArrayElements(env, array, NULL);
    if (bytes == NULL) return -ENOMEM;

    jint total = 0;
    while (total < length) {
        ssize_t count = write(fd, bytes + offset + total, (size_t)(length - total));
        if (count < 0 && errno == EINTR) continue;
        if (count < 0) {
            total = -errno;
            break;
        }
        if (count == 0) break;
        total += (jint)count;
    }
    (*env)->ReleaseByteArrayElements(env, array, bytes, JNI_ABORT);
    return total;
}

JNIEXPORT jint JNICALL
Java_com_example_termiglow_PtyBridge_nativeWaitFor(JNIEnv *env, jclass clazz, jlong handle) {
    (void)env;
    (void)clazz;
    pid_t child = handle_pid(handle);
    int fd = handle_fd(handle);
    int status = 0;
    pid_t result;
    do {
        result = waitpid(child, &status, 0);
    } while (result < 0 && errno == EINTR);

    int saved_errno = errno;
    close(fd);
    if (result < 0) return -saved_errno;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return 255;
}

JNIEXPORT void JNICALL
Java_com_example_termiglow_PtyBridge_nativeTerminate(JNIEnv *env, jclass clazz, jlong handle) {
    (void)env;
    (void)clazz;
    pid_t child = handle_pid(handle);
    if (child > 0) {
        (void)kill(-child, SIGHUP);
        (void)kill(-child, SIGTERM);
        (void)kill(child, SIGTERM);
    }
}
