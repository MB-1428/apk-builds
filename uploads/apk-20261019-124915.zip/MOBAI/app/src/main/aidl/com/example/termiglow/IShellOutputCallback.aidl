package com.example.termiglow;

/** Asynchronous console output from the privileged Shell process. */
oneway interface IShellOutputCallback {
    void onOutput(String text);
    void onExit(int exitCode);
    void onError(String message);
}
