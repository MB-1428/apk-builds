# TermiGlow v2.6：左側導覽列（終端 / 設置 / 關於），終端模式開關移到設置頁。

- 新增 ANSI 顏色解析、輸出不換行、root 模式啟動後自動診斷。
- Shizuku UserService 版本升為 5，新增 setUsePty。

# TermiGlow v2.3 — 真正 PTY 互動終端／白色主題

本版修正 v12/v13 的核心問題：舊程式只在 Android 系統剛好提供相容的 `script` 指令時才嘗試 PTY；否則會靜默退回一般 stdin/stdout 管線。一般管線不是終端機，原生程式可能因為 `isatty()`、`/dev/tty` 或輸出緩衝而不顯示選單。畫面卻仍顯示 `RUNNING · INPUT READY`，容易誤以為終端正常。

## 本版改動

- 修正 v14 編譯錯誤：補上 `ShellUserService.clearStagedScriptLocked()`，統一關閉暫存輸出串流、刪除暫存腳本並重設傳輸計數。
- 明確加入 `androidx.annotation:annotation:1.9.1`，供 Shizuku API 編譯時解析 `RestrictTo.Scope` 註解常數。
- 將 Android `versionCode` 更新為 13、`versionName` 更新為 2.2，方便安裝更新版 APK。
- 新增 Android NDK 原生 PTY bridge：透過 `/dev/ptmx` 配置真正的 pseudo-terminal，並將 slave 設為子程序的控制終端。
- Shizuku UserService、Root 與一般權限路徑都使用相同的 PTY 讀寫流程，不再依賴手機是否預裝 `script` applet。
- PTY 輸出以位元組串流讀取，即使提示符沒有換行，也能立即轉成文字回傳 UI。
- 執行中 `$` 輸入列會透過 PTY 寫入文字並加上換行，原生終端負責一般的輸入回顯，避免 UI 重複顯示輸入內容。
- 保留原始 `main.sh` 的所有位元組，不改動 Shell 前綴、`PAYLOAD_OFFSET` 或內嵌 ELF。
- 保留 Shizuku `UserServiceArgs.processNameSuffix("termiglow_shell")`、白色主題、底部輸入列與即時狀態。
- `minSdk 24`；由於內嵌 ELF 是 AArch64，本專案以 `arm64-v8a` 建置原生 PTY 函式庫。

## 測試方式

1. 建置並安裝 APK，確認 Shizuku 已啟動且 TermiGlow 已獲授權（或裝置具備可用的 Root 執行環境）。
2. 點擊「執行內置腳本」。
3. 終端區應顯示腳本原本的選單，並停在 `请选择（默认 1）:` 等待輸入。
4. 在底部輸入 `1` 或 `2`，按「送出輸入」。輸入會送進同一個 PTY 程序，不會重新啟動腳本。

## 建置需求

使用 Android Studio、JDK 17、Android SDK Platform 35、Android NDK `27.2.12479018` 及 CMake `3.22.1`。在 GitHub Actions 中，請確認安裝 NDK/CMake 後再執行 Gradle；以下指令假設原本 repo 已包含 `gradlew`：

```bash
sdkmanager --install "ndk;27.2.12479018" "cmake;3.22.1"
./gradlew assembleDebug
```

若 Actions 工作流程使用自己的建置命令，請把 `sdkmanager --install` 放在 Gradle 建置步驟之前。

## 驗證狀態與限制

- 已對照建置日誌修正 `clearStagedScriptLocked()` 缺失的 Java 編譯錯誤。
- 已確認 ZIP 內 `main.sh` 與原始檔位元組雜湊一致。
- 原生 C 原始碼已在本工作環境執行 Clang 語法檢查。
- 此工作環境沒有 Android SDK/NDK 或 Gradle，因此無法在這裡完成 Android APK 編譯、檢查 Android linker 相容性或實機驗證；仍需由 GitHub Actions 建置並在手機上測試。
