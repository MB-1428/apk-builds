package com.example.termiglow;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 14, 24);
    private final int PANEL = Color.rgb(14, 27, 43);
    private final int GREEN = Color.rgb(39, 230, 166);
    private final int WHITE = Color.rgb(226, 239, 250);
    private final int MUTED = Color.rgb(133, 158, 181);
    private EditText scriptInput;
    private TextView output;
    private TextView status;
    private Button runButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile Process activeProcess;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        appendOutput("TermiGlow v1.0  •  Android Shell\n");
        appendOutput("提示：腳本會在 App 私有目錄執行。\n");
        appendOutput("輸入 Shell 命令或貼上 .sh 腳本，按「執行」。\n\n");
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(14), dp(18), dp(12));
        page.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = new TextView(this);
        logo.setText(">_");
        logo.setTextColor(GREEN);
        logo.setTextSize(25);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        logo.setPadding(dp(12), dp(7), dp(12), dp(7));
        logo.setBackground(round(PANEL, 14, GREEN, 1));
        header.addView(logo);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        TextView title = label("TermiGlow", 22, WHITE, true);
        TextView subtitle = label("ANDROID SHELL WORKSPACE", 10, MUTED, true);
        titles.addView(title); titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = label("● READY", 11, GREEN, true);
        header.addView(badge);
        page.addView(header);

        TextView intro = label("你的行動終端", 18, WHITE, true);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(24);
        page.addView(intro, introLp);
        TextView hint = label("執行腳本 · 即時輸出 · 本機工作區", 12, MUTED, false);
        page.addView(hint);

        TextView scriptLabel = label("SCRIPT EDITOR", 11, GREEN, true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(20);
        page.addView(scriptLabel, slp);

        scriptInput = new EditText(this);
        scriptInput.setGravity(Gravity.TOP | Gravity.START);
        scriptInput.setTextSize(13);
        scriptInput.setTypeface(Typeface.MONOSPACE);
        scriptInput.setTextColor(WHITE);
        scriptInput.setHintTextColor(MUTED);
        scriptInput.setHint("#!/system/bin/sh\necho Hello from Android\n");
        scriptInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        scriptInput.setMinLines(5);
        scriptInput.setMaxLines(9);
        scriptInput.setHorizontallyScrolling(true);
        scriptInput.setBackground(round(PANEL, 14, Color.rgb(34, 58, 79), 1));
        page.addView(scriptInput, new LinearLayout.LayoutParams(-1, dp(170)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = dp(12);
        page.addView(actions, alp);

        runButton = actionButton("▶  執行腳本", GREEN, BG);
        actions.addView(runButton, new LinearLayout.LayoutParams(0, dp(46), 1.2f));
        Button clear = actionButton("清除輸出", PANEL, WHITE);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(46), 1);
        clp.leftMargin = dp(9);
        actions.addView(clear, clp);
        runButton.setOnClickListener(v -> runScript());
        clear.setOnClickListener(v -> output.setText(""));

        LinearLayout outHeader = new LinearLayout(this);
        outHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView outTitle = label("TERMINAL OUTPUT", 11, GREEN, true);
        outHeader.addView(outTitle, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("● IDLE", 10, MUTED, true);
        outHeader.addView(status);
        LinearLayout.LayoutParams ohp = new LinearLayout.LayoutParams(-1, -2);
        ohp.topMargin = dp(22);
        page.addView(outHeader, ohp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(round(Color.rgb(3, 8, 14), 14, Color.rgb(29, 49, 66), 1));
        output = new TextView(this);
        output.setTextColor(GREEN);
        output.setTextSize(12);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(14), dp(14), dp(14), dp(14));
        output.setTextIsSelectable(true);
        scroll.addView(output);
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(10);
        page.addView(scroll, outLp);

        TextView footer = label("本機執行環境  •  不提供 root 權限", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(12);
        page.addView(footer, flp);

        setContentView(page);
    }

    private void runScript() {
        final String source = scriptInput.getText().toString();
        if (source.trim().isEmpty()) {
            Toast.makeText(this, "請先輸入腳本內容", Toast.LENGTH_SHORT).show();
            return;
        }
        runButton.setEnabled(false);
        status.setText("● RUNNING");
        status.setTextColor(GREEN);
        appendOutput("\n$ ./script.sh\n");
        executor.execute(() -> {
            File script = new File(getFilesDir(), "current_script.sh");
            try {
                java.io.FileOutputStream fos = new java.io.FileOutputStream(script);
                fos.write(source.getBytes("UTF-8"));
                fos.close();
                ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", script.getAbsolutePath());
                pb.directory(getFilesDir());
                pb.redirectErrorStream(true);
                activeProcess = pb.start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(activeProcess.getInputStream(), "UTF-8"));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String result = line;
                    runOnUiThread(() -> appendOutput(result + "\n"));
                }
                int code = activeProcess.waitFor();
                runOnUiThread(() -> {
                    appendOutput("\n[process exited: " + code + "]\n");
                    status.setText(code == 0 ? "● SUCCESS" : "● EXIT " + code);
                    status.setTextColor(code == 0 ? GREEN : Color.rgb(255, 111, 120));
                    runButton.setEnabled(true);
                });
            } catch (Exception e) {
                final String message = e.toString();
                runOnUiThread(() -> {
                    appendOutput("[error] " + message + "\n");
                    status.setText("● ERROR");
                    status.setTextColor(Color.rgb(255, 111, 120));
                    runButton.setEnabled(true);
                });
            } finally {
                activeProcess = null;
            }
        });
    }

    private void appendOutput(String text) {
        output.append(text);
        if (output.getParent() instanceof ScrollView) {
            ScrollView s = (ScrollView) output.getParent();
            s.post(() -> s.fullScroll(View.FOCUS_DOWN));
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(13); b.setTextColor(fg);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(bg, 13, bg == GREEN ? GREEN : Color.rgb(37, 61, 82), 1));
        return b;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }
    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (activeProcess != null) activeProcess.destroy();
        executor.shutdownNow();
    }
}
