#!/usr/bin/env python3
"""
fetch_ghostlock_profiles.py
遍历 GitHub 仓库 YuKongA/ghostlock-app 的 kernel_profiles 目录，
下载所有 .conf 文件（含 index.conf 及共享文件），
并可选地将其覆盖写入本地 assets/kernel_profiles/ 目录。

用法：
  python3 fetch_ghostlock_profiles.py               # 下载到当前目录的 kernel_profiles/
  python3 fetch_ghostlock_profiles.py --dry-run     # 仅列出文件，不下载
  python3 fetch_ghostlock_profiles.py --out /path/to/assets/kernel_profiles
  python3 fetch_ghostlock_profiles.py --token <GITHUB_TOKEN>  # 解除 API 速率限制
"""

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

# ─── 常量 ─────────────────────────────────────────────────────
REPO         = "YuKongA/ghostlock-app"
BRANCH       = "main"
ASSETS_PATH  = "app/src/main/assets/kernel_profiles"
API_BASE     = "https://api.github.com"
RAW_BASE     = f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/{ASSETS_PATH}"
API_TREE_URL = (
    f"{API_BASE}/repos/{REPO}/git/trees/{BRANCH}"
    f"?recursive=1"
)
API_DIR_URL  = f"{API_BASE}/repos/{REPO}/contents/{ASSETS_PATH}"

# 速率限制：未认证为 60 req/h，认证为 5000 req/h
RATE_SLEEP   = 1.2   # 未认证时每次请求间隔（秒）


# ─── 工具函数 ─────────────────────────────────────────────────

def build_headers(token: str | None) -> dict:
    h = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "MOBAI-CloudUpdate/1.0",
    }
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def fetch_json(url: str, headers: dict, retries: int = 3) -> dict | list:
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 403 and "rate limit" in e.read().decode().lower():
                wait = 60
                print(f"  [速率限制] 等待 {wait}s …", file=sys.stderr)
                time.sleep(wait)
            elif e.code == 404:
                raise RuntimeError(f"资源不存在：{url}") from e
            else:
                raise
        except Exception as exc:
            if attempt == retries - 1:
                raise
            print(f"  [重试 {attempt+1}/{retries}] {exc}", file=sys.stderr)
            time.sleep(2 ** attempt)
    raise RuntimeError(f"请求失败：{url}")


def fetch_raw(url: str, headers: dict) -> bytes:
    h = {k: v for k, v in headers.items()
         if k not in ("Accept",)}          # raw 不需要 JSON Accept
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ─── 遍历逻辑 ─────────────────────────────────────────────────

def list_conf_files_via_tree(headers: dict) -> list[str]:
    """
    用 Git Trees API（递归）遍历整个仓库树，
    筛选 ASSETS_PATH 下的 .conf 文件；一次请求即可。
    """
    print(f"[遍历] 获取仓库文件树（{REPO}@{BRANCH}）…")
    data = fetch_json(API_TREE_URL, headers)

    prefix = ASSETS_PATH + "/"
    names: list[str] = []
    for item in data.get("tree", []):
        path: str = item.get("path", "")
        if (
            item.get("type") == "blob"
            and path.startswith(prefix)
            and path.endswith(".conf")
        ):
            names.append(path[len(prefix):])   # 只保留文件名

    names.sort()
    print(f"[遍历] 发现 {len(names)} 个 .conf 文件")
    return names


def list_conf_files_via_contents(headers: dict) -> list[str]:
    """
    备用：用 Contents API 列出目录（无需递归，单层即可）。
    """
    print(f"[遍历] 获取目录列表（{API_DIR_URL}）…")
    items = fetch_json(API_DIR_URL, headers)
    names = [
        item["name"]
        for item in items
        if item.get("type") == "file" and item["name"].endswith(".conf")
    ]
    names.sort()
    print(f"[遍历] 发现 {len(names)} 个 .conf 文件")
    return names


# ─── 主流程 ───────────────────────────────────────────────────

def run(args: argparse.Namespace) -> None:
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    headers = build_headers(args.token)
    delay   = 0.0 if args.token else RATE_SLEEP

    # 1. 遍历获取文件列表
    try:
        conf_files = list_conf_files_via_tree(headers)
    except Exception as exc:
        print(f"[警告] Trees API 失败（{exc}），改用 Contents API", file=sys.stderr)
        conf_files = list_conf_files_via_contents(headers)

    if not conf_files:
        print("[错误] 未找到任何 .conf 文件，请检查仓库路径", file=sys.stderr)
        sys.exit(1)

    if args.dry_run:
        print("\n[试运行] 将下载以下文件：")
        for name in conf_files:
            print(f"  {name}")
        print(f"\n共 {len(conf_files)} 个文件，目标目录：{out_dir.resolve()}")
        return

    # 2. 逐一下载
    ok = skipped = failed = 0
    for i, name in enumerate(conf_files, 1):
        raw_url  = f"{RAW_BASE}/{name}"
        dest     = out_dir / name
        progress = f"[{i:3d}/{len(conf_files)}]"

        try:
            data = fetch_raw(raw_url, headers)
        except Exception as exc:
            print(f"{progress} ✗ 下载失败：{name}  ({exc})", file=sys.stderr)
            failed += 1
            continue

        # 比较已有文件，相同则跳过
        if dest.exists() and sha256_file(dest) == sha256_bytes(data):
            print(f"{progress} = 无变化，跳过：{name}")
            skipped += 1
        else:
            dest.write_bytes(data)
            print(f"{progress} ✓ 已写入：{name}  ({len(data)} 字节)")
            ok += 1

        if delay > 0:
            time.sleep(delay)

    # 3. 汇总
    print(f"\n完成：✓ 更新 {ok} 个  = 跳过 {skipped} 个  ✗ 失败 {failed} 个")
    print(f"输出目录：{out_dir.resolve()}")

    if failed:
        sys.exit(1)


# ─── CLI ──────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="遍历下载 ghostlock-app 的所有 kernel_profiles .conf 文件"
    )
    parser.add_argument(
        "--out", "-o",
        default="kernel_profiles",
        metavar="DIR",
        help="输出目录（默认：./kernel_profiles）",
    )
    parser.add_argument(
        "--token", "-t",
        default=os.environ.get("GITHUB_TOKEN"),
        metavar="TOKEN",
        help="GitHub Personal Access Token（或设置环境变量 GITHUB_TOKEN）",
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        help="仅列出待下载文件，不实际写入",
    )
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
