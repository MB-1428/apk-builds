# MOBAI v30 程式優化紀錄

## 本次修改範圍

本次以保留既有介面與功能為原則，只修改終端機 UI 更新及 Liquid Glass 模糊繪製：

- `app/src/main/java/com/example/termiglow/MainActivity.java`
- `app/src/main/java/com/example/termiglow/GlassLayout.java`

沒有修改 `main.sh`、`libGhostlock.so`、Kernel Profile、Shizuku 服務協定或 GhostLock 執行流程。

## 1. MainActivity.java：終端機輸出批次化

### 原本問題

PTY／Pipe 每收到一段輸出，原本就會立即執行多項 UI 操作：

- 將字串追加到 TextView。
- 更新快速選項按鈕。
- 重新整理 Liquid Glass 背景快照。
- 強制捲動到終端機底部。

輸出頻率高時，會造成主執行緒頻繁排程及重繪；即使使用者正在查看舊日誌，也會被拉回底部。

### 修改內容

1. 新增 40 ms 輸出緩衝批次。背景執行緒只負責把文字加入佇列，TextView 更新集中到主執行緒。
2. 批次合併後才執行 ANSI 解析，保留跨讀取區塊的 ANSI escape sequence 狀態。
3. 每批只更新一次快速選項、導覽玻璃快照與捲動位置。
4. 只有使用者原本就在底部附近時才自動跟隨新輸出；向上閱讀時保留目前位置。
5. 終端機保留上限設為 120,000 字元，快速選單分析緩衝維持 4,000 字元，避免長時間輸出造成無限制累積。
6. 清除畫面時同時清理待顯示佇列，避免已排隊的舊輸出在清除後重新出現。
7. Activity 銷毀時停止接收新的 UI 輸出並清空已排程的更新。
8. 將快速選單與結束代碼的正規表示式改成靜態預編譯，避免重複建立 Pattern。

## 2. GlassLayout.java：降低模糊計算與 GC 成本

### 原本問題

原本的水平／垂直 Box Blur 對每個輸出像素，都重新累加 `2r + 1` 個鄰近像素。每次刷新還會建立兩個新的 `int[]` 緩衝區。

### 修改內容

1. 改成滑動視窗累加：每往右／往下一個像素，只扣除離開視窗的像素並加入新像素。
2. 單次模糊掃描的工作量由約 `O(width × height × radius)` 降為 `O(width × height)`。
3. 將兩個像素緩衝區保留為 View 欄位，尺寸不變時重複使用，降低短時間大量配置陣列造成的 GC 壓力。
4. 重用 Bitmap 繪製用的 Rect，避免每次 `onDraw()` 都建立新的矩形物件。
5. 保留原本邊界延伸、兩輪水平／垂直模糊、縮小快照與 Liquid Glass 高光效果。

## 3. 驗證結果

| 檢查項目 | 結果 |
|---|---|
| 新舊 Box Blur 數值等價性 | 通過；測試影像寬高 1–12、半徑 0–4、水平與垂直方向 |
| `fetch_ghostlock_profiles.py` Python 語法檢查 | 通過 |
| `pty_bridge.c` Clang 語法檢查 | 通過 |
| 完整 Android Gradle APK 建置 | 未執行；目前環境沒有 Gradle、Android SDK／NDK |
| Android 實機效能測試 | 未執行；沒有裝置端 FPS、耗時或記憶體數據 |

## 4. 建置環境

依專案 README，建議使用：

- JDK 17
- Gradle 8.9
- Android SDK Platform 35
- Android NDK `27.2.12479018`
- CMake `3.22.1`

專案 ZIP 沒有包含 Gradle Wrapper，因此建置命令為：

```bash
gradle assembleDebug
```

## 5. 尚待處理的項目

以下屬於後續安全性／可靠性工作，本次沒有改動：

- GhostLock Profile 雲端快取目前主要以 `Content-Length` 判斷是否跳過下載；相同大小但內容不同時，可能誤判為無更新。較可靠的方式是使用 ETag／內容雜湊，並以暫存檔完成後再原子替換。
- 主腳本雲端更新快取應加入版本／雜湊驗證與原子寫入，避免下載中斷留下不完整快取。由於該腳本會進入裝置權限執行流程，本次不改動其下載或執行行為。
- README 中的產品版本文字與 Gradle `versionName`（`2.2`）不一致；需要先確認正式版本號，再統一更新，避免影響既有 APK 升級判定。
- 目前只能確認原生 C 語法檢查通過，尚不能等同 Android NDK 完整連結或手機實機正常。

## 6. 建議實機回歸測試

1. 開啟終端機，執行會連續輸出大量文字的正常測試腳本，確認 UI 不再因頻繁輸出而明顯卡頓。
2. 輸出期間向上滑動查看舊日誌，確認畫面不會被自動拉回底部。
3. 輸出期間按「清除」，確認舊佇列不會重新顯示。
4. 使用會跨多個讀取區塊輸出 ANSI 色彩控制碼的測試文字，確認顏色不會錯位。
5. 開啟／關閉 Liquid Glass 模糊與高光，確認外觀設定仍正常。
6. 用 JDK 17 與指定 SDK／NDK 執行 `gradle assembleDebug`，再於 arm64-v8a 裝置安裝測試。

> 本次是程式碼層級的效能優化，不宣稱已取得實機 FPS 提升比例；實際改善程度仍須以相同裝置、相同輸出量的前後測量確認。
