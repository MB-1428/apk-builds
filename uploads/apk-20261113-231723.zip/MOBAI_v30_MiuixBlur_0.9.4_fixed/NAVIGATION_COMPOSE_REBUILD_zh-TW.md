# MOBAI v30 — Kotlin Compose + Miuix 0.9.4 Liquid Glass 導航

## 修改目標

只替換主畫面的四項分頁導航 UI，並把 Miuix Blur 0.9.4 接入導航玻璃背景。終端、設置、Root、關於四個頁面仍由原本的 `MainActivity.java` 建立；Shizuku、PTY、Shell、GhostLock、設定儲存與原生橋接流程繼續由 Java 負責。

## 架構與背景資料流

```text
MainActivity.java
  ├─ buildTerminalPage()
  ├─ buildSettingsPage()
  ├─ buildRootPage()
  ├─ buildAboutPage()
  └─ GlassLayout.java
       ├─ 擷取目前 Java 頁面在導航區域後方的 Bitmap
       ├─ API 24–32：執行舊式低成本模糊作為相容 fallback
       └─ BackdropListener -> LiquidGlassNavigationView.setBackdropBitmap()
            └─ LiquidGlassNavigation.kt
                 ├─ Image(Bitmap) + Modifier.layerBackdrop()
                 ├─ Miuix Modifier.textureBlur()
                 ├─ Miuix Highlight.GlassStrokeMiddleLight / GlassStrokeBigLight
                 ├─ 四個導航項目與連續索引選取膠囊
                 ├─ Spring 彈簧動畫、拖曳與放手吸附
                 └─ 漸層玻璃與互動光斑
```

`LayerBackdrop` 只能擷取 Compose 自己繪製的內容，不能直接讀取外部 Java View。因此這個專案採用 Java `GlassLayout` 擷取頁面 Bitmap，再將 Bitmap 傳給 Compose；Compose 將它繪製成背景 Image，最後讓 Miuix `layerBackdrop()` 擷取該 Image，供 `textureBlur()` 使用。

Java 透過 `LiquidGlassNavigationView.setSelectedIndex()` 將頁面狀態同步給 Compose；Compose 透過 `OnNavigationTabSelectedListener` 回呼 `MainActivity.showPage(index)`。頁面切換仍由原本 Java Activity 負責。

## Miuix Blur 與 Android 相容性

- Miuix Blur：`top.yukonga.miuix.kmp:miuix-blur-android:0.9.4`。
- Miuix 0.9.4 對應 Kotlin 2.4.20 與 Compose Multiplatform 1.12.0。
- Miuix Android Blur 的 RuntimeShader 路徑需要 Android 13（API 33）或更高版本；程式以 `isRuntimeShaderSupported()` 進行 runtime capability check。
- `minSdk` 保持 24。Manifest 使用官方範例採用的 `tools:overrideLibrary="top.yukonga.miuix.kmp.blur"`，允許低版本安裝；API 24–32 不執行 Miuix RuntimeShader，而是由 `GlassLayout` 提供預先模糊的 Bitmap fallback。
- API 32+ 建立 Miuix `LayerBackdrop`；只有 RuntimeShader 能力存在時才套用 `textureBlur` 與 Highlight。
- Android 13+ 的導航底板與選取膠囊使用 Miuix `textureBlur`，並依液態玻璃設定套用 Miuix 邊緣高光。

## 建置設定

- Android Gradle Plugin：8.7.3（保留原版）
- Kotlin Android / Compose Compiler Plugin：2.4.20
- Compose Multiplatform：1.12.0
- Miuix Blur：0.9.4
- compileSdk：35
- minSdk：24（不變）
- targetSdk：28（不變）
- ABI：arm64-v8a（不變）
- Java/Kotlin JVM target：17（Kotlin 使用新版 `compilerOptions` DSL）
- Gradle：建議使用 Gradle 8.9（AGP 8.7.3 的最低 Gradle 版本）；Kotlin 2.4.20 本身支援 Gradle 7.6.3–9.7.0。

使用 Android Studio 開啟專案根目錄 `MOBAI/`，等待 Gradle Sync，然後執行：

```bash
gradle :app:assembleDebug
```

## 修改檔案

1. `build.gradle`：更新 Kotlin Android 與 Compose compiler plugins 至 2.4.20。
2. `app/build.gradle`：移除舊 Compose BOM，對齊 Compose Multiplatform 1.12.0，新增 Miuix Blur 0.9.4。
3. `app/src/main/AndroidManifest.xml`：加入 Miuix Blur 的 `tools:overrideLibrary`，保持 minSdk 24。
4. `app/src/main/java/com/example/termiglow/LiquidGlassNavigation.kt`：以 Miuix `LayerBackdrop`、`textureBlur` 與 `Highlight` 繪製導航玻璃效果，保留選取動畫與拖曳互動。
5. `app/src/main/java/com/example/termiglow/GlassLayout.java`：改為 Java 頁面背景擷取器，將快照回傳 Compose；API 24–32 提供模糊 fallback。
6. `app/src/main/java/com/example/termiglow/MainActivity.java`：只調整導航初始化順序，接上 Java 快照與 Compose callback；頁面及既有功能邏輯不搬動。

## 建議驗收

- 點擊四個導航項目，確認分頁內容正確。
- 快速連續切換，確認膠囊與頁面索引同步。
- 在導航膠囊上左右拖曳，確認位置連續、放開後吸附到最近分頁。
- 切換模糊與液態玻璃設定，確認即時生效。
- API 24–32：確認不呼叫 RuntimeShader，顯示 Java 預模糊 fallback。
- API 33+：確認 Miuix 背景 Blur 與邊緣 Highlight 生效。
- 檢查橫向／平板側邊導航排列、TalkBack selected 語意與終端輸出更新。

## 驗證限制

目前執行環境沒有 Android SDK、Gradle 執行檔或可用的 Android build cache，因此無法在此產生 APK，也不能宣稱已通過實際 Gradle 編譯。請在 Android Studio 完成第一次 Gradle Sync／Build 後再進行實機驗收。本次會檢查原始碼結構、Manifest XML、版本設定與 ZIP 完整性。
