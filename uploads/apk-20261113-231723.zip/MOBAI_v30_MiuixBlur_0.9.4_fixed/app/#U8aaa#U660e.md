GhostLock 集成完整指南（Termiglow / MOBAI 项目）

文档版本：基于 GhostLock-App 官方仓库 2026-07-28 文档状态与你的项目结构编写。
目标：在现有的 Android 终端应用（com.example.termiglow）中集成 GhostLock，实现“点击按钮 → 自动检测内核 → 触发 GhostLock 加载 KernelSU 模块”的功能。不涉及 main.sh 的接管或交互式 shell 提供。
许可证：GhostLock 采用 Apache License 2.0 。

一、集成前提与约束（必须理解）

1.1 GhostLock 能做什么

GhostLock 利用 CVE-2026-43499 在受支持的内核上获取临时 root，并加载 KernelSU 模块 。它被设计为一次性执行：拿到 uid 0 后加载模块，执行完即退出。它不提供交互式 root shell，也不支持 --exec <command> 之类的参数来接管你的命令 。

1.2 硬性门槛

约束 说明
内核精确匹配 GhostLock 按 uname -r 完整字符串匹配 profile，任何字符差异直接拒绝运行 
需要 ksud 模块加载需要 KernelSU、ReSukiSU、BakaSU 或 KowSU 提供的 ksud。缺 ksud 时 W1/W2 仍能拿到 uid 0，但不会加载任何模块 
Shizuku 依赖（部分内核） 标记为 recommend_shizuku = 1 的 profile 需要通过 Shizuku 的 UserService 执行 
临时性 重启后权限清除，不持久化
adb 路径差异 通过 adb shell 执行会跳过 W3 seccomp 绕过阶段，因为 adb shell 本身没有 seccomp 过滤 

1.3 关于“找不到就提示无法使用”

你的需求是自动扫描匹配，找不到就提示。这是正确且安全的做法。GhostLock 官方 App 本身也是这种逻辑：不匹配的内核直接拒绝运行，并在界面显示状态 。

二、需要放入项目的文件

2.1 文件清单

文件 来源 放置位置
libghostlock.so GhostLock Release 中的 ghostlock 二进制，重命名 app/src/main/jniLibs/arm64-v8a/
*.conf（所有 profile） GhostLock Release 中的 GhostLock-kernel-profiles.zip app/src/main/assets/ghostlock/kernel_profiles/
GhostLockManager.java 本文档提供 app/src/main/java/com/example/termiglow/

2.2 为什么二进制必须重命名为 .so 并放入 jniLibs

Android 10+ 强制执行 W^X 策略，禁止应用在可写目录（如 filesDir、cacheDir）执行二进制文件 。即使 chmod 755 也会报 Permission denied。

唯一可靠的方式是将二进制以 lib<name>.so 的形式放入 jniLibs。系统在安装 APK 时会将其解压到 nativeLibraryDir（/data/app/.../lib/arm64/），该目录只读且可执行，绕过 W^X 限制 。

你的 app/build.gradle 已配置 abiFilters 'arm64-v8a'，与 GhostLock 二进制的 AArch64 架构匹配，无需修改 ABI 配置。

2.3 Profile 文件命名规则

profile 文件名必须与目标设备的 uname -r 完全一致，格式为：

```
<uname -r 完整字符串>.conf
```

例如：6.6.118-android15-8-g2e6b9c3812c5-ab15114928-4k.conf

GhostLock 官方 App 的内置 profile 位于 app/src/main/assets/kernel_profiles/，index.conf 保存运行索引 。在你的集成中，index.conf 不是必须的，因为我们的自动扫描逻辑直接遍历目录，不依赖索引。但如果你希望与 GhostLock 的资产结构保持兼容，可以一并放入。

三、核心代码：GhostLockManager.java

将以下文件放入 app/src/main/java/com/example/termiglow/GhostLockManager.java：

```java
package com.example.termiglow;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * GhostLock 临时 root 集成管理器。
 *
 * 职责：
 *  1. 读取 uname -r
 *  2. 自动扫描 assets/ghostlock/kernel_profiles/ 下的所有 .conf 文件
 *  3. 精确匹配内核后，释放 profile 并调用 GhostLock 二进制加载 KernelSU 模块
 *
 * 约束：
 *  - 二进制必须位于 jniLibs/arm64-v8a/libghostlock.so
 *  - profile 文件名必须与 uname -r 完全一致
 *  - 不提供 shell，不接管 main.sh
 */
public final class GhostLockManager {
    private static final String TAG = "GhostLock";
    private static final String ASSET_DIR = "ghostlock/kernel_profiles";
    private static final String BIN_NAME = "libghostlock.so";

    public enum Result {
        SUCCESS,        // 执行成功（退出码 0）
        EXEC_FAILED,    // 执行失败（退出码非 0）
        NO_PROFILE,     // 内核不匹配
        NO_BINARY,      // 二进制缺失
        ERROR           // 其他异常
    }

    public static final class Outcome {
        public final Result result;
        public final String kernelRelease;
        public final String detail;
        public final List<String> availableProfiles;

        Outcome(Result r, String kernel, String detail, List<String> profiles) {
            this.result = r;
            this.kernelRelease = kernel;
            this.detail = detail;
            this.availableProfiles = profiles;
        }
    }

    private final Context context;

    public GhostLockManager(Context context) {
        this.context = context.getApplicationContext();
    }

    /** 执行 uname -r，返回内核版本字符串 */
    public String getKernelRelease() {
        try {
            Process p = new ProcessBuilder("uname", "-r")
                    .redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine();
            p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            Log.w(TAG, "uname -r failed", e);
            return "";
        }
    }

    /** 列出 assets 里所有 profile 的 release 名（去掉 .conf 后缀） */
    public List<String> listAvailableProfiles() {
        List<String> out = new ArrayList<>();
        try {
            String[] list = context.getAssets().list(ASSET_DIR);
            if (list == null) return out;
            for (String name : list) {
                if (name.endsWith(".conf")) {
                    out.add(name.substring(0, name.length() - 5));
                }
            }
        } catch (IOException e) {
            Log.w(TAG, "list profiles failed", e);
        }
        return out;
    }

    /**
     * 执行 GhostLock：
     *  1. 检查二进制是否存在
     *  2. 读取 uname -r，匹配 assets 中的 profile
     *  3. 释放匹配的 profile 到 filesDir
     *  4. 调用 libghostlock.so --load-prebuilt-profile <profile>
     */
    public Outcome run() {
        String kernel = getKernelRelease();
        if (kernel.isEmpty()) {
            return new Outcome(Result.ERROR, kernel,
                    "無法讀取 uname -r", listAvailableProfiles());
        }

        // 1. 检查二进制
        File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
        if (!bin.exists() || !bin.canExecute()) {
            return new Outcome(Result.NO_BINARY, kernel,
                    "未找到 " + BIN_NAME + "（請確認已放入 jniLibs/arm64-v8a/）",
                    listAvailableProfiles());
        }

        // 2. 精确匹配 profile
        String targetAsset = ASSET_DIR + "/" + kernel + ".conf";
        if (!assetExists(targetAsset)) {
            return new Outcome(Result.NO_PROFILE, kernel,
                    "當前內核 " + kernel + " 不在 GhostLock 支援列表",
                    listAvailableProfiles());
        }

        // 3. 释放 profile
        File profileFile;
        try {
            profileFile = new File(context.getFilesDir(), "gl_" + kernel + ".conf");
            try (InputStream in = context.getAssets().open(targetAsset);
                 FileOutputStream out = new FileOutputStream(profileFile)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            }
        } catch (IOException e) {
            return new Outcome(Result.ERROR, kernel,
                    "釋放 profile 失敗: " + e.getMessage(),
                    listAvailableProfiles());
        }

        // 4. 执行 GhostLock
        Process proc = null;
        try {
            proc = new ProcessBuilder(
                    bin.getAbsolutePath(),
                    "--load-prebuilt-profile", profileFile.getAbsolutePath()
            ).redirectErrorStream(true).start();

            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            int code = proc.waitFor();
            String output = sb.toString().trim();
            if (code == 0) {
                return new Outcome(Result.SUCCESS, kernel, output, listAvailableProfiles());
            } else {
                return new Outcome(Result.EXEC_FAILED, kernel,
                        "exit " + code + (output.isEmpty() ? "" : ": " + output),
                        listAvailableProfiles());
            }
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles());
        } finally {
            if (proc != null) proc.destroy();
            if (profileFile.exists()) profileFile.delete();
        }
    }

    private boolean assetExists(String path) {
        try (InputStream ignored = context.getAssets().open(path)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
```

四、UI 接入：在现有界面中添加按钮

4.1 按钮放置位置

在你的 MainActivity 的 buildTerminalPage() 或 buildSettingsPage() 方法中，添加一个按钮。以下示例放在设置页，因为它与终端功能无关，是一个独立的附加功能。

在 buildSettingsPage() 方法的 return page; 之前插入：

```java
// ---- GhostLock 临时 Root 按钮 ----
GhostLockManager glManager = new GhostLockManager(this);

Button glButton = actionButton("臨時 Root（GhostLock）", ACCENT, Color.WHITE);
glButton.setOnClickListener(v -> {
    glButton.setEnabled(false);
    appendOutput("\n▶ 正在嘗試 GhostLock 臨時提權…\n");

    executor.execute(() -> {
        GhostLockManager.Outcome o = glManager.run();

        runOnUiThread(() -> {
            glButton.setEnabled(true);
            switch (o.result) {
                case SUCCESS:
                    appendOutput("✔ GhostLock 執行完成。\n");
                    if (!o.detail.isEmpty()) {
                        appendOutput(o.detail + "\n");
                    }
                    appendOutput("  注意：臨時權限在重啟後失效。\n");
                    updatePrivilegeStatus("GhostLock（臨時）");
                    break;

                case NO_PROFILE:
                    appendOutput("⚠ GhostLock 無法使用：內核 " + o.kernelRelease + " 不在支援列表。\n");
                    if (!o.availableProfiles.isEmpty()) {
                        appendOutput("  已內置的內核：\n");
                        for (String p : o.availableProfiles) {
                            appendOutput("    · " + p + "\n");
                        }
                    } else {
                        appendOutput("  （assets 中未找到任何 profile 文件）\n");
                    }
                    break;

                case NO_BINARY:
                    appendOutput("⚠ GhostLock 無法使用：" + o.detail + "\n");
                    break;

                case EXEC_FAILED:
                    appendOutput("⚠ GhostLock 執行失敗（" + o.detail + "）。\n");
                    break;

                case ERROR:
                default:
                    appendOutput("⚠ GhostLock 出錯：" + o.detail + "\n");
                    break;
            }
        });
    });
});

LinearLayout.LayoutParams glLp = new LinearLayout.LayoutParams(-1, dp(52));
glLp.topMargin = dp(12);
page.addView(glButton, glLp);
```

4.2 修改 AndroidManifest.xml（确保 extractNativeLibs 为 true）

在你的 AndroidManifest.xml 的 <application> 标签中添加：

```xml
<application
    android:allowBackup="true"
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher"
    android:label="MOBAI"
    android:extractNativeLibs="true"    <!-- 新增此行 -->
    android:theme="@android:style/Theme.Material.NoActionBar">
```

为什么需要这一行：extractNativeLibs="true" 确保 APK 安装时 jniLibs 中的 .so 文件被解压到 nativeLibraryDir。如果为 false（Android 6.0+ 在某些配置下的默认值），二进制可能不会被释放到文件系统，导致无法执行 。

五、打包步骤（手动操作清单）

5.1 获取 GhostLock 二进制和 Profile

从 GhostLock Release 页面下载：

· ghostlock（arm64-v8a 独立二进制）
· GhostLock-kernel-profiles.zip（内核 profile 包）

5.2 放置二进制

```bash
# 在你的项目根目录执行
mkdir -p app/src/main/jniLibs/arm64-v8a
cp /path/to/ghostlock app/src/main/jniLibs/arm64-v8a/libghostlock.so
```

必须重命名为 libghostlock.so，否则系统不会将其视为 native library 处理。

5.3 放置 Profile

```bash
mkdir -p app/src/main/assets/ghostlock/kernel_profiles
unzip GhostLock-kernel-profiles.zip -d /tmp/gl_profiles
cp /tmp/gl_profiles/*.conf app/src/main/assets/ghostlock/kernel_profiles/
```

5.4 验证目录结构

最终项目应包含：

```
app/
├── src/main/
│   ├── jniLibs/arm64-v8a/libghostlock.so
│   ├── assets/ghostlock/kernel_profiles/
│   │   ├── 6.6.118-android15-8-g2e6b9c3812c5-ab15114928-4k.conf
│   │   ├── 6.12.38-android16-5-g844001fb8721-ab14552068-4k.conf
│   │   └── ...（其他 profile）
│   └── java/com/example/termiglow/
│       ├── GhostLockManager.java   ← 新增
│       ├── MainActivity.java
│       └── ...
```

六、执行流程与结果解读

6.1 点击按钮后发生了什么

```
用户点击「臨時 Root（GhostLock）」
        │
        ▼
GhostLockManager.run()
        │
        ├─ 1. uname -r → 例如 "6.6.118-android15-8-g..."
        │
        ├─ 2. 扫描 assets/ghostlock/kernel_profiles/
        │     找 "6.6.118-android15-8-g...conf"
        │
        ├─ 3. 找到？──否──▶ Result.NO_PROFILE
        │      │               UI 提示「内核不在支援列表」
        │     是
        │      ▼
        ├─ 4. 释放 profile 到 filesDir
        │
        ├─ 5. 执行 libghostlock.so --load-prebuilt-profile <profile>
        │
        └─ 6. 读取退出码和输出
               │
               ├─ 退出码 0 ──▶ Result.SUCCESS
               │                UI 提示「执行完成」
               │
               └─ 退出码非 0 ──▶ Result.EXEC_FAILED
                                UI 提示失败详情
```

6.2 关于 SUCCESS 的准确含义

Result.SUCCESS 表示 GhostLock 进程退出码为 0。这不绝对等于“KernelSU 模块已加载”，因为：

· 如果设备缺少 ksud，GhostLock 可能在 W1/W2 阶段拿到 uid 0 后正常退出，但没有加载模块 。
· GhostLock 的输出文本可能包含模块加载状态，但官方不保证输出格式稳定。

建议的 UI 文案：使用“执行完成”而非“模块已加载”。如果希望更精确，可以解析输出中的关键词，但这不是可靠的做法。

6.3 关于 NO_PROFILE

这是预期中最常见的“无法使用”结果。UI 应展示：

· 当前设备的内核字符串
· 已内置的 profile 列表（供用户或开发者判断是否需要添加新 profile）

如果已内置列表为空，说明 assets/ghostlock/kernel_profiles/ 目录下没有 .conf 文件，需要检查打包步骤。

七、进阶：为未支持的内核生成 Profile

如果你的目标设备内核不在 GhostLock 内置列表中，可以使用官方提取器生成 profile。

7.1 编译提取器（需要 Rust）

```bash
cd tools/extract_rs
cargo build --release
```

7.2 从 boot.img 提取（高通设备）

```bash
build/extract/release/ghostlock-extract boot.img \
    --xbl-config xbl_config.img \
    --format conf \
    --out profile.conf
```

没有 xbl_config.img 时省略 --xbl-config 。

7.3 从 OTA ZIP 提取

```bash
build/extract/release/ghostlock-extract OTA.zip --format conf --out profile.conf
```

7.4 提取器的关键行为

行为 说明
输出是 unverified candidate 生成成功 ≠ 设备可用，App 执行前会校验缺失/无效字段 
不猜测缺失字段 只写入镜像实际解析出的字段，不会用相邻内核族的猜测值填充 
MediaTek 特殊处理 无 xbl_config.img 且通常无内嵌 BTF，物理加载地址由 kallsyms _text 推导，可用 --phys 覆盖 
remove_waiter() 已修复时 提取器以退出码 6 拒绝 

7.5 将生成的 profile 加入项目

```bash
cp profile.conf app/src/main/assets/ghostlock/kernel_profiles/<uname-r>.conf
```

文件名必须与目标设备的 uname -r 完全一致。

八、与 Shizuku / 现有权限链的关系

你的项目已经有一条完整的权限回退链：Shizuku → root (su) → 普通权限。GhostLock 按钮是独立的附加功能，不替代现有链路。

8.1 为什么保持独立

· GhostLock 不提供 shell，无法接管 main.sh 的 PTY 交互
· 你的现有 Shizuku 链路已经能覆盖“有 Shizuku”的用户
· 你的现有 su 链路已经能覆盖“有永久 root”的用户
· GhostLock 只对“既没 Shizuku 又没永久 root，但内核恰好匹配”的用户有价值

8.2 如果你希望将 GhostLock 加入自动回退链

可以在 requestRootFallback() 的 su 探测失败后，追加 GhostLock 检测。但不建议自动执行，因为 GhostLock 的 W3 阶段在部分内核上有 panic 风险，且执行需要用户知情。建议保持为显式按钮，由用户主动触发。

九、安全与体验注意事项

事项 建议
临时性告知 UI 明确提示“重启后失效”
缺少 ksud 的提示 如果 GhostLock 退出码为 0 但用户报告模块未生效，提示检查是否安装了 KernelSU 系管理器
W3 panic 风险 在目标内核上测试，必要时在 profile 中设 w3_attempts = 0（需要修改 profile，不是代码）
不要对全体用户展示按钮 可以在按钮点击后再检测，而不是启动时就检测（避免启动开销）
日志记录 将 GhostLock 的输出写入 appendOutput，方便用户反馈问题时提供信息

十、验收清单

☐ libghostlock.so 已放入 jniLibs/arm64-v8a/
☐ AndroidManifest.xml 中 extractNativeLibs="true"
☐ assets/ghostlock/kernel_profiles/ 下至少有一个 .conf 文件
☐ GhostLockManager.java 已添加到项目中
☐ 设置页的按钮已添加
☐ 在目标设备上测试：内核匹配时按钮执行后返回 SUCCESS 或 EXEC_FAILED
☐ 在非目标设备上测试：按钮执行后返回 NO_PROFILE，UI 正确显示当前内核和可用列表
☐ 确认执行后无 kernel panic（观察设备是否重启）
☐ 确认重启后临时权限已清除

十一、参考资源

资源 位置
GhostLock 主仓库 https://github.com/YuKongA/ghostlock-app
支持设备列表 docs/kernel_profiles/SUPPORTED_DEVICES_ZH.md
Profile 结构文档 docs/kernel_profiles/PROFILE_SCHEMA_ZH.md
Kernel Profile 适配指南 docs/kernel_profiles/README_ZH.md
命令行调试 README 中 “命令行调试” 章节 
偏移提取器源码 tools/extract_rs/
许可证 Apache License 2.0 

文档结束。 实现时请以 GhostLock 仓库的实际 CLI 参数和 profile 格式为准，本文档中的代码基于官方 README 公开信息编写，但 native 二进制的参数解析细节可能随版本变化。