package com.example.termiglow;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Captures the Java page content behind the Compose navigation and forwards that snapshot to
 * Miuix LayerBackdrop. On Android versions below API 33, the snapshot is pre-blurred here because
 * Miuix RuntimeShader blur is not available on those versions.
 */
final class GlassLayout extends FrameLayout {
    private static final int SCALE = 4;
    private static final int FALLBACK_BLUR_RADIUS = 5;

    interface BackdropListener {
        void onBackdropChanged(Bitmap bitmap);
    }

    private View source;
    private BackdropListener backdropListener;
    private Bitmap small;
    private int[] blurBufferA;
    private int[] blurBufferB;
    private boolean dirty = true;
    private long lastSnapshot;
    private boolean blurEnabled = true;

    GlassLayout(Context context, float radiusPx) {
        super(context);
        // The Compose child draws the glass surface; this container only captures page content.
        setWillNotDraw(false);
        setClipToPadding(false);
    }

    void setSource(View view) {
        source = view;
        refresh();
    }

    void setBackdropListener(BackdropListener listener) {
        backdropListener = listener;
        refresh();
    }

    void refresh() {
        dirty = true;
        invalidate();
    }

    void setBlurEnabled(boolean enabled) {
        if (blurEnabled == enabled) return;
        blurEnabled = enabled;
        dirty = true;
        invalidate();
    }

    void setLiquidGlass(boolean enabled) {
        // Retained for compatibility with existing MainActivity settings plumbing.
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        small = null;
        dirty = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (source != null && getWidth() > 0 && getHeight() > 0
                && source.getWidth() > 0 && source.getHeight() > 0) {
            updateBackdrop();
        }
    }

    private void updateBackdrop() {
        if (!dirty && small != null) return;
        long now = SystemClock.uptimeMillis();
        if (small != null && now - lastSnapshot < 50) {
            postInvalidateDelayed(50);
            return;
        }
        lastSnapshot = now;
        dirty = false;

        int w = Math.max(1, getWidth() / SCALE);
        int h = Math.max(1, getHeight() / SCALE);
        if (small == null || small.getWidth() != w || small.getHeight() != h) {
            small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        }
        small.eraseColor(0xFFF2F4F8);
        Canvas snapshotCanvas = new Canvas(small);
        snapshotCanvas.scale(1f / SCALE, 1f / SCALE);
        snapshotCanvas.translate(-getLeft(), -getTop());
        try {
            source.draw(snapshotCanvas);
        } catch (RuntimeException ignored) {
            // Keep the neutral fallback surface if a child cannot draw into a software canvas.
        }

        // The Miuix RuntimeShader path is API 33+. Older systems keep a low-cost Java fallback.
        if (blurEnabled && Build.VERSION.SDK_INT < 33) {
            blur(small, FALLBACK_BLUR_RADIUS);
        }

        BackdropListener listener = backdropListener;
        if (listener != null) listener.onBackdropChanged(small);
    }

    /** Separable box blur used only as the API 24–32 compatibility fallback. */
    private void blur(Bitmap bmp, int r) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int size = w * h;
        if (blurBufferA == null || blurBufferA.length != size) {
            blurBufferA = new int[size];
            blurBufferB = new int[size];
        }
        bmp.getPixels(blurBufferA, 0, w, 0, 0, w, h);
        for (int pass = 0; pass < 2; pass++) {
            pass1(blurBufferA, blurBufferB, w, h, r, true);
            pass1(blurBufferB, blurBufferA, w, h, r, false);
        }
        bmp.setPixels(blurBufferA, 0, w, 0, 0, w, h);
    }

    /** Sliding-window box blur: O(width * height), with clamped edge pixels. */
    private static void pass1(int[] src, int[] dst, int w, int h, int r, boolean horizontal) {
        int lines = horizontal ? h : w;
        int len = horizontal ? w : h;
        int radius = Math.max(0, r);
        int div = 2 * radius + 1;

        for (int line = 0; line < lines; line++) {
            int sr = 0, sg = 0, sb = 0;
            for (int k = -radius; k <= radius; k++) {
                int pos = Math.max(0, Math.min(len - 1, k));
                int px = horizontal ? src[line * w + pos] : src[pos * w + line];
                sr += (px >> 16) & 0xff;
                sg += (px >> 8) & 0xff;
                sb += px & 0xff;
            }

            for (int i = 0; i < len; i++) {
                int out = 0xff000000 | ((sr / div) << 16)
                        | ((sg / div) << 8) | (sb / div);
                if (horizontal) dst[line * w + i] = out;
                else dst[i * w + line] = out;

                if (i + 1 < len) {
                    int removePos = Math.max(0, Math.min(len - 1, i - radius));
                    int addPos = Math.max(0, Math.min(len - 1, i + radius + 1));
                    int remove = horizontal ? src[line * w + removePos]
                            : src[removePos * w + line];
                    int add = horizontal ? src[line * w + addPos]
                            : src[addPos * w + line];
                    sr += ((add >> 16) & 0xff) - ((remove >> 16) & 0xff);
                    sg += ((add >> 8) & 0xff) - ((remove >> 8) & 0xff);
                    sb += (add & 0xff) - (remove & 0xff);
                }
            }
        }
    }
}
