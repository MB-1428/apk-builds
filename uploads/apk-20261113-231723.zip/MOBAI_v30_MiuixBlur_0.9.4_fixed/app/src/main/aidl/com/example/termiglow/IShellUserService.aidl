package com.example.termiglow;

import com.example.termiglow.IShellOutputCallback;

interface IShellUserService {
    // Reserved transaction used by Shizuku to stop a UserService.
    void destroy() = 16777114;
    void exit() = 1;
    void beginScript(int totalBytes) = 2;
    void writeScriptChunk(in byte[] chunk) = 3;
    void startScript(String input, IShellOutputCallback callback) = 4;
    void abortScript() = 5;
    void writeInput(String text) = 6;
    void closeInput() = 7;
    void setUsePty(boolean usePty) = 8;

    // GhostLock：在 Shizuku（shell, uid=2000）进程内执行 GhostLock 二进制。
    // UserService 负责把字节流落到临时目录、chmod、执行、清理。
    // 返回格式 "exit=<code>\n<输出>"，由调用方解析。
    // shell 进程无 seccomp 过滤，W3 阶段会被跳过。
    String runGhostLock(in byte[] binaryBytes, in byte[] profileBytes) = 9;
}