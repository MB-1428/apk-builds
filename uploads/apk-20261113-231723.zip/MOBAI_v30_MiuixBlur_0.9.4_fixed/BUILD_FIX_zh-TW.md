# MOBAI v30 — Miuix Blur 0.9.4 建置修正

## 根因（依 GitHub Actions 2026-11-09 日誌）

`checkDebugAarMetadata` 顯示 Miuix Blur 0.9.4 與其 Compose 1.12.0 傳遞依賴要求：

- `compileSdk` 至少為 37。
- Compose `animation` / `foundation` 1.12.0 要求 Android Gradle Plugin (AGP) 9.1.0 或更新。
- 原專案仍使用 `compileSdk 35`、AGP 8.7.3，CI 又使用 Gradle 8.9，因此 AAR metadata 檢查失敗。

## 本次專案設定

| 項目 | 修正後 |
|---|---:|
| Android Gradle Plugin | 9.2.0 |
| Gradle | 9.4.1（CI 執行器必須同步設定） |
| compileSdk | 37 |
| minSdk | 24（保留） |
| targetSdk | 28（保留） |
| Kotlin / Compose Compiler Plugin | 2.4.20 |
| Miuix Blur | 0.9.4 |

AGP 9.2.0 要求 Gradle 9.4.1，支援到 API 37。Kotlin Gradle Plugin 2.4.20 的官方相容範圍涵蓋 AGP 9.2 與 Gradle 9.4.1。

## CI 執行器也必須修改

這個 ZIP 本身沒有 Gradle Wrapper，原先 GitHub Actions 是直接 provision Gradle 8.9。請在建置工作流程的 Gradle setup 步驟將版本改成 `9.4.1`，例如：

```yaml
- name: Setup Gradle
  uses: gradle/actions/setup-gradle@v3.5.0
  with:
    gradle-version: '9.4.1'

- name: Build APK
  run: gradle assembleDebug --no-daemon --stacktrace
```

如果使用 `gradle/gradle-build-action@v3` 包裝 setup 步驟，請確保實際執行的 Gradle 版本仍是 9.4.1；不要讓後續步驟再次選回 8.9。

## Kotlin 插件遷移說明

AGP 9 預設內建 Kotlin 支援。本專案暫時設定 `android.builtInKotlin=false`，以保留現有明確宣告的 Kotlin 2.4.20 Android Plugin 與 Compose Compiler Plugin，避免同時啟用兩套 Kotlin 整合。

## Android 低版本

保留 `minSdk 24`。Miuix Blur 的 RuntimeShader 效果只在 Android 13 / API 33 以上可用；程式以 `isRuntimeShaderSupported()` / `isRenderEffectSupported()` 做能力檢查，舊版沿用 Java 預模糊快照 fallback。仍應在 API 24–32 實機或模擬器驗證啟動與畫面。

## 驗證界線

已更新並靜態檢查 Gradle 設定；本工作環境沒有 Android SDK、Gradle 9.4.1 與完整建置環境，因此沒有宣稱 APK 已成功編譯。下一次 CI 應先確認日誌顯示 `Provision Gradle 9.4.1`，再檢查後續是否出現新的 Kotlin / AGP DSL 或程式碼編譯錯誤。
