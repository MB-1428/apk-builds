# AGP 9.x / Kotlin Android Plugin 相容性修正

## 本次修改

1. `gradle.properties` 新增：
   ```properties
   android.newDsl=false
   ```
   這是暫時相容設定，用來避開目前 `org.jetbrains.kotlin.android` 外掛與 AGP 9.x 新 DSL 的衝突。保留原本 `android.builtInKotlin=false`，沒有在這次進行 Kotlin 內建外掛遷移。

2. `app/build.gradle` 將 `compileSdk` 從 37 調整為 36，與目前 APK Builder 安裝的 `platforms;android-36` 對齊。

## 保留項目

- Gradle / AGP / Kotlin 外掛版本未更動。
- Miuix Blur 0.9.4 與 Compose 依賴未更動。
- Java / Kotlin JVM target 仍為 17。
- 原有 Android、Shizuku、Native CMake 與 ABI 設定未更動。

## 驗證界線

本次完成檔案層級修改與 ZIP 完整性檢查；目前未在具備相同 Android SDK、NDK、Gradle 網路依賴的 GitHub Actions 環境執行完整 APK 編譯。因此不能保證後續不會出現其他獨立的依賴或原始碼錯誤。
