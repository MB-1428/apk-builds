# MOBAI v29 DebugBoot 修復紀錄（保留原始檔案版）

## 保留原則

本版直接以最初上傳的 `MOBAI_v29_DebugBoot.zip` 為基準。沒有刪除任何原始檔案或原始程式碼；`main.sh`、`libGhostlock.so`、全部 Kernel Profile、AIDL、ShellUserService、JNI/C 原始碼與其他 Java 檔案均保留。資源圖片只更正檔名，圖片位元組不變。

## 本次修改

1. 將 `res/mipmap-*` 中以 `.trashed-` 開頭的圖示檔改為 Android 可辨識的 `ic_launcher.png` 與 `ic_launcher_foreground.png`。
2. 將 `drawable-nodpi` 圖片改名為 `logo.png`。
3. 將 `GhostLockManager` 的 Profile 資產路徑對齊原始 ZIP 實際存在的 `assets/kernel_profiles/`。
4. 新增 `GhostLockManager(Context)` 相容建構子，解決 `MainActivity` 一參數呼叫與原本三參數建構子不匹配的 Java 編譯錯誤。
5. 新增 `SHIZUKU_UNAVAILABLE` 的 UI 狀態文字。
6. README 建置指令改用已安裝的 Gradle 8.9；原始 ZIP 沒有 Gradle Wrapper。

## GhostLock 執行限制

GhostLock 原始 Java、AIDL、Service、ELF 與全部 Profile 均完整保留，沒有刪除或修改原始執行實作／二進位內容。但新增的一參數預設建構子使用 `useShizuku=true` 且不傳入 Service，因此目前 MainActivity 的預設按鈕不會啟動漏洞提權／核心利用載荷，而會回報 `SHIZUKU_UNAVAILABLE`。這是刻意的安全限制，不代表 GhostLock 功能已完成修復或可運作。

## 尚未完成的驗證

- 本工作環境沒有 Gradle、Android SDK、Android NDK，因此沒有產生 APK，也無法聲稱完整 Java/Android 編譯通過。
- 未執行 `main.sh`、`libGhostlock.so` 或任何 Root／提權流程。
- 未調整遠端腳本下載、Root fallback、核心利用邏輯或 ELF 內容。
- 此版沒有偽造無法運作的 `gradlew`。建置請使用 JDK 17、Gradle 8.9、Android SDK Platform 35、NDK 27.2.12479018、CMake 3.22.1。

## 建議建置指令

```bash
gradle assembleDebug
```

Windows：

```bat
gradle.bat assembleDebug
```
