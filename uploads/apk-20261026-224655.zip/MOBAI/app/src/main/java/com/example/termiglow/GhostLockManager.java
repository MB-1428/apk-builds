package com.example.termiglow;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * GhostLock 临时 root 集成：自动扫描 assets 里的 kernel profile，
 * 用 uname -r 精确匹配，匹配则执行 GhostLock 加载 KernelSU 模块。
 *
 * 前提：
 *  - libghostlock.so 已放入 jniLibs/arm64-v8a/
 *  - profile 文件已放入 assets/ghostlock/kernel_profiles/，文件名 = uname -r 完整字符串 + ".conf"
 */
public final class GhostLockManager {
    private static final String TAG = "GhostLock";
    private static final String ASSET_DIR = "ghostlock/kernel_profiles";
    private static final String BIN_NAME = "libghostlock.so";

    public enum Result {
        /** 内核匹配，GhostLock 执行成功 */
        SUCCESS,
        /** 内核匹配，但 GhostLock 执行失败 */
        EXEC_FAILED,
        /** 内核对不上，assets 里没有匹配的 profile */
        NO_PROFILE,
        /** 二进制加载失败（打包问题） */
        NO_BINARY,
        /** 执行过程异常 */
        ERROR
    }

    public static final class Outcome {
        public final Result result;
        public final String kernelRelease;
        public final String detail;
        public final List<String> availableProfiles;

        Outcome(Result r, String kernel, String detail, List<String> profiles) {
            this.result = r;
            this.kernelRelease = kernel;
            this.detail = detail;
            this.availableProfiles = profiles;
        }
    }

    private final Context context;

    public GhostLockManager(Context context) {
        this.context = context.getApplicationContext();
    }

    /** 读取 uname -r */
    public String getKernelRelease() {
        try {
            Process p = new ProcessBuilder("uname", "-r")
                    .redirectErrorStream(true).start();
            java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine();
            p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            return "";
        }
    }

    /** 列出 assets 里所有 profile 的 release 名（去掉 .conf 后缀） */
    public List<String> listAvailableProfiles() {
        List<String> out = new ArrayList<>();
        try {
            String[] list = context.getAssets().list(ASSET_DIR);
            if (list == null) return out;
            for (String name : list) {
                if (name.endsWith(".conf")) {
                    out.add(name.substring(0, name.length() - 5));
                }
            }
        } catch (IOException e) {
            Log.w(TAG, "list profiles failed", e);
        }
        return out;
    }

    /**
     * 执行 GhostLock：
     *  1. 读 uname -r
     *  2. 精确匹配 assets 里的 profile
     *  3. 释放 profile
     *  4. 调用二进制 --load-prebuilt-profile
     */
    public Outcome run() {
        String kernel = getKernelRelease();
        if (kernel.isEmpty()) {
            return new Outcome(Result.ERROR, kernel,
                    "无法读取 uname -r", listAvailableProfiles());
        }

        // 1. 检查二进制
        File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
        if (!bin.exists() || !bin.canExecute()) {
            return new Outcome(Result.NO_BINARY, kernel,
                    "未找到 " + BIN_NAME + "（请确认已放入 jniLibs/arm64-v8a/）",
                    listAvailableProfiles());
        }

        // 2. 精确匹配 profile
        String targetAsset = ASSET_DIR + "/" + kernel + ".conf";
        if (!assetExists(targetAsset)) {
            List<String> profiles = listAvailableProfiles();
            return new Outcome(Result.NO_PROFILE, kernel,
                    "当前内核 " + kernel + " 不在 GhostLock 支持列表",
                    profiles);
        }

        // 3. 释放 profile
        File profileFile;
        try {
            profileFile = new File(context.getFilesDir(), "gl_" + kernel + ".conf");
            try (InputStream in = context.getAssets().open(targetAsset);
                 FileOutputStream out = new FileOutputStream(profileFile)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            }
        } catch (IOException e) {
            return new Outcome(Result.ERROR, kernel,
                    "释放 profile 失败: " + e.getMessage(),
                    listAvailableProfiles());
        }

        // 4. 执行
        Process proc = null;
        try {
            proc = new ProcessBuilder(
                    bin.getAbsolutePath(),
                    "--load-prebuilt-profile", profileFile.getAbsolutePath()
            ).redirectErrorStream(true).start();

            StringBuilder sb = new StringBuilder();
            try (java.io.BufferedReader r = new java.io.BufferedReader(
                    new java.io.InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            int code = proc.waitFor();
            String output = sb.toString().trim();
            if (code == 0) {
                return new Outcome(Result.SUCCESS, kernel, output, listAvailableProfiles());
            } else {
                return new Outcome(Result.EXEC_FAILED, kernel,
                        "exit " + code + (output.isEmpty() ? "" : ": " + output),
                        listAvailableProfiles());
            }
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles());
        } finally {
            if (proc != null) proc.destroy();
            if (profileFile.exists()) profileFile.delete();
        }
    }

    private boolean assetExists(String path) {
        try (InputStream ignored = context.getAssets().open(path)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}