package com.example.termiglow

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RuntimeShader
import android.os.Build
import android.graphics.Paint as AndroidPaint
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.border
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.roundToPx
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.blur.BlendColorEntry
import top.yukonga.miuix.kmp.blur.BlurBlendMode
import top.yukonga.miuix.kmp.blur.BlurColors
import top.yukonga.miuix.kmp.blur.LayerBackdrop
import top.yukonga.miuix.kmp.blur.highlight.Highlight
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.blur.textureBlur
import kotlin.math.abs
import kotlin.math.roundToInt

/** Java-facing callback: page construction and business logic remain in MainActivity. */
fun interface OnNavigationTabSelectedListener {
    fun onTabSelected(index: Int)
}

/** ComposeView host controlled by the existing Java Activity. */
class LiquidGlassNavigationView(
    context: Context,
    initialIndex: Int,
    wide: Boolean,
    blurEnabled: Boolean,
    liquidGlassEnabled: Boolean,
    private val listener: OnNavigationTabSelectedListener
) : ComposeView(context) {
    private var selected by mutableStateOf(initialIndex.coerceIn(0, 3))
    private var isWide by mutableStateOf(wide)
    private var isBlurEnabled by mutableStateOf(blurEnabled)
    private var isLiquidEnabled by mutableStateOf(liquidGlassEnabled)
    private var backdropBitmap by mutableStateOf<Bitmap?>(null)
    private var backdropRevision by mutableIntStateOf(0)

    init {
        setContent {
            LiquidGlassNavigation(
                selectedIndex = selected,
                wide = isWide,
                blurEnabled = isBlurEnabled,
                liquidGlassEnabled = isLiquidEnabled,
                backdropBitmap = backdropBitmap,
                backdropRevision = backdropRevision,
                onSelect = { index ->
                    selected = index
                    listener.onTabSelected(index)
                }
            )
        }
    }

    fun setSelectedIndex(index: Int) { selected = index.coerceIn(0, 3) }
    fun setBlurEnabled(enabled: Boolean) { isBlurEnabled = enabled }
    fun setLiquidGlassEnabled(enabled: Boolean) { isLiquidEnabled = enabled }
    fun setWideLayout(enabled: Boolean) { isWide = enabled }

    /** Receives a source snapshot from the Java page container. */
    fun setBackdropBitmap(bitmap: Bitmap?) {
        backdropBitmap = bitmap
        backdropRevision++
    }
}

private data class NavItem(val title: String, val glyph: String, val description: String)

private val navItems = listOf(
    NavItem("終端", ">_", "終端分頁"),
    NavItem("設置", "⚙", "設置分頁"),
    NavItem("Root", "◇", "Root 管理分頁"),
    NavItem("關於", "i", "關於分頁")
)

@Composable
private fun LiquidGlassNavigation(
    selectedIndex: Int,
    wide: Boolean,
    blurEnabled: Boolean,
    liquidGlassEnabled: Boolean,
    backdropBitmap: Bitmap?,
    backdropRevision: Int,
    onSelect: (Int) -> Unit
) {
    val scope = rememberCoroutineScope()
    val position = remember { Animatable(selectedIndex.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var dragStretch by remember { mutableFloatStateOf(0f) }
    var touchPoint by remember { mutableStateOf(Offset.Zero) }

    val canUseMiuixBlur = blurEnabled && Build.VERSION.SDK_INT >= 33 && backdropBitmap != null
    // LayerBackdrop samples only Compose content. The Java host forwards a page snapshot as
    // an Image below, so the library can blur the actual page rather than its own glass tint.
    val backdrop: LayerBackdrop? = if (Build.VERSION.SDK_INT >= 32) {
        rememberLayerBackdrop { drawContent() }
    } else null
    val backdropImage = remember(backdropRevision, backdropBitmap) {
        backdropBitmap?.asImageBitmap()
    }

    LaunchedEffect(selectedIndex) {
        if (!dragging) position.animateTo(
            selectedIndex.toFloat(),
            spring(dampingRatio = 0.72f, stiffness = 420f)
        )
    }

    val shape = RoundedCornerShape(if (wide) 25.dp else 28.dp)
    val shellBrush = if (liquidGlassEnabled) {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.70f),
                Color.White.copy(alpha = 0.44f),
                Color(0xFFEAF3FF).copy(alpha = 0.58f)
            )
        )
    } else {
        Brush.linearGradient(
            listOf(Color(0xFFF6F7FA).copy(alpha = 0.96f), Color(0xFFE9EDF3).copy(alpha = 0.94f))
        )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(if (wide) 5.dp else 4.dp)
            .shadow(if (liquidGlassEnabled) 15.dp else 8.dp, shape)
            .clip(shape)
            .pointerInput(wide, selectedIndex) {
                if (!wide) {
                    detectDragGestures(
                        onDragStart = { touchPoint = it; dragging = true },
                        onDragEnd = {
                            dragging = false
                            val target = position.value.roundToInt().coerceIn(0, navItems.lastIndex)
                            dragStretch = 0f
                            scope.launch {
                                position.animateTo(
                                    target.toFloat(),
                                    spring(dampingRatio = 0.62f, stiffness = 360f)
                                )
                            }
                            onSelect(target)
                        },
                        onDragCancel = {
                            dragging = false
                            dragStretch = 0f
                            scope.launch { position.animateTo(selectedIndex.toFloat(), spring()) }
                        },
                        onDrag = { change, amount ->
                            change.consume()
                            val cell = size.width.toFloat() / navItems.size
                            val next = (position.value + amount.x / cell)
                                .coerceIn(0f, navItems.lastIndex.toFloat())
                            position.snapTo(next)
                            dragStretch = (amount.x / 90f).coerceIn(-0.10f, 0.10f)
                            touchPoint = change.position
                        }
                    )
                }
            }
    ) {
        // Background source: the Java layer captures the actual page behind the nav bar.
        if (blurEnabled && backdropImage != null) {
            Image(
                bitmap = backdropImage,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().then(
                    if (backdrop != null) Modifier.layerBackdrop(backdrop) else Modifier
                )
            )
        } else {
            Box(Modifier.fillMaxSize().background(shellBrush))
        }

        // Miuix 0.9.4 RuntimeShader blur and edge highlight are API 33+.
        if (canUseMiuixBlur && backdrop != null) {
            Box(
                Modifier.fillMaxSize().textureBlur(
                    backdrop = backdrop,
                    shape = shape,
                    blurRadius = 23f,
                    colors = BlurColors(
                        blendColors = listOf(
                            BlendColorEntry(Color.White.copy(alpha = 0.30f), BlurBlendMode.SrcOver)
                        ),
                        brightness = 0.025f,
                        contrast = 1.04f,
                        saturation = 1.08f
                    ),
                    highlight = if (liquidGlassEnabled) Highlight.GlassStrokeMiddleLight else null
                )
            )
        } else {
            Box(Modifier.fillMaxSize().background(shellBrush))
        }

        if (!canUseMiuixBlur) {
            Box(
                Modifier.fillMaxSize().border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = if (liquidGlassEnabled) 0.88f else 0.58f),
                    shape = shape
                )
            )
        }

        val cellWidth = (maxWidth - 6.dp) / navItems.size.toFloat()
        val indicatorWidth = if (wide) maxWidth - 10.dp else cellWidth - 2.dp
        val indicatorHeight = if (wide) 50.dp else maxHeight - 8.dp
        val indicatorX = if (wide) 5.dp else 3.dp + cellWidth * position.value + 1.dp
        val indicatorY = if (wide) (54.dp * position.value) + 4.dp else 4.dp
        val capsuleShape = RoundedCornerShape(24.dp)

        val capsuleBlur = if (canUseMiuixBlur && backdrop != null) {
            Modifier.textureBlur(
                backdrop = backdrop,
                shape = capsuleShape,
                blurRadius = 34f,
                colors = BlurColors(
                    blendColors = listOf(
                        BlendColorEntry(Color.White.copy(alpha = 0.24f), BlurBlendMode.SrcOver)
                    ),
                    brightness = 0.035f,
                    contrast = 1.06f,
                    saturation = 1.12f
                ),
                highlight = if (liquidGlassEnabled) Highlight.GlassStrokeBigLight else null
            )
        } else Modifier

        Box(
            modifier = Modifier
                .offset { IntOffset(indicatorX.roundToPx(), indicatorY.roundToPx()) }
                .size(width = indicatorWidth, height = indicatorHeight)
                .then(capsuleBlur)
                .graphicsCapsule(liquidGlassEnabled, canUseMiuixBlur, dragStretch, touchPoint)
        ) {
            GlassShaderHighlight(touchPoint)
        }

        if (wide) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                navItems.forEachIndexed { index, item ->
                    NavItemContent(item, index == selectedIndex, true) { onSelect(index) }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(0.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                navItems.forEachIndexed { index, item ->
                    Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                        NavItemContent(item, index == selectedIndex, false) { onSelect(index) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavItemContent(item: NavItem, selected: Boolean, wide: Boolean, onClick: () -> Unit) {
    val foreground = if (selected) Color(0xFF1557B0) else Color(0xFF424B59)
    val itemModifier = Modifier
        .then(if (wide) Modifier.fillMaxWidth().height(52.dp) else Modifier.fillMaxSize())
        .clip(RoundedCornerShape(22.dp))
        .clickable(role = Role.Tab, onClick = onClick)
        .semantics {
            contentDescription = item.description
            this.selected = selected
        }
    if (wide) {
        Row(itemModifier.padding(horizontal = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                text = item.glyph,
                style = TextStyle(color = foreground, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            )
            BasicText(
                text = item.title,
                modifier = Modifier.padding(start = 13.dp),
                style = TextStyle(
                    color = foreground,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
            )
        }
    } else {
        Column(
            itemModifier,
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(item.glyph, color = foreground, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Text(
                item.title,
                color = foreground,
                fontSize = 10.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
    }
}

private fun Modifier.graphicsCapsule(
    liquid: Boolean,
    useMiuixBlur: Boolean,
    stretch: Float,
    touch: Offset
): Modifier = this.then(
    Modifier
        .graphicsLayer {
            scaleX = 1f + stretch
            scaleY = 1f - abs(stretch) * 0.18f
        }
        .shadow(5.dp, RoundedCornerShape(24.dp))
        .clip(RoundedCornerShape(24.dp))
        .background(
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = if (useMiuixBlur) 0.25f else 0.66f),
                    Color(0xFFDCEBFF).copy(alpha = if (useMiuixBlur) 0.20f else 0.52f),
                    Color.White.copy(alpha = if (liquid) 0.24f else 0.34f)
                )
            )
        )
        .then(
            Modifier.background(
                Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (liquid) 0.60f else 0.38f),
                        Color.White.copy(alpha = 0.0f)
                    ),
                    center = touch.takeIf { it != Offset.Zero } ?: Offset(42f, 4f),
                    radius = 110f
                )
            )
        )
)

/** AGSL specular highlight fallback for the selected capsule on Android 13+. */
@Composable
private fun GlassShaderHighlight(touch: Offset) {
    if (Build.VERSION.SDK_INT < 33) return
    val shader = remember {
        RuntimeShader("""
            uniform float2 resolution;
            uniform float2 touch;
            uniform float press;
            half4 main(float2 p) {
                float2 uv = p / max(resolution, float2(1.0));
                float edge = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y));
                float rim = 1.0 - smoothstep(0.0, 0.13, edge);
                float d = distance(p, touch);
                float spot = exp(-(d * d) / max(resolution.x * resolution.x * 0.055, 1.0));
                float alpha = clamp(rim * 0.22 + spot * (0.24 + press * 0.20), 0.0, 0.52);
                return half4(1.0, 1.0, 1.0, alpha);
            }
        """.trimIndent())
    }
    val paint = remember(shader) {
        AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply { this.shader = shader }
    }
    Canvas(Modifier.fillMaxSize()) {
        shader.setFloatUniform("resolution", size.width, size.height)
        shader.setFloatUniform("touch", touch.x.coerceIn(0f, size.width), touch.y.coerceIn(0f, size.height))
        shader.setFloatUniform("press", 0.55f)
        drawIntoCanvas { canvas ->
            canvas.nativeCanvas.drawRoundRect(
                0f, 0f, size.width, size.height,
                24.dp.toPx(), 24.dp.toPx(), paint
            )
        }
    }
}
