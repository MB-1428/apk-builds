# MOBAI v30 — Kotlin Compose Liquid Glass 導航重構

## 修改目標

只替換主畫面的四項分頁導航 UI。終端、設置、Root、關於四個頁面仍由原本的 `MainActivity.java` 建立；Shizuku、PTY、Shell、GhostLock、設定儲存與原生橋接流程不搬入 Compose。

## 架構

```text
MainActivity.java
  ├─ buildTerminalPage()
  ├─ buildSettingsPage()
  ├─ buildRootPage()
  ├─ buildAboutPage()
  └─ GlassLayout (既有 Java 背景取樣／模糊外殼)
       └─ LiquidGlassNavigationView (Kotlin Compose)
            ├─ 四個導航項目
            ├─ 連續索引選取膠囊
            ├─ Spring 彈簧動畫
            ├─ 拖曳與放手吸附
            ├─ 漸層玻璃、邊緣高光、互動光斑
            └─ Android 13+ AGSL 高光 Shader
```

Java 透過 `LiquidGlassNavigationView.setSelectedIndex()` 將頁面狀態同步給 Compose；Compose 透過 `OnNavigationTabSelectedListener` 回呼 `MainActivity.showPage(index)`。頁面切換仍由原本 Java Activity 負責。

## 液態玻璃效果與平台差異

- 玻璃底板：Java `GlassLayout` 對目前頁面內容擷取低解析度 Bitmap，交給 Compose 作為 `LayerBackdrop` 的來源；Android 13（API 33）以上由 Miuix `textureBlur()` 執行真正的 RuntimeShader 背景模糊與邊緣高光。
- 選取膠囊：使用同一份頁面快照作為 backdrop，另外套用較強的 Miuix `textureBlur()`、`Highlight.GlassStrokeBigLight`、連續索引位置、Spring 動畫與拖曳形變。
- 相容性：`miuix-blur-android:0.9.4` 的模糊／高光需要 API 33+；專案維持 `minSdk 24`，API 24–32 由 Java `GlassLayout` 做降級模糊，API 33+ 才呼叫 Miuix RuntimeShader。Manifest 使用 `tools:overrideLibrary` 保留較低 minSdk，並以執行時 API 判斷避免舊系統執行 Shader 路徑。
- 這是將 Java View 背景快照橋接到 Miuix `LayerBackdrop + textureBlur`，不是完整移植 KernelSU 的 Lens 折射／色散／裝置傾斜雙光源。

## 建置設定

- Android Gradle Plugin：8.7.3（保留原版）
- Kotlin Android / Compose Compiler Plugin：2.4.20
- Compose Multiplatform：1.12.0（與 Miuix 0.9.4 對齊）
- Miuix Blur：0.9.4
- compileSdk：35
- minSdk：24（不變）
- targetSdk：28（不變）
- ABI：arm64-v8a（不變）
- Java/Kotlin JVM target：17
- Gradle：8.9 或更新的相容版本（AGP 8.7.3 的最低 Gradle 版本為 8.9）
- JDK：17

使用 Android Studio 開啟專案根目錄 `MOBAI/`，確認 Gradle 使用 JDK 17 與 Gradle 8.9+，等待 Gradle Sync，然後執行 `:app:assembleDebug`。

## 修改檔案

1. `build.gradle`：新增 Kotlin Android 與 Compose compiler plugins。
2. `app/build.gradle`：啟用 Compose，加入 Compose UI、Foundation、Animation、Material3 依賴。
3. `app/src/main/java/com/example/termiglow/LiquidGlassNavigation.kt`：新增 Compose 導航 UI。
4. `app/src/main/java/com/example/termiglow/MainActivity.java`：以 ComposeView 替換舊 Java 導航項目；保留頁面建構與業務功能，並同步選取狀態及模糊設定。
5. `app/src/main/java/com/example/termiglow/GlassLayout.java`：擷取 Java 頁面背景 Bitmap，提供給 Compose `LayerBackdrop`；API 24–32 保留 Java 降級模糊。
6. `app/src/main/AndroidManifest.xml`：以 `tools:overrideLibrary` 保留 app 的 minSdk 24。

## 建議驗收

- 點擊四個導航項目，確認分頁內容正確。
- 快速連續切換，確認膠囊與頁面索引不倒退。
- 在底部膠囊上左右拖曳，確認位置連續、放開後吸附到最近分頁。
- 切換模糊與液態玻璃設定，確認即時生效。
- 在 API 24–32 確認 Java 降級模糊；API 33+ 確認 Miuix backdrop blur 與 Highlight。
- 檢查橫向／平板側邊導航排列、TalkBack selected 語意與終端輸出互動。

## 驗證限制

Miuix 0.9.4 的 Kotlin／Compose 版本已對齊，但本次工作環境沒有 Android SDK、Gradle 執行檔或可用的 Android build cache，因此無法在此產生 APK 或宣稱已通過實際 Gradle 編譯。請使用支援 Kotlin 2.4.20、Compose Multiplatform 1.12.0 的 Android Studio／Gradle 環境完成 Sync 與 `:app:assembleDebug`，再進行 API 24–32 及 API 33+ 實機驗收。


## Miuix Blur 0.9.4 整合更新

本版本已把導航玻璃背景改為使用 Miuix Blur 0.9.4：

- Gradle 依賴：`top.yukonga.miuix.kmp:miuix-blur-android:0.9.4`
- Kotlin / Compose Compiler：`2.4.20`
- Compose Multiplatform Android artifacts：`1.12.0`
- 保留 `minSdk 24`、`compileSdk 35`、Java/Kotlin JVM 17、`arm64-v8a`。
- `AndroidManifest.xml` 使用 Miuix 官方示例中的 `tools:overrideLibrary="top.yukonga.miuix.kmp.blur"`。這是因為 Blur Android 模組要求 API 33；保留低於 API 33 的裝置時，必須同時做執行時能力檢查，不能在舊系統直接呼叫 Shader 模糊路徑。

### 背景接線方式

`GlassLayout.java` 不再繪製導航玻璃本身，而是從原本 Java 頁面擷取導航區域的 Bitmap，透過 `BackdropListener` 交給 `LiquidGlassNavigationView`。Compose 將該 Bitmap 畫入 `LayerBackdrop`，再由 Miuix `textureBlur()` 處理整個玻璃底板與選取膠囊。這避免 Miuix 只捕捉 Compose 自己、卻捕捉不到外層 Java View 的問題。

### Android 版本行為

- API 33+：使用 Miuix `rememberLayerBackdrop()`、`layerBackdrop()`、`textureBlur()` 和 `Highlight`。
- API 24–32：不呼叫 Miuix RuntimeShader Blur；Java `GlassLayout` 只保留低解析度的舊式快照模糊作為相容後備。
- 使用者關閉模糊時：Compose 不顯示背景快照，改用不透明玻璃底色。

### 工具鏈提醒

本專案原本沒有 Gradle Wrapper。使用 Android Studio 時，Gradle 版本需符合 AGP 8.7.3（至少 Gradle 8.9）；Kotlin 2.4.20 官方相容範圍涵蓋 Gradle 8.9 與 AGP 8.7.3。請在有 Android SDK / NDK 的環境執行：

```bash
gradle :app:assembleDebug
```

目前交付環境沒有 Gradle 執行檔或 Android SDK，因此本次只完成原始碼、Gradle 設定、Manifest 與 ZIP 完整性檢查，**沒有宣稱 APK 編譯已通過**。Miuix 的 Blur 功能仍需在 API 33+ 真機上驗證視覺與效能，並在 API 24–32 裝置驗證 fallback。
