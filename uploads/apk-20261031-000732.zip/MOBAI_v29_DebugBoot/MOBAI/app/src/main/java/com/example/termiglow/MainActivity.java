package com.example.termiglow;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    // Palette: computed by applyPalette() from theme mode + Monet, instead of fixed constants.
    private int BG;
    private int PANEL;
    private int ACCENT;
    private int TEXT;
    private int MUTED;
    private int BORDER;
    private int ERROR;
    private int glassFill;
    private int glassStroke;
    private int pillFill;

    private static final String PREFS_NAME = "mobai_settings";
    private static final String KEY_THEME_MODE = "theme_mode";
    private static final String KEY_MONET = "monet_enabled";
    private static final String KEY_BLUR = "blur_enabled";
    private static final String KEY_LIQUID_GLASS = "liquid_glass_enabled";
    private static final int THEME_SYSTEM = 0;
    private static final int THEME_LIGHT = 1;
    private static final int THEME_DARK = 2;

    private android.content.SharedPreferences prefs;
    private int themeMode = THEME_SYSTEM;
    private boolean monetEnabled = false;
    private boolean blurEnabled = true;
    private boolean liquidGlassEnabled = true;

    private EditText inputBox;
    private TextView inputLabel;
    private TextView output;
    private TextView status;
    private Button runButton;
    private ScrollView outputScroll;
    private final AnsiRenderer ansi = new AnsiRenderer();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile long activePtyHandle;
    // Default = PTY run as the app user, exactly like MT Manager's terminal; main.sh finds su/rish itself.
    private volatile boolean usePty = true;
    private volatile Process activeProcess;
    private volatile OutputStream activeProcessInput;
    private android.widget.Switch ptyBox;
    private TextView privilegeInfo;
    private LinearLayout quickBox;
    private LinearLayout quickBar;
    private String lastMenuSig = "";
    private final StringBuilder recentText = new StringBuilder();
    private View[] pages;
    private LinearLayout[] navItems;
    private int currentPage = -1;
    private GlassLayout navGlass;
    private LinearLayout navRow;
    private View navPill;
    private boolean wideLayout;
    private static final String DEFAULT_SCRIPT_URL =
            "https://raw.githubusercontent.com/MB-1428/update/main/update/main.sh";
    private volatile boolean scriptRunning = false;
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private volatile String executionMode = "normal";
    private volatile boolean shizukuPermissionRequestPending = false;
    private volatile boolean rootFallbackStarted = false;
    private volatile boolean rootAvailable = false;
    private volatile boolean userServiceBindInProgress = false;
    private volatile boolean userServiceBound = false;
    private volatile IShellUserService shizukuShellService;
    private volatile CountDownLatch userServiceReady = new CountDownLatch(1);
    private Shizuku.UserServiceArgs userServiceArgs;
    private volatile boolean ghostLockRunning = false;
    private volatile GhostLockManager.Result ghostLockLastResult = null;
    private GhostLockManager ghostLockManager;

    private final IShellOutputCallback shellOutputCallback = new IShellOutputCallback.Stub() {
        @Override
        public void onOutput(String text) {
            appendOutput(text);
        }

        @Override
        public void onExit(int exitCode) {
            runOnUiThread(() -> completeScript(exitCode));
        }

        @Override
        public void onError(String message) {
            appendOutput("\n⚠ 輸出中斷：" + message + "\n");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener =
            (requestCode, grantResult) -> {
                if (requestCode != SHIZUKU_REQUEST_CODE) return;
                shizukuPermissionRequestPending = false;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    executionMode = "shizuku";
                    appendOutput("✔ 已取得 Shizuku 授權，正在連線…\n");
                    updatePrivilegeStatus("Shizuku 連線中");
                    bindShizukuUserService();
                } else {
                    appendOutput("未授權 Shizuku，改為嘗試 root。\n");
                    requestRootFallback();
                }
            };

    private final Shizuku.OnBinderReceivedListener shizukuBinderListener =
            () -> runOnUiThread(this::checkShizukuPermission);

    private final ServiceConnection userServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuShellService = IShellUserService.Stub.asInterface(service);
            userServiceBindInProgress = false;
            userServiceBound = true;
            userServiceReady.countDown();
            appendOutput("✔ Shizuku 已連線。\n");
            updatePrivilegeStatus("Shizuku 已就緒");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            shizukuShellService = null;
            userServiceBindInProgress = false;
            userServiceBound = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線中斷。\n");
            updatePrivilegeStatus("Shizuku 已中斷");
        }
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        loadSettings();
        applyPalette();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        boolean light = !resolveDark();
        int uiFlags = light ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0;
        if (android.os.Build.VERSION.SDK_INT >= 26 && light) {
            uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);

        installCrashRecorder();
        try {
            buildUi(state == null);
        } catch (Throwable t) {
            showFatalScreen("介面建立失敗", t);
            return;
        }
        showLastCrashIfAny();
        appendOutput("歡迎使用 MOBAI\n\n"
                + "使用步驟\n"
                + "① 按下方「開始運行」\n"
                + "② 出現選項時，點上方的按鈕即可\n"
                + "③ 看到「配置完成」，介面就會出現\n\n"
                + "小提示：若介面沒出現，可到左側「設置」更改運行方式後再試。\n\n");

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (shizukuShellService != null || shizukuPermissionRequestPending
                    || "shizuku".equals(executionMode)) return;
            if (Shizuku.pingBinder()) {
                checkShizukuPermission();
            } else {
                appendOutput("未偵測到 Shizuku，改為嘗試 root；沒有 root 會使用一般權限。\n");
                requestRootFallback();
            }
        }, 1500);
    }


    // ---- theme: light/dark mode, Monet dynamic color, blur + liquid glass toggles ----
    private void loadSettings() {
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        themeMode = prefs.getInt(KEY_THEME_MODE, THEME_SYSTEM);
        monetEnabled = prefs.getBoolean(KEY_MONET, false);
        blurEnabled = prefs.getBoolean(KEY_BLUR, true);
        liquidGlassEnabled = prefs.getBoolean(KEY_LIQUID_GLASS, true);
    }

    /** THEME_SYSTEM follows the device's day/night setting; otherwise the explicit choice wins. */
    private boolean resolveDark() {
        if (themeMode == THEME_LIGHT) return false;
        if (themeMode == THEME_DARK) return true;
        int mode = getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    /** Reads the primary color of the current system wallpaper, Monet-style; 0 if unavailable. */
    private int getMonetAccent() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 27) {
                android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(this);
                android.app.WallpaperColors colors =
                        wm.getWallpaperColors(android.app.WallpaperManager.FLAG_SYSTEM);
                if (colors != null && colors.getPrimaryColor() != null) {
                    return colors.getPrimaryColor().toArgb();
                }
            }
        } catch (Exception ignored) {
            // No wallpaper access, or the device doesn't report colors; fall back to the default accent.
        }
        return 0;
    }

    /** Recomputes the whole color palette from the current theme mode + Monet setting. */
    private void applyPalette() {
        boolean dark = resolveDark();
        if (dark) {
            BG = Color.rgb(18, 18, 20);
            PANEL = Color.rgb(42, 42, 46);
            TEXT = Color.rgb(237, 237, 240);
            MUTED = Color.rgb(161, 161, 170);
            BORDER = Color.rgb(58, 58, 64);
            ERROR = Color.rgb(248, 113, 113);
            glassFill = 0x4DFFFFFF;
            glassStroke = 0x40FFFFFF;
            pillFill = 0x40FFFFFF;
        } else {
            BG = Color.rgb(247, 247, 247);
            PANEL = Color.rgb(232, 232, 232);
            TEXT = Color.rgb(24, 24, 27);
            MUTED = Color.rgb(113, 113, 122);
            BORDER = Color.rgb(232, 232, 232);
            ERROR = Color.rgb(220, 38, 38);
            glassFill = 0xB3FFFFFF;
            glassStroke = 0xCCFFFFFF;
            pillFill = 0x24000000;
        }
        int monetAccent = monetEnabled ? getMonetAccent() : 0;
        ACCENT = monetAccent != 0 ? monetAccent : Color.rgb(37, 99, 235);
    }

    // ---- crash recorder: lets a non-developer see why the app closed ----
    private File crashFile() {
        return new File(getFilesDir(), "last_crash.txt");
    }

    private static String stackToString(Throwable t) {
        java.io.StringWriter sw = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(sw));
        return sw.toString();
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        final File file = crashFile();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
                out.write(("線程：" + thread.getName() + "\n" + stackToString(error))
                        .getBytes(StandardCharsets.UTF_8));
            } catch (Throwable ignored) {
                // Best effort only.
            }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private void showLastCrashIfAny() {
        File file = crashFile();
        if (!file.exists()) return;
        String text;
        try (java.io.FileInputStream in = new java.io.FileInputStream(file)) {
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = in.read(chunk)) != -1) buf.write(chunk, 0, n);
            text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return;
        }
        file.delete();
        TextView body = label(text, 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(8), dp(16), dp(8));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new android.app.AlertDialog.Builder(this)
                .setTitle("上次閃退的原因（可長按複製後貼給開發者）")
                .setView(scroll)
                .setPositiveButton("知道了", null)
                .show();
    }

    private void showFatalScreen(String title, Throwable t) {
        TextView body = label(title + "\n\n" + stackToString(t), 11, TEXT, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(16), dp(24), dp(16), dp(16));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.addView(body);
        setContentView(scroll);
    }

    private LinearLayout buildTerminalPage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));

        // Title row: large title on the left, clear pill on the right.
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(label("MOBAI", 30, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = actionButton("清除", Color.WHITE, TEXT);
        titleRow.addView(clear, new LinearLayout.LayoutParams(dp(76), dp(40)));
        page.addView(titleRow);

        // Status card, styled like a list item.
        LinearLayout item = new LinearLayout(this);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(14), dp(12), dp(16), dp(12));
        item.setBackground(glassBg(22));
        TextView icon = label(">_", 17, Color.WHITE, true);
        icon.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(Color.rgb(39, 39, 42), 14, Color.rgb(39, 39, 42), 0));
        item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(14), 0, dp(8), 0);
        names.addView(label("MOBAI 主程式", 16, TEXT, true));
        names.addView(label("按下方「開始運行」即可啟動", 12, MUTED, false));
        item.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("待命", 10, MUTED, true);
        status.setGravity(Gravity.END);
        item.addView(status, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
        itemLp.topMargin = dp(16);
        page.addView(item, itemLp);

        // Terminal card.
        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(glassBg(22));
        output = label("", 11, TEXT, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(16), dp(16), dp(16), dp(16));
        output.setTextIsSelectable(true);
        // Keep terminal lines unwrapped so ASCII art / menus stay aligned; scroll sideways if needed.
        output.setHorizontallyScrolling(true);
        android.widget.HorizontalScrollView hScroll = new android.widget.HorizontalScrollView(this);
        hScroll.setFillViewport(true);
        hScroll.addView(output);
        outputScroll.addView(hScroll);
        outputScroll.getViewTreeObserver().addOnScrollChangedListener(() -> {
            if (navGlass != null) navGlass.refresh();
        });
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(12);
        page.addView(outputScroll, outLp);

        quickBox = new LinearLayout(this);
        quickBox.setOrientation(LinearLayout.VERTICAL);
        quickBox.setVisibility(View.GONE);
        TextView quickHint = label("請選擇一個選項：", 12, MUTED, true);
        quickHint.setPadding(dp(6), 0, 0, dp(6));
        quickBox.addView(quickHint);
        android.widget.HorizontalScrollView quickScroll = new android.widget.HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        quickBar = new LinearLayout(this);
        quickScroll.addView(quickBar);
        quickBox.addView(quickScroll);
        LinearLayout.LayoutParams quickLp = new LinearLayout.LayoutParams(-1, -2);
        quickLp.topMargin = dp(12);
        page.addView(quickBox, quickLp);

        inputLabel = label("啟動參數（選填，一般不用填）", 11, MUTED, true);
        LinearLayout.LayoutParams inputLabelLp = new LinearLayout.LayoutParams(-1, -2);
        inputLabelLp.topMargin = dp(14);
        inputLabelLp.leftMargin = dp(6);
        page.addView(inputLabel, inputLabelLp);

        // Gray pill input, like the search bar in the reference.
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setBackground(round(PANEL, 28, PANEL, 0));
        LinearLayout.LayoutParams inputRowLp = new LinearLayout.LayoutParams(-1, dp(54));
        inputRowLp.topMargin = dp(6);
        page.addView(inputRow, inputRowLp);

        TextView prompt = label("$", 19, MUTED, true);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        prompt.setGravity(Gravity.CENTER);
        inputRow.addView(prompt, new LinearLayout.LayoutParams(dp(46), -1));

        inputBox = new EditText(this);
        inputBox.setTextSize(14);
        inputBox.setSingleLine(false);
        inputBox.setMinLines(1);
        inputBox.setMaxLines(2);
        inputBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        inputBox.setTypeface(Typeface.MONOSPACE);
        inputBox.setTextColor(TEXT);
        inputBox.setHintTextColor(MUTED);
        inputBox.setHint("一般請留空");
        inputBox.setBackground(null);
        inputBox.setPadding(0, 0, dp(18), 0);
        inputRow.addView(inputBox, new LinearLayout.LayoutParams(0, -1, 1));

        runButton = actionButton("▶  開始運行", ACCENT, Color.WHITE);
        LinearLayout.LayoutParams runLp = new LinearLayout.LayoutParams(-1, dp(52));
        runLp.topMargin = dp(10);
        page.addView(runButton, runLp);

        runButton.setOnClickListener(v -> {
            if (scriptRunning) sendInteractiveInput();
            else runBuiltInScript();
        });
        clear.setOnClickListener(v -> { output.setText(""); ansi.reset(); recentText.setLength(0); updateQuickReplies(); });
        return page;
    }

    private LinearLayout newPage(String title) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(12));
        page.addView(label(title, 30, TEXT, true));
        return page;
    }

    /** White rounded list-item card: title + subtitle on the left, optional view on the right. */
    private LinearLayout listCard(String title, TextView sub, View right) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(14), dp(16), dp(14));
        card.setBackground(glassBg(22));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(label(title, 16, TEXT, true));
        names.addView(sub);
        card.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(12);
            card.addView(right, lp);
        }
        return card;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        return lp;
    }

    /** A rounded pill of N equal segments, one highlighted; tapping a segment reports its index. */
    private LinearLayout segmentedRow(String[] labels, int selected, java.util.function.IntConsumer onSelect) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(round(PANEL, 16, PANEL, 0));
        row.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean isSelected = i == selected;
            TextView seg = label(labels[i], 13, isSelected ? Color.WHITE : TEXT, true);
            seg.setGravity(Gravity.CENTER);
            seg.setBackground(round(isSelected ? ACCENT : Color.TRANSPARENT, 12, Color.TRANSPARENT, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            if (i > 0) lp.leftMargin = dp(4);
            seg.setOnClickListener(v -> onSelect.accept(idx));
            row.addView(seg, lp);
        }
        return row;
    }

    /** Re-applies the saved settings' effects and restarts the activity so every color repaints. */
    private void onAppearanceChanged() {
        recreate();
    }

    private LinearLayout buildSettingsPage() {
        LinearLayout page = newPage("設置");

        TextView themeLabel = label("外觀模式", 11, MUTED, true);
        LinearLayout.LayoutParams themeLabelLp = new LinearLayout.LayoutParams(-1, -2);
        themeLabelLp.topMargin = dp(16);
        themeLabelLp.leftMargin = dp(6);
        page.addView(themeLabel, themeLabelLp);

        LinearLayout themeRow = segmentedRow(new String[] {"跟隨系統", "淺色", "深色"}, themeMode, idx -> {
            if (idx == themeMode) return;
            themeMode = idx;
            prefs.edit().putInt(KEY_THEME_MODE, idx).apply();
            onAppearanceChanged();
        });
        LinearLayout.LayoutParams themeRowLp = new LinearLayout.LayoutParams(-1, dp(48));
        themeRowLp.topMargin = dp(6);
        page.addView(themeRow, themeRowLp);

        android.widget.Switch monetBox = new android.widget.Switch(this);
        monetBox.setChecked(monetEnabled);
        monetBox.setOnCheckedChangeListener((b, checked) -> {
            monetEnabled = checked;
            prefs.edit().putBoolean(KEY_MONET, checked).apply();
            onAppearanceChanged();
        });
        TextView monetSub = label("取用系統桌布的主色調作為主題色（需裝置支援，Android 12+）", 12, MUTED, false);
        page.addView(listCard("啟用 Monet 顏色", monetSub, monetBox), cardLp());

        android.widget.Switch blurBox = new android.widget.Switch(this);
        blurBox.setChecked(blurEnabled);
        blurBox.setOnCheckedChangeListener((b, checked) -> {
            blurEnabled = checked;
            prefs.edit().putBoolean(KEY_BLUR, checked).apply();
            if (navGlass != null) navGlass.setBlurEnabled(checked);
        });
        TextView blurSub = label("啟用頂部／底部導覽列的模糊效果", 12, MUTED, false);
        page.addView(listCard("模糊", blurSub, blurBox), cardLp());

        android.widget.Switch liquidBox = new android.widget.Switch(this);
        liquidBox.setChecked(liquidGlassEnabled);
        liquidBox.setOnCheckedChangeListener((b, checked) -> {
            liquidGlassEnabled = checked;
            prefs.edit().putBoolean(KEY_LIQUID_GLASS, checked).apply();
            if (navGlass != null) navGlass.setLiquidGlassEnabled(checked);
        });
        TextView liquidSub = label("為導覽列啟用液態玻璃光澤效果", 12, MUTED, false);
        page.addView(listCard("液態玻璃", liquidSub, liquidBox), cardLp());

        ptyBox = new android.widget.Switch(this);
        ptyBox.setChecked(usePty);
        ptyBox.setOnCheckedChangeListener((b, checked) -> usePty = checked);
        TextView modeSub = label("開啟＝建議方式\n如果介面沒出現或選項異常，可關閉後再試一次", 12, MUTED, false);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("運行方式", modeSub, ptyBox), first);

        privilegeInfo = label("偵測中…", 12, MUTED, false);
        page.addView(listCard("權限狀態", privilegeInfo, null), cardLp());

        TextView clearSub = label("每次按「開始運行」都會先清空畫面", 12, MUTED, false);
        TextView on = label("已啟用", 11, ACCENT, true);
        page.addView(listCard("開始前清空畫面", clearSub, on), cardLp());

        TextView note = label("運行中無法更改運行方式。", 11, MUTED, false);
        LinearLayout.LayoutParams noteLp = cardLp();
        noteLp.leftMargin = dp(6);
        page.addView(note, noteLp);

        // GhostLock temporary root entry.
        Button ghostLockButton = actionButton("🔓  Root（GhostLock）", ACCENT, Color.WHITE);
        ghostLockButton.setEnabled(!ghostLockRunning);
        LinearLayout.LayoutParams ghostLp = cardLp();
        ghostLp.topMargin = dp(12);
        ghostLp.leftMargin = dp(6);
        page.addView(ghostLockButton, ghostLp);
        ghostLockButton.setOnClickListener(v -> runGhostLockNow());

        TextView ghostLockSub = label("需要對應的 libghostlock.so 與 kernel profile；一般來說不建議使用。", 12, MUTED, false);
        LinearLayout.LayoutParams ghostSubLp = cardLp();
        ghostSubLp.topMargin = dp(6);
        ghostSubLp.leftMargin = dp(6);
        page.addView(ghostLockSub, ghostSubLp);
        return page;
    }

    private void runGhostLockNow() {
        if (ghostLockRunning) return;
        ghostLockRunning = true;
        executor.execute(() -> {
            if (ghostLockManager == null) {
                ghostLockManager = new GhostLockManager(MainActivity.this);
            }
            GhostLockManager.Outcome outcome = ghostLockManager.run();
            final GhostLockManager.Result result = outcome.result;
            final String detail = outcome.detail;
            final String kernel = outcome.kernelRelease;
            final java.util.List<String> profiles = outcome.availableProfiles;
            runOnUiThread(() -> {
                ghostLockRunning = false;
                ghostLockLastResult = result;
                String statusText;
                switch (result) {
                    case SUCCESS:
                        statusText = "✔ GhostLock 執行成功";
                        break;
                    case EXEC_FAILED:
                        statusText = "⚠ GhostLock 執行失敗";
                        break;
                    case NO_PROFILE:
                        statusText = "⚠ 目前内核沒有對應的 GhostLock profile";
                        break;
                    case NO_BINARY:
                        statusText = "⚠ 找不到 libghostlock.so，請確認已放入 jniLibs/arm64-v8a/";
                        break;
                    case SHIZUKU_UNAVAILABLE:
                        statusText = "⚠ GhostLock 尚未啟用：目前沒有可用的 Shizuku 執行服務";
                        break;
                    case ERROR:
                    default:
                        statusText = "⚠ GhostLock 發生錯誤";
                        break;
                }
                updatePrivilegeStatus(statusText);
                appendOutput("\n[GhostLock] 結果：" + statusText + "\n");
                if (detail != null) appendOutput("[GhostLock] " + detail + "\n");
                if (kernel != null && !kernel.isEmpty()) appendOutput("[GhostLock] kernel：" + kernel + "\n");
                if (profiles != null && !profiles.isEmpty()) {
                    StringBuilder sb = new StringBuilder("[GhostLock] 可用 profiles：");
                    for (String p : profiles) sb.append(p).append(", ");
                    appendOutput(sb.toString() + "\n");
                }
            });
        });
    }

    /** The script address is fixed at build time; users cannot change it. */
    private String getScriptUrl() {
        return DEFAULT_SCRIPT_URL;
    }

    /** Turns a GitHub "blob" page link into the raw file link so the app downloads the script, not HTML. */
    private static String normalizeScriptUrl(String url) {
        if (url == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^https://github\\.com/([^/]+)/([^/]+)/blob/(.+)$").matcher(url.trim());
        if (m.find()) {
            return "https://raw.githubusercontent.com/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3);
        }
        return url.trim();
    }

    private LinearLayout buildAboutPage() {
        LinearLayout page = newPage("關於");
        TextView ver = label("v2.8", 12, MUTED, false);
        TextView tag = label("MOBAI", 11, ACCENT, true);
        LinearLayout.LayoutParams first = cardLp();
        first.topMargin = dp(16);
        page.addView(listCard("版本", ver, tag), first);

        TextView steps = label("① 到「終端」按「開始運行」\n② 出現選項時，點上方的按鈕\n③ 看到「配置完成」，介面就會出現", 12, MUTED, false);
        page.addView(listCard("使用步驟", steps, null), cardLp());

        TextView about = label("MOBAI 會啟動內建的主程式，並顯示運行過程。", 12, MUTED, false);
        page.addView(listCard("說明", about, null), cardLp());

        TextView perm = label("會依序嘗試 Shizuku → root → 一般權限。\n請只在信任的來源使用。", 12, MUTED, false);
        page.addView(listCard("權限", perm, null), cardLp());

        TextView pkg = label(getPackageName(), 12, MUTED, false);
        page.addView(listCard("套件名稱", pkg, null), cardLp());
        return page;
    }

    private static void appendSpan(android.text.SpannableStringBuilder sb, String text, int color, boolean bold) {
        int start = sb.length();
        sb.append(text);
        sb.setSpan(new android.text.style.ForegroundColorSpan(color), start, sb.length(),
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) {
            sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), start, sb.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    /** Boot-log lines: device facts are real; module lines are only for show. */
    private java.util.List<String[]> buildBootLines() {
        java.util.List<String[]> l = new java.util.ArrayList<>();
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        String abi = android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "?";
        String kernel = System.getProperty("os.version");
        l.add(new String[] {"HEAD", "MOBAI Boot Loader v2.9"});
        l.add(new String[] {"INFO", "bootloader: cold start"});
        l.add(new String[] {"DEBUG", "package   = " + getPackageName()});
        l.add(new String[] {"DEBUG", "device    = " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL});
        l.add(new String[] {"DEBUG", "board     = " + android.os.Build.BOARD + " / " + android.os.Build.HARDWARE});
        l.add(new String[] {"DEBUG", "android   = " + android.os.Build.VERSION.RELEASE
                + " (API " + android.os.Build.VERSION.SDK_INT + ")"});
        l.add(new String[] {"DEBUG", "kernel    = " + (kernel == null ? "?" : kernel)});
        l.add(new String[] {"DEBUG", "abi       = " + abi});
        l.add(new String[] {"DEBUG", "cpu cores = " + Runtime.getRuntime().availableProcessors()});
        l.add(new String[] {"DEBUG", "heap max  = " + (Runtime.getRuntime().maxMemory() / (1024 * 1024)) + " MB"});
        l.add(new String[] {"DEBUG", "display   = " + dm.widthPixels + "x" + dm.heightPixels
                + " @" + dm.densityDpi + "dpi"});
        l.add(new String[] {"DEBUG", "locale    = " + java.util.Locale.getDefault()});
        l.add(new String[] {"DEBUG", "layout    = " + (wideLayout ? "wide (sidebar)" : "compact (bottom bar)")});
        l.add(new String[] {"BLANK", ""});
        l.add(new String[] {"INFO", "starting subsystems"});
        l.add(new String[] {"OK", "register crash recorder"});
        l.add(new String[] {"DEBUG", "crash log dir = files/"});
        l.add(new String[] {"OK", "init terminal core"});
        l.add(new String[] {"DEBUG", "terminal window = 48 x 140"});
        l.add(new String[] {"OK", "load pty bridge"});
        l.add(new String[] {"DEBUG", "pty: forkpty ready, utf-8"});
        l.add(new String[] {"OK", "load ansi renderer"});
        l.add(new String[] {"DEBUG", "ansi: sgr 16 / 256 / truecolor"});
        l.add(new String[] {"OK", "init quick-reply parser"});
        l.add(new String[] {"DEBUG", "menu pattern compiled"});
        l.add(new String[] {"OK", "build backdrop layers"});
        l.add(new String[] {"DEBUG", "blobs = 3, gradient = 2 stops"});
        l.add(new String[] {"OK", "start glass renderer"});
        l.add(new String[] {"DEBUG", "blur: scale 1/8, radius 3, passes 2"});
        l.add(new String[] {"OK", "init navigation"});
        l.add(new String[] {"DEBUG", "pages = terminal, settings, about"});
        l.add(new String[] {"OK", "init network stack"});
        l.add(new String[] {"DEBUG", "tls = https only, timeout 15s"});
        l.add(new String[] {"OK", "resolve script source"});
        l.add(new String[] {"DEBUG", "cache = files/main.sh.cached"});
        l.add(new String[] {"OK", "prepare shizuku / root probe"});
        l.add(new String[] {"OK", "mount user interface"});
        l.add(new String[] {"BLANK", ""});
        l.add(new String[] {"INFO", "all subsystems started"});
        l.add(new String[] {"READY", "MOBAI ready._"});
        return l;
    }

    private View scrolled(LinearLayout page) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(page);
        return sv;
    }

    private void showPage(int index) {
        if (index == currentPage) return;
        final int old = currentPage;
        currentPage = index;
        positionPill(old >= 0);
        for (int i = 0; i < pages.length; i++) {
            pages[i].animate().cancel();
            pages[i].setAlpha(1f);
            pages[i].setTranslationX(0f);
            pages[i].setTranslationY(0f);
            if (i != index && i != old) pages[i].setVisibility(View.GONE);
        }
        final View in = pages[index];
        in.setVisibility(View.VISIBLE);
        if (old < 0) return;
        final View out = pages[old];
        float dir = index > old ? 1f : -1f;
        final float offset = dp(28) * dir;
        in.setAlpha(0f);
        if (wideLayout) in.setTranslationY(offset); else in.setTranslationX(offset);
        android.view.animation.DecelerateInterpolator ease = new android.view.animation.DecelerateInterpolator(1.6f);
        in.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(320).setInterpolator(ease)
                .setUpdateListener(a -> { if (navGlass != null) navGlass.refresh(); }).start();
        out.animate().alpha(0f).translationX(wideLayout ? 0f : -offset).translationY(wideLayout ? -offset : 0f)
                .setDuration(220).setInterpolator(ease).withEndAction(() -> {
                    if (currentPage != pages.length && pages[currentPage] != out) {
                        out.setVisibility(View.GONE);
                    }
                    out.setAlpha(1f);
                    out.setTranslationX(0f);
                    out.setTranslationY(0f);
                }).start();
    }

    /** Slides the highlight capsule to the selected tab. */
    private void positionPill(boolean animate) {
        if (navPill == null || navItems == null || currentPage < 0) return;
        View target = navItems[currentPage];
        if (target.getWidth() == 0 || target.getHeight() == 0) return;
        android.view.ViewGroup.LayoutParams lp = navPill.getLayoutParams();
        if (lp.width != target.getWidth() || lp.height != target.getHeight()) {
            lp.width = target.getWidth();
            lp.height = target.getHeight();
            navPill.setLayoutParams(lp);
        }
        float x = navRow.getLeft() + target.getLeft();
        float y = navRow.getTop() + target.getTop();
        navPill.animate().cancel();
        if (animate) {
            navPill.animate().translationX(x).translationY(y).setDuration(340)
                    .setInterpolator(new android.view.animation.OvershootInterpolator(0.9f)).start();
        } else {
            navPill.setTranslationX(x);
            navPill.setTranslationY(y);
        }
    }

    private void buildUi(boolean playSplash) {
        wideLayout = getResources().getConfiguration().screenWidthDp >= 600;
        final android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(BG);

        // Content layer: soft gradient backdrop; this is what the glass panels blur.
        android.widget.FrameLayout content = new android.widget.FrameLayout(this);
        content.setBackground(new Backdrop());
        if (wideLayout) content.setPadding(dp(204), 0, 0, 0);
        else content.setPadding(0, 0, 0, dp(94));
        pages = new View[] {buildTerminalPage(), scrolled(buildSettingsPage()), scrolled(buildAboutPage())};
        for (View p : pages) {
            content.addView(p, new android.widget.FrameLayout.LayoutParams(-1, -1));
        }
        root.addView(content, new android.widget.FrameLayout.LayoutParams(-1, -1));

        // Navigation: frosted panel on the left (tablet) or floating at the bottom (phone).
        navGlass = new GlassLayout(this, dp(wideLayout ? 28 : 32));
        navGlass.setTint(glassFill, glassStroke);
        navGlass.setBlurEnabled(blurEnabled);
        navGlass.setLiquidGlassEnabled(liquidGlassEnabled);
        navGlass.setSource(content);
        navPill = new View(this);
        navPill.setBackground(round(pillFill, wideLayout ? 20 : 26, pillFill, 0));
        navGlass.addView(navPill, new android.widget.FrameLayout.LayoutParams(0, 0));

        navRow = new LinearLayout(this);
        navRow.setOrientation(wideLayout ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        navRow.setPadding(dp(8), dp(wideLayout ? 18 : 6), dp(8), dp(6));
        String[] names = {"終端", "設置", "關於"};
        String[] glyphs = {">_", "⚙", "i"};
        navItems = new LinearLayout[names.length];
        for (int i = 0; i < names.length; i++) {
            LinearLayout nav = new LinearLayout(this);
            nav.setOrientation(wideLayout ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
            nav.setGravity(wideLayout ? (Gravity.CENTER_VERTICAL | Gravity.START) : Gravity.CENTER);
            nav.setPadding(dp(wideLayout ? 16 : 4), 0, dp(wideLayout ? 12 : 4), 0);
            TextView glyph = label(glyphs[i], wideLayout ? 18 : 17, TEXT, true);
            glyph.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            glyph.setGravity(Gravity.CENTER);
            nav.addView(glyph, new LinearLayout.LayoutParams(wideLayout ? dp(30) : -2, -2));
            TextView name = label(names[i], wideLayout ? 15 : 11, TEXT, true);
            if (wideLayout) name.setPadding(dp(12), 0, 0, 0);
            nav.addView(name);
            final int index = i;
            nav.setOnClickListener(v -> showPage(index));
            LinearLayout.LayoutParams navLp = wideLayout
                    ? new LinearLayout.LayoutParams(-1, dp(52))
                    : new LinearLayout.LayoutParams(0, -1, 1);
            if (wideLayout) navLp.topMargin = dp(6);
            navRow.addView(nav, navLp);
            navItems[i] = nav;
        }
        navGlass.addView(navRow, new android.widget.FrameLayout.LayoutParams(-1, -1));
        navGlass.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot) positionPill(false);
        });
        android.widget.FrameLayout.LayoutParams glassLp;
        if (wideLayout) {
            glassLp = new android.widget.FrameLayout.LayoutParams(dp(180), -1, Gravity.START);
            glassLp.setMargins(dp(12), dp(12), 0, dp(12));
        } else {
            glassLp = new android.widget.FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM);
            glassLp.setMargins(dp(16), 0, dp(16), dp(14));
        }
        root.addView(navGlass, glassLp);

        // Launch animation: computer-style boot log with debug lines (tap to skip).
        if (playSplash) {
            final android.widget.FrameLayout splash = new android.widget.FrameLayout(this);
            splash.setBackgroundColor(0xFF0B0F14);
            splash.setClickable(true);
            final TextView log = label("", 11, 0xFFD6E2EA, false);
            log.setTypeface(Typeface.MONOSPACE);
            log.setLineSpacing(0f, 1.25f);
            log.setPadding(dp(16), dp(44), dp(16), dp(52));
            final ScrollView logScroll = new ScrollView(this);
            logScroll.setVerticalScrollBarEnabled(false);
            logScroll.addView(log);
            splash.addView(logScroll, new android.widget.FrameLayout.LayoutParams(-1, -1));
            TextView hint = label("點擊畫面可跳過", 11, 0xFF6B7A86, false);
            hint.setGravity(Gravity.CENTER);
            splash.addView(hint, new android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
            hint.setPadding(0, 0, 0, dp(18));
            root.addView(splash, new android.widget.FrameLayout.LayoutParams(-1, -1));

            final java.util.List<String[]> lines = buildBootLines();
            final android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
            final java.util.Random random = new java.util.Random();
            final long t0 = android.os.SystemClock.elapsedRealtime();
            final boolean[] done = {false};
            final int[] index = {0};
            final Runnable finish = () -> {
                if (done[0]) return;
                done[0] = true;
                splash.animate().alpha(0f).setDuration(450).withEndAction(() -> root.removeView(splash)).start();
            };
            splash.setOnClickListener(v -> finish.run());
            final Runnable step = new Runnable() {
                @Override
                public void run() {
                    if (done[0]) return;
                    if (index[0] >= lines.size()) {
                        handler.postDelayed(finish, 900);
                        return;
                    }
                    String[] line = lines.get(index[0]++);
                    String level = line[0];
                    String text = line[1];
                    double seconds = (android.os.SystemClock.elapsedRealtime() - t0) / 1000.0;
                    if (!"BLANK".equals(level)) {
                        appendSpan(sb, String.format(java.util.Locale.US, "[%7.3f] ", seconds), 0xFF5E6C78, false);
                    }
                    switch (level) {
                        case "HEAD":
                            appendSpan(sb, text, 0xFFFFFFFF, true);
                            break;
                        case "OK":
                            StringBuilder padded = new StringBuilder(text);
                            while (padded.length() < 30) padded.append('.');
                            appendSpan(sb, "[ INFO ] ", 0xFF7DCFFF, false);
                            appendSpan(sb, padded + " ", 0xFFD6E2EA, false);
                            appendSpan(sb, "[  OK  ]", 0xFF4DFF88, true);
                            break;
                        case "DEBUG":
                            appendSpan(sb, "[DEBUG] ", 0xFF7AA2F7, false);
                            appendSpan(sb, text, 0xFF9AA8B4, false);
                            break;
                        case "INFO":
                            appendSpan(sb, "[ INFO ] ", 0xFF7DCFFF, false);
                            appendSpan(sb, text, 0xFFD6E2EA, false);
                            break;
                        case "READY":
                            appendSpan(sb, text, 0xFF4DFF88, true);
                            break;
                        default:
                            break;
                    }
                    sb.append('\n');
                    log.setText(sb);
                    logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
                    int delay = "OK".equals(level) ? 170 + random.nextInt(130)
                            : 90 + random.nextInt(90);
                    if ("READY".equals(level) || "HEAD".equals(level)) delay = 380;
                    handler.postDelayed(this, delay);
                }
            };
            handler.postDelayed(step, 350);
        }

        setContentView(root);
        showPage(0);
    }

    private void runBuiltInScript() {
        if (scriptRunning) {
            sendInteractiveInput();
            return;
        }
        output.setText("");
        ansi.reset();
        recentText.setLength(0);
        updateQuickReplies();
        final String input = inputBox.getText().toString();
        final boolean pty = usePty;
        ptyBox.setEnabled(false);
        runButton.setEnabled(false);
        status.setText("啟動中");
        status.setTextColor(ACCENT);
        appendOutput("▶ 開始運行 MOBAI…\n");
        if (!input.isEmpty()) appendOutput("啟動參數：" + input + "\n");

        executor.execute(() -> {
            File localScript = null;
            long localPtyHandle = 0L;
            Process localProc = null;
            boolean localPtyWaitCompleted = false;
            try {
                // main.sh contains an ELF payload: keep and transfer its raw bytes.
                byte[] scriptBytes = loadScriptBytes();
                if ("shizuku".equals(executionMode)) {
                    IShellUserService service = shizukuShellService;
                    if (service == null) {
                        CountDownLatch latch = userServiceReady;
                        latch.await(10, TimeUnit.SECONDS);
                        service = shizukuShellService;
                    }
                    if (service == null) {
                        throw new IllegalStateException(
                                "Shizuku UserService 尚未連線。請確認 Shizuku 正在執行且已授權，再重試。");
                    }

                    appendOutput("使用 Shizuku 權限運行\n");
                    service.setUsePty(pty);
                    service.beginScript(scriptBytes.length);
                    boolean started = false;
                    try {
                        final int chunkSize = 64 * 1024;
                        for (int offset = 0; offset < scriptBytes.length; offset += chunkSize) {
                            int end = Math.min(scriptBytes.length, offset + chunkSize);
                            service.writeScriptChunk(Arrays.copyOfRange(scriptBytes, offset, end));
                        }
                        // Queue the UI state before start: the first output or exit callback
                        // must never be overwritten by a later "running" state update.
                        runOnUiThread(() -> {
                            inputBox.setText("");
                            setInteractiveMode(true);
                        });
                        service.startScript(input, shellOutputCallback);
                        started = true;
                    } finally {
                        if (!started) {
                            try { service.abortScript(); } catch (Exception ignored) { }
                        }
                    }
                    return;
                }

                localScript = new File(getCacheDir(), "main.sh");
                try (FileOutputStream out = new FileOutputStream(localScript)) {
                    out.write(scriptBytes);
                    out.flush();
                }

                appendOutput("使用 " + ("root".equals(executionMode) ? "root 權限" : "一般權限") + " 運行\n");
                if (pty) {
                    localPtyHandle = startLocalProcess(localScript, input);
                    activePtyHandle = localPtyHandle;
                    final long runningHandle = localPtyHandle;
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    try (InputStream stream = PtyBridge.openInputStream(runningHandle);
                         InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                        char[] buffer = new char[2048];
                        int count;
                        while ((count = reader.read(buffer)) != -1) {
                            if (count > 0) appendOutput(new String(buffer, 0, count));
                        }
                    }
                    int code = PtyBridge.waitFor(runningHandle);
                    localPtyWaitCompleted = true;
                    activePtyHandle = 0L;
                    runOnUiThread(() -> completeScript(code));
                } else {
                    final Process proc = startLocalPipeProcess(localScript, input);
                    localProc = proc;
                    activeProcess = proc;
                    activeProcessInput = proc.getOutputStream();
                    runOnUiThread(() -> {
                        inputBox.setText("");
                        setInteractiveMode(true);
                    });
                    Thread reader = new Thread(() -> {
                        try (InputStream stream = proc.getInputStream();
                             InputStreamReader r = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                            char[] buffer = new char[2048];
                            int count;
                            while ((count = r.read(buffer)) != -1) {
                                if (count > 0) appendOutput(new String(buffer, 0, count));
                            }
                        } catch (Exception ignored) {
                            // Stream closed.
                        }
                    }, "TermiGlow-PipeReader");
                    reader.setDaemon(true);
                    reader.start();
                    int code = proc.waitFor();
                    reader.join(1500);
                    localPtyWaitCompleted = true;
                    activeProcess = null;
                    activeProcessInput = null;
                    runOnUiThread(() -> completeScript(code));
                }
            } catch (Exception e) {
                if (localProc != null && !localPtyWaitCompleted) localProc.destroy();
                activeProcess = null;
                activeProcessInput = null;
                if (localPtyHandle > 0L && !localPtyWaitCompleted) {
                    PtyBridge.terminate(localPtyHandle);
                    try { PtyBridge.waitFor(localPtyHandle); } catch (Exception ignored) { }
                }
                activePtyHandle = 0L;
                String message = describeError(e);
                runOnUiThread(() -> finishWithError(message));
            } finally {
                if (localScript != null && localScript.exists()) localScript.delete();
            }
        });
    }


    /** Shows tap-to-answer buttons when the program is waiting at a numbered menu. */
    private void updateQuickReplies() {
        if (quickBox == null) return;
        String t = recentText.toString();
        int idx = Math.max(t.lastIndexOf("请选择"), t.lastIndexOf("請選擇"));
        boolean waiting = scriptRunning && idx >= 0 && t.indexOf('\n', idx) < 0;
        java.util.LinkedHashMap<String, String> opts = new java.util.LinkedHashMap<>();
        if (waiting) {
            String before = t.substring(Math.max(0, idx - 900), idx);
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?m)^\\s*\\[(\\d+)\\]\\s*(.+?)\\s*$").matcher(before);
            while (m.find()) opts.put(m.group(1), m.group(2));
        }
        if (opts.isEmpty()) {
            quickBox.setVisibility(View.GONE);
            lastMenuSig = "";
            return;
        }
        String sig = opts.toString();
        if (sig.equals(lastMenuSig) && quickBox.getVisibility() == View.VISIBLE) return;
        lastMenuSig = sig;
        quickBar.removeAllViews();
        for (java.util.Map.Entry<String, String> e : opts.entrySet()) {
            addQuickChip(e.getKey() + "．" + friendlyOption(e.getValue()), e.getKey(), false);
        }
        addQuickChip("使用預設", "", true);
        quickBox.setVisibility(View.VISIBLE);
    }

    private void addQuickChip(String label, String reply, boolean primary) {
        Button chip = actionButton(label, primary ? ACCENT : Color.WHITE, primary ? Color.WHITE : TEXT);
        chip.setOnClickListener(v -> {
            inputBox.setText(reply);
            sendInteractiveInput();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.rightMargin = dp(8);
        quickBar.addView(chip, lp);
    }

    private String friendlyOption(String raw) {
        if (raw.contains("无后台") || raw.contains("無後台")) {
            if (raw.contains("开启") || raw.contains("開啟")) return "關閉程式時，介面一起關閉（推薦）";
            if (raw.contains("关闭") || raw.contains("關閉")) return "介面留在背景，關閉程式後仍繼續顯示";
        }
        return raw;
    }

    /** Send one line to a running script instead of starting it again. */
    private void sendInteractiveInput() {
        if (!scriptRunning) return;
        final String line = inputBox.getText().toString();
        try {
            if ("shizuku".equals(executionMode)) {
                IShellUserService service = shizukuShellService;
                if (service == null) throw new IllegalStateException("Shizuku UserService 已斷線。");
                service.writeInput(line);
            } else {
                long handle = activePtyHandle;
                OutputStream pipeIn = activeProcessInput;
                if (handle != 0L) {
                    PtyBridge.writeLine(handle, line);
                } else if (pipeIn != null) {
                    pipeIn.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                    pipeIn.flush();
                } else {
                    throw new IllegalStateException("目前沒有可接收輸入的程序。");
                }
            }
            // A real PTY supplies normal terminal echo; do not duplicate the line here.
            inputBox.setText("");
            inputBox.requestFocus();
        } catch (Exception e) {
            appendOutput("\n⚠ 送出失敗：" + describeError(e) + "\n");
        }
    }

    private void setInteractiveMode(boolean running) {
        scriptRunning = running;
        runButton.setEnabled(true);
        if (ptyBox != null) ptyBox.setEnabled(!running);
        if (running) {
            runButton.setText("↵  送出");
            inputLabel.setText("回覆程式的提問");
            inputBox.setHint("輸入選項數字（例如 1），再按「送出」；直接按送出＝使用預設");
            status.setText("運行中");
            status.setTextColor(ACCENT);
        } else {
            runButton.setText("▶  開始運行");
            inputLabel.setText("啟動參數（選填，一般不用填）");
            inputBox.setHint("一般請留空");
        }
    }

    private void completeScript(int exitCode) {
        scriptRunning = false;
        activePtyHandle = 0L;
        appendOutput(exitCode == 0 ? "\n✔ 程式已結束。\n" : "\n⚠ 程式已結束（代碼 " + exitCode + "）。\n");
        updateExitStatus(exitCode);
        setInteractiveMode(false);
    }

    private byte[] readBuiltInScriptBytes() throws Exception {
        try (InputStream in = getAssets().open("main.sh");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    /** Downloads main.sh when a URL is set (falls back to the last download), else uses the bundled copy. */
    private byte[] loadScriptBytes() throws Exception {
        String url = getScriptUrl();
        if (url.isEmpty()) {
            appendOutput("未設定主程式網址，使用內建版本。\n");
            return readBuiltInScriptBytes();
        }
        File cache = new File(getFilesDir(), "main.sh.cached");
        appendOutput("正在下載主程式…\n");
        try {
            if (!url.startsWith("https://")) throw new IllegalStateException("網址必須以 https:// 開頭");
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            int status = conn.getResponseCode();
            if (status != 200) throw new IllegalStateException("伺服器回應 " + status);
            byte[] data;
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16384];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                data = out.toByteArray();
            } finally {
                conn.disconnect();
            }
            if (data.length < 64) throw new IllegalStateException("下載的檔案太小");
            try (FileOutputStream out = new FileOutputStream(cache)) {
                out.write(data);
            }
            appendOutput("✔ 下載完成（" + (data.length / 1024) + " KB）\n");
            return data;
        } catch (Exception e) {
            if (cache.exists()) {
                appendOutput("⚠ 下載失敗（" + describeError(e) + "），改用上次下載的版本。\n");
                try (InputStream in = new java.io.FileInputStream(cache); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[16384];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    return out.toByteArray();
                }
            }
            throw new IllegalStateException("下載主程式失敗：" + describeError(e));
        }
    }

    private int findBytes(byte[] source, byte[] target) {
        if (target.length == 0 || source.length < target.length) return -1;
        outer: for (int i = 0; i <= source.length - target.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (source[i + j] != target[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private Process startLocalPipeProcess(File script, String input) throws Exception {
        String arg = input == null ? "" : input;
        ProcessBuilder builder;
        if ("root".equals(executionMode)) {
            builder = new ProcessBuilder("su", "-c",
                    "/system/bin/sh " + shellQuote(script.getAbsolutePath()) + " " + shellQuote(arg));
        } else {
            builder = new ProcessBuilder("/system/bin/sh", script.getAbsolutePath(), arg);
        }
        builder.directory(getFilesDir());
        builder.redirectErrorStream(true);
        return builder.start();
    }

    private long startLocalProcess(File script, String input) throws Exception {
        // Same as typing `sh main.sh` in MT Manager's terminal: run as the app user inside the PTY.
        // main.sh detects root / su / Shizuku rish by itself and only elevates the ELF launch.
        String command = "exec /system/bin/sh " + shellQuote(script.getAbsolutePath())
                + " " + shellQuote(input == null ? "" : input);
        return PtyBridge.start(command, getFilesDir(), 48, 140);
    }

    private void checkShizukuPermission() {
        if (!Shizuku.pingBinder()) return;
        if (shizukuPermissionRequestPending || shizukuShellService != null
                || userServiceBindInProgress || "shizuku".equals(executionMode)) return;
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                executionMode = "shizuku";
                appendOutput("✔ 已有 Shizuku 授權，正在連線…\n");
                bindShizukuUserService();
            } else {
                shizukuPermissionRequestPending = true;
                appendOutput("正在請求 Shizuku 授權…\n");
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Exception e) {
            shizukuPermissionRequestPending = false;
            appendOutput("Shizuku 無法使用：" + describeError(e) + "\n");
            requestRootFallback();
        }
    }

    private void bindShizukuUserService() {
        if (shizukuShellService != null || userServiceBindInProgress) return;
        try {
            userServiceBindInProgress = true;
            userServiceReady = new CountDownLatch(1);
            userServiceArgs = new Shizuku.UserServiceArgs(
                    new ComponentName(this, ShellUserService.class))
                    // Shizuku API 13.1.5 requires a non-null process-name suffix.
                    .processNameSuffix("mobai_shell")
                    .tag("termiglow-shell-user-service")
                    .version(5)
                    .daemon(false);
            Shizuku.bindUserService(userServiceArgs, userServiceConnection);
            appendOutput("正在連線 Shizuku…\n");
        } catch (Exception e) {
            userServiceBindInProgress = false;
            userServiceReady.countDown();
            appendOutput("⚠ Shizuku 連線失敗：" + describeError(e) + "\n");
            executionMode = rootAvailable ? "root" : "normal";
            requestRootFallback();
        }
    }

    private void requestRootFallback() {
        if (rootFallbackStarted || "shizuku".equals(executionMode)) return;
        rootFallbackStarted = true;
        executor.execute(() -> {
            Process probe = null;
            try {
                probe = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        probe.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line).append('\n');
                }
                int code = probe.waitFor();
                if ("shizuku".equals(executionMode)) return;
                if (code == 0 && result.toString().contains("uid=0")) {
                    rootAvailable = true;
                    executionMode = "root";
                    runOnUiThread(() -> {
                        appendOutput("✔ 已取得 root 授權。\n");
                        updatePrivilegeStatus("root 已就緒");
                    });
                } else {
                    rootAvailable = false;
                    executionMode = "normal";
                    runOnUiThread(() -> {
                        appendOutput("未取得 root，將使用一般權限。\n");
                        updatePrivilegeStatus("一般權限");
                    });
                }
            } catch (Exception e) {
                if ("shizuku".equals(executionMode)) return;
                rootAvailable = false;
                executionMode = "normal";
                runOnUiThread(() -> {
                    appendOutput("此裝置沒有 root，將使用一般權限。\n");
                    updatePrivilegeStatus("一般權限");
                });
            } finally {
                if (probe != null) probe.destroy();
            }
        });
    }

    private int extractExitCode(String transcript) {
        Matcher matcher = Pattern.compile("\\[process exited: (-?\\d+)\\]").matcher(transcript);
        int result = Integer.MIN_VALUE;
        while (matcher.find()) {
            try {
                result = Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return Integer.MIN_VALUE;
            }
        }
        return result;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private String describeError(Throwable error) {
        Throwable deepest = error;
        while (deepest.getCause() != null && deepest.getCause() != deepest) {
            deepest = deepest.getCause();
        }
        String message = deepest.getMessage();
        if (message == null || message.trim().isEmpty()) message = deepest.getClass().getSimpleName();
        return error.getClass().getSimpleName() + ": " + message;
    }

    private void updatePrivilegeStatus(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> updatePrivilegeStatus(text));
            return;
        }
        if (privilegeInfo != null) privilegeInfo.setText(text);
        if (status == null) return;
        status.setText("" + text);
        status.setTextColor(ACCENT);
    }

    private void updateExitStatus(int code) {
        status.setText(code == 0 ? "已完成" : "異常結束 (" + code + ")");
        status.setTextColor(code == 0 ? ACCENT : ERROR);
    }

    private void finishWithError(String message) {
        appendOutput("⚠ " + message + "\n");
        status.setText("發生錯誤");
        status.setTextColor(ERROR);
        setInteractiveMode(false);
        runButton.setEnabled(true);
    }

    private void appendOutput(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> appendOutput(text));
            return;
        }
        CharSequence plain = ansi.feed(text);
        output.append(plain);
        recentText.append(plain);
        if (recentText.length() > 4000) recentText.delete(0, recentText.length() - 3000);
        updateQuickReplies();
        if (navGlass != null) navGlass.refresh();
        CharSequence all = output.getText();
        if (all instanceof android.text.Editable && all.length() > 160000) {
            ((android.text.Editable) all).delete(0, all.length() - 120000);
        }
        if (outputScroll != null) {
            outputScroll.post(() -> outputScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(fg);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        boolean light = bg == Color.WHITE;
        button.setBackground(round(light ? 0xB3FFFFFF : bg, 26, light ? 0xCCFFFFFF : bg, light ? 1 : 0));
        return button;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private GradientDrawable glassBg(int radius) {
        return round(glassFill, radius, glassStroke, 1);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderListener);
        if (userServiceArgs != null && userServiceBound) {
            try {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true);
            } catch (Exception ignored) {
                // Shizuku may already have been stopped while the Activity was closing.
            }
        }
        long handle = activePtyHandle;
        if (handle > 0L) PtyBridge.terminate(handle);
        Process pipeProc = activeProcess;
        if (pipeProc != null) pipeProc.destroy();
        if (scriptRunning && shizukuShellService != null) {
            try { shizukuShellService.abortScript(); } catch (Exception ignored) { }
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}