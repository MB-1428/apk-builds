package com.example.termiglow;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * GhostLock 临时 root 集成管理器。
 *
 * useShizuku = true：
 *   通过 Shizuku UserService（shell uid=2000）执行 GhostLock。
 *   shell 进程无 seccomp 过滤，W3 阶段被跳过，避免内核崩溃风险。
 *   二进制和 profile 以字节流交给 UserService，由其释放到临时目录并执行。
 *
 * useShizuku = false：
 *   原有方式，在 app 进程内通过 ProcessBuilder 执行。
 *   app 进程有 seccomp 过滤，W3 阶段会尝试绕过（有 panic 风险）。
 */
public final class GhostLockManager {
    private static final String TAG = "GhostLock";
    private static final String ASSET_DIR = "kernel_profiles";
    private static final String BIN_NAME = "libGhostlock.so";

    public enum Result {
        SUCCESS,
        EXEC_FAILED,
        NO_PROFILE,
        NO_BINARY,
        SHIZUKU_UNAVAILABLE,
        ERROR
    }

    public static final class Outcome {
        public final Result result;
        public final String kernelRelease;
        public final String detail;
        public final List<String> availableProfiles;
        public final boolean viaShizuku;

        Outcome(Result r, String kernel, String detail,
                List<String> profiles, boolean viaShizuku) {
            this.result = r;
            this.kernelRelease = kernel;
            this.detail = detail;
            this.availableProfiles = profiles;
            this.viaShizuku = viaShizuku;
        }
    }

    private final Context context;
    private final boolean useShizuku;
    private final IShellUserService shizukuService; // 可为 null，useShizuku 时需非 null

    /**
     * Safe default constructor used by the current UI.
     * It does not start the bundled privilege-escalation payload; an explicit,
     * connected service is required for any execution path.
     */
    public GhostLockManager(Context context) {
        this(context, true, null);
    }

    /**
     * @param context        应用上下文
     * @param useShizuku     true = 通过 Shizuku shell 执行（跳过 W3）
     * @param shizukuService 已连接的 IShellUserService，useShizuku=true 时不能为 null
     */
    public GhostLockManager(Context context, boolean useShizuku,
                            IShellUserService shizukuService) {
        this.context = context.getApplicationContext();
        this.useShizuku = useShizuku;
        this.shizukuService = shizukuService;
    }

    public String getKernelRelease() {
        try {
            Process p = new ProcessBuilder("uname", "-r")
                    .redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine();
            p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            return "";
        }
    }

    public List<String> listAvailableProfiles() {
        List<String> out = new ArrayList<>();
        try {
            String[] list = context.getAssets().list(ASSET_DIR);
            if (list == null) return out;
            for (String name : list) {
                if (name.endsWith(".conf")) {
                    out.add(name.substring(0, name.length() - 5));
                }
            }
        } catch (IOException e) {
            Log.w(TAG, "list profiles failed", e);
        }
        return out;
    }

    public Outcome run() {
        String kernel = getKernelRelease();
        if (kernel.isEmpty()) {
            return new Outcome(Result.ERROR, kernel,
                    "無法讀取 uname -r", listAvailableProfiles(), useShizuku);
        }

        String targetAsset = ASSET_DIR + "/" + kernel + ".conf";
        if (!assetExists(targetAsset)) {
            return new Outcome(Result.NO_PROFILE, kernel,
                    "當前內核 " + kernel + " 不在 GhostLock 支援列表",
                    listAvailableProfiles(), useShizuku);
        }

        if (useShizuku) {
            return runViaShizuku(kernel, targetAsset);
        } else {
            return runInProcess(kernel, targetAsset);
        }
    }

    // ==================== Shizuku 路径 ====================

    private Outcome runViaShizuku(String kernel, String targetAsset) {
        if (shizukuService == null) {
            return new Outcome(Result.SHIZUKU_UNAVAILABLE, kernel,
                    "Shizuku UserService 未連線", listAvailableProfiles(), true);
        }
        try {
            // 1. 读 nativeLibraryDir 中的 .so 字节
            byte[] binBytes;
            File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
            if (!bin.isFile()) {
                return new Outcome(Result.NO_BINARY, kernel,
                        "nativeLibraryDir 中缺少 " + BIN_NAME,
                        listAvailableProfiles(), true);
            }
            try (InputStream in = new FileInputStream(bin);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                binBytes = out.toByteArray();
            }

            // 2. 读 profile 字节
            byte[] profileBytes;
            try (InputStream in = context.getAssets().open(targetAsset);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                profileBytes = out.toByteArray();
            }

            // 3. 通过 Shizuku 执行
            String raw = shizukuService.runGhostLock(binBytes, profileBytes);
            return parseShizukuResult(raw, kernel);
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles(), true);
        }
    }

    private Outcome parseShizukuResult(String raw, String kernel) {
        String output = raw == null ? "" : raw;
        boolean ok = output.startsWith("exit=0\n");
        Result r = ok ? Result.SUCCESS : Result.EXEC_FAILED;
        return new Outcome(r, kernel, output, listAvailableProfiles(), true);
    }

    // ==================== 原有 in-process 路径 ====================

    private Outcome runInProcess(String kernel, String targetAsset) {
        File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
        if (!bin.exists() || !bin.canExecute()) {
            return new Outcome(Result.NO_BINARY, kernel,
                    "未找到 " + BIN_NAME + "（請確認已放入 jniLibs/arm64-v8a/）",
                    listAvailableProfiles(), false);
        }

        File profileFile;
        try {
            profileFile = new File(context.getFilesDir(), "gl_" + kernel + ".conf");
            copyAssetTo(profileFile, targetAsset);
        } catch (IOException e) {
            return new Outcome(Result.ERROR, kernel,
                    "釋放 profile 失敗: " + e.getMessage(),
                    listAvailableProfiles(), false);
        }

        Process proc = null;
        try {
            proc = new ProcessBuilder(
                    bin.getAbsolutePath(),
                    "--load-prebuilt-profile", profileFile.getAbsolutePath()
            ).redirectErrorStream(true).start();

            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            int code = proc.waitFor();
            String output = sb.toString().trim();
            if (code == 0) {
                return new Outcome(Result.SUCCESS, kernel, output,
                        listAvailableProfiles(), false);
            } else {
                return new Outcome(Result.EXEC_FAILED, kernel,
                        "exit " + code + (output.isEmpty() ? "" : ": " + output),
                        listAvailableProfiles(), false);
            }
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel,
                    e.getClass().getSimpleName() + ": " + e.getMessage(),
                    listAvailableProfiles(), false);
        } finally {
            if (proc != null) proc.destroy();
            if (profileFile.exists()) profileFile.delete();
        }
    }

    // ==================== 工具方法 ====================

    private void copyAssetTo(File dest, String assetPath) throws IOException {
        try (InputStream in = context.getAssets().open(assetPath);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
    }

    private boolean assetExists(String path) {
        try (InputStream ignored = context.getAssets().open(path)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}