# TermiGlow v2.0 — 即時互動 Shell / 白色主題

本版針對原始 `main.sh` 的互動選單進行修正。舊版在 `executeScript()` 內等待腳本結束後才回傳完整輸出，因此像 `请选择（默认 1）:` 這類沒有換行的提示不會即時顯示；而且執行中沒有把使用者後續輸入傳給程序 stdin。

## 主要改動

- 保留 `app/src/main/assets/main.sh` 原始位元組，不重寫 Shell 前綴、`PAYLOAD_OFFSET` 或內嵌 ELF。
- Shizuku UserService 改成非阻塞啟動，透過 AIDL callback 即時回傳程序輸出。
- 新增 PTY 嘗試：若 Android 環境提供 `script` applet，透過 `script -q -c ... /dev/null` 分配虛擬終端，讓需要 TTY 的原生互動選單能等待輸入；若系統沒有該 applet，會退回一般 stdin/stdout 管線。
- Root／一般權限執行也改成按字元區塊讀取，不再使用 `readLine()`，使未換行的提示可立即顯示。
- 執行中的底部 `$` 輸入列會把一行文字寫入正在執行的程序 stdin；此時按鈕會變成「送出輸入」。例如看到 `请选择（默认 1）:` 後輸入 `1` 再按「送出輸入」。
- 第一次啟動時，輸入框內容仍會作為原始腳本的 `$1`；腳本啟動後，輸入框切換成互動式輸入。
- 保留白色主題、Shizuku UserService `.processNameSuffix("termiglow_shell")` 和原始位元組分段傳輸。
- Android `minSdk 24`。

## 使用互動選單

1. 啟動腳本。
2. 等待終端區即時顯示 `请选择（默认 1）:`。
3. 在底部 `$` 輸入框輸入選項，例如 `1`。
4. 按「送出輸入」將文字傳給程序 stdin，不會重新啟動腳本。

第一次啟動時輸入的內容會作為 `$1`；啟動後輸入列改用於互動選單。

## 建置

使用 Android Studio 與 JDK 17 開啟專案，等待 Gradle Sync 後執行 `assembleDebug`，或由 GitHub Actions 建置 APK。

## 限制

本版會嘗試使用 Android 的 `script` applet 建立 PTY；不同 ROM 不一定提供該 applet，因此仍需在實機確認是否成功分配 TTY。若沒有 `script`，會退回一般 stdin/stdout 管線。此工作環境沒有完整 Android SDK／Gradle，故尚未實際完成 APK 編譯或裝置測試。
