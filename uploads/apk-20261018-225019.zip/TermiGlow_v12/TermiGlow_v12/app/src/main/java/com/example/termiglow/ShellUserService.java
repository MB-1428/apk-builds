package com.example.termiglow;

import android.os.RemoteException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku UserService that stages the self-extracting main.sh as raw bytes,
 * then runs it as an interactive process. Output is sent to the activity as
 * soon as it arrives, and user keystrokes are forwarded to process stdin.
 */
public final class ShellUserService extends IShellUserService.Stub {
    private static final int MAX_SCRIPT_BYTES = 8 * 1024 * 1024;
    private static final int CHUNK_CHARS = 2048;

    private final Object stagingLock = new Object();
    private final Object processLock = new Object();

    private File stagedScriptFile;
    private OutputStream stagedScriptOutput;
    private int expectedScriptBytes;
    private int writtenScriptBytes;

    private volatile Process activeProcess;
    private volatile OutputStream activeProcessInput;
    private volatile File activeScriptFile;

    public ShellUserService() {
        // Required no-argument constructor for Shizuku UserService.
    }

    @Override
    public void beginScript(int totalBytes) throws RemoteException {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
            if (totalBytes <= 0 || totalBytes > MAX_SCRIPT_BYTES) {
                throw new RemoteException("Invalid built-in script size: " + totalBytes);
            }
            File tempDirectory = new File("/data/local/tmp");
            if (!tempDirectory.isDirectory() || !tempDirectory.canWrite()) {
                throw new RemoteException("Shizuku UserService cannot write /data/local/tmp");
            }
            try {
                stagedScriptFile = File.createTempFile("termiglow-main-", ".sh", tempDirectory);
                stagedScriptOutput = new FileOutputStream(stagedScriptFile);
                expectedScriptBytes = totalBytes;
                writtenScriptBytes = 0;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to stage built-in script: " + e.getMessage());
            }
        }
    }

    @Override
    public void writeScriptChunk(byte[] chunk) throws RemoteException {
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script; beginScript must be called first");
            }
            if (chunk == null || writtenScriptBytes + chunk.length > expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Invalid script chunk length");
            }
            try {
                stagedScriptOutput.write(chunk);
                writtenScriptBytes += chunk.length;
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to write script chunk: " + e.getMessage());
            }
        }
    }

    @Override
    public void startScript(String input, IShellOutputCallback callback) throws RemoteException {
        if (callback == null) throw new RemoteException("Missing output callback");

        final File scriptFile;
        synchronized (stagingLock) {
            if (stagedScriptOutput == null || stagedScriptFile == null) {
                throw new RemoteException("No staged script to execute");
            }
            try {
                stagedScriptOutput.close();
            } catch (IOException e) {
                clearStagedScriptLocked();
                throw new RemoteException("Unable to close staged script: " + e.getMessage());
            }
            stagedScriptOutput = null;
            if (writtenScriptBytes != expectedScriptBytes) {
                clearStagedScriptLocked();
                throw new RemoteException("Incomplete script transfer: expected "
                        + expectedScriptBytes + " bytes, received " + writtenScriptBytes);
            }
            scriptFile = stagedScriptFile;
            stagedScriptFile = null;
            expectedScriptBytes = 0;
            writtenScriptBytes = 0;
        }

        synchronized (processLock) {
            if (activeProcess != null) {
                if (isProcessAlive(activeProcess)) {
                    scriptFile.delete();
                    throw new RemoteException("A script is already running");
                }
                activeProcess = null;
                activeProcessInput = null;
                activeScriptFile = null;
            }
        }

        Process process = null;
        try {
            String argument = input == null ? "" : input;
            String command = "exec /system/bin/sh " + shellQuote(scriptFile.getAbsolutePath())
                    + " " + shellQuote(argument);
            // Allocate a PTY so native prompts that require a terminal stay open and
            // read the choice instead of exiting immediately on a pipe-backed stdin.
            String ptyCommand = "if command -v script >/dev/null 2>&1; then "
                    + "exec script -q -c " + shellQuote(command) + " /dev/null; "
                    + "else exec " + command + "; fi";
            ProcessBuilder builder = new ProcessBuilder("/system/bin/sh", "-c", ptyCommand);
            builder.directory(new File("/"));
            builder.redirectErrorStream(true);
            process = builder.start();
            synchronized (processLock) {
                activeProcess = process;
                activeProcessInput = process.getOutputStream();
                activeScriptFile = scriptFile;
            }

            final Process runningProcess = process;
            final File scriptToDelete = scriptFile;
            Thread readerThread = new Thread(
                    () -> streamProcess(runningProcess, scriptToDelete, callback),
                    "TermiGlow-ShellOutput");
            readerThread.setDaemon(true);
            readerThread.start();
        } catch (IOException | RuntimeException e) {
            if (process != null) process.destroy();
            scriptFile.delete();
            synchronized (processLock) {
                activeProcess = null;
                activeProcessInput = null;
                activeScriptFile = null;
            }
            throw new RemoteException("Unable to start interactive script: " + e.getMessage());
        }
    }

    private void streamProcess(Process process, File scriptFile, IShellOutputCallback callback) {
        int exitCode = -1;
        String streamError = null;
        boolean callbackAvailable = true;
        try (InputStream stream = process.getInputStream();
             Reader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            char[] buffer = new char[CHUNK_CHARS];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                if (count == 0) continue;
                if (callbackAvailable) {
                    try {
                        callback.onOutput(new String(buffer, 0, count));
                    } catch (RemoteException e) {
                        // Keep draining stdout even if the Activity has gone away;
                        // otherwise the child can block forever on a full output pipe.
                        callbackAvailable = false;
                    }
                }
            }
            exitCode = process.waitFor();
        } catch (Exception e) {
            streamError = e.getClass().getSimpleName() + ": "
                    + (e.getMessage() == null ? "output stream failed" : e.getMessage());
            process.destroy();
            try {
                exitCode = process.waitFor();
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
            }
        } finally {
            try {
                OutputStream stdin = process.getOutputStream();
                stdin.close();
            } catch (IOException ignored) { }
            if (scriptFile.exists()) scriptFile.delete();
            synchronized (processLock) {
                if (activeProcess == process) {
                    activeProcess = null;
                    activeProcessInput = null;
                    activeScriptFile = null;
                }
            }
        }

        if (callbackAvailable) {
            try {
                if (streamError != null) callback.onError(streamError);
                callback.onExit(exitCode);
            } catch (RemoteException ignored) {
                // Activity may already have closed.
            }
        }
    }

    @Override
    public void writeInput(String text) throws RemoteException {
        final OutputStream stdin;
        synchronized (processLock) {
            if (activeProcess == null || !isProcessAlive(activeProcess) || activeProcessInput == null) {
                throw new RemoteException("No interactive script is running");
            }
            stdin = activeProcessInput;
        }
        String value = text == null ? "" : text;
        if (!value.endsWith("\n")) value += "\n";
        try {
            stdin.write(value.getBytes(StandardCharsets.UTF_8));
            stdin.flush();
        } catch (IOException e) {
            throw new RemoteException("Unable to send input to the script: " + e.getMessage());
        }
    }

    @Override
    public void closeInput() throws RemoteException {
        synchronized (processLock) {
            if (activeProcessInput != null) {
                try {
                    activeProcessInput.close();
                } catch (IOException e) {
                    throw new RemoteException("Unable to close script input: " + e.getMessage());
                } finally {
                    activeProcessInput = null;
                }
            }
        }
    }

    @Override
    public void abortScript() {
        synchronized (stagingLock) {
            clearStagedScriptLocked();
        }
        Process process;
        synchronized (processLock) {
            process = activeProcess;
            if (activeProcessInput != null) {
                try { activeProcessInput.close(); } catch (IOException ignored) { }
                activeProcessInput = null;
            }
        }
        if (process != null) process.destroy();
    }

    private boolean isProcessAlive(Process process) {
        if (process == null) return false;
        try {
            process.exitValue();
            return false;
        } catch (IllegalThreadStateException stillRunning) {
            return true;
        }
    }

    private void clearStagedScriptLocked() {
        if (stagedScriptOutput != null) {
            try { stagedScriptOutput.close(); } catch (IOException ignored) { }
            stagedScriptOutput = null;
        }
        if (stagedScriptFile != null) {
            stagedScriptFile.delete();
            stagedScriptFile = null;
        }
        expectedScriptBytes = 0;
        writtenScriptBytes = 0;
    }

    @Override
    public void exit() {
        abortScript();
        System.exit(0);
    }

    @Override
    public void destroy() {
        exit();
    }
    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

}
