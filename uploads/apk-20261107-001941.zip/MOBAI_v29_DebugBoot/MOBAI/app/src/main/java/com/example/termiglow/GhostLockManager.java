package com.example.termiglow;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** GhostLock profile loader with a best-effort recursive GitHub cloud update. */
public final class GhostLockManager {
    private static final String TAG = "GhostLock";
    private static final String ASSET_DIR = "kernel_profiles";
    private static final String BIN_NAME = "libGhostlock.so";
    private static final String UPDATE_CONFIG = "cloud-update.conf";
    private static final int MAX_TREE_BYTES = 8 * 1024 * 1024;

    public enum Result { SUCCESS, EXEC_FAILED, NO_PROFILE, NO_BINARY, SHIZUKU_UNAVAILABLE, ERROR }

    public static final class Outcome {
        public final Result result;
        public final String kernelRelease;
        public final String detail;
        public final List<String> availableProfiles;
        public final boolean viaShizuku;
        Outcome(Result r, String kernel, String detail, List<String> profiles, boolean viaShizuku) {
            this.result = r; this.kernelRelease = kernel; this.detail = detail;
            this.availableProfiles = profiles; this.viaShizuku = viaShizuku;
        }
    }

    private final Context context;
    private final boolean useShizuku;
    private final IShellUserService shizukuService;
    private File cacheDir() { return new File(context.getFilesDir(), ASSET_DIR); }

    public GhostLockManager(Context context) { this(context, true, null); }
    public GhostLockManager(Context context, boolean useShizuku, IShellUserService shizukuService) {
        this.context = context.getApplicationContext();
        this.useShizuku = useShizuku;
        this.shizukuService = shizukuService;
    }

    public String getKernelRelease() {
        try {
            Process p = new ProcessBuilder("uname", "-r").redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine(); p.waitFor();
            return line == null ? "" : line.trim();
        } catch (Exception e) { return ""; }
    }

    public List<String> listAvailableProfiles() {
        Set<String> names = new LinkedHashSet<>();
        collectAssetProfiles(ASSET_DIR, names);
        collectCachedProfiles(cacheDir(), "", names);
        return new ArrayList<>(names);
    }

    public Outcome run() {
        String kernel = getKernelRelease();
        if (kernel.isEmpty()) return new Outcome(Result.ERROR, kernel, "無法讀取 uname -r", listAvailableProfiles(), useShizuku);

        String updateNote = updateCloudProfiles();
        File cached = new File(cacheDir(), kernel + ".conf");
        String targetAsset = ASSET_DIR + "/" + kernel + ".conf";
        if (!cached.isFile() && !assetExists(targetAsset)) {
            String detail = "當前內核 " + kernel + " 不在 GhostLock 支援列表";
            if (!updateNote.isEmpty()) detail += "；" + updateNote;
            return new Outcome(Result.NO_PROFILE, kernel, detail, listAvailableProfiles(), useShizuku);
        }
        if (useShizuku) return runViaShizuku(kernel, targetAsset, cached, updateNote);
        return runInProcess(kernel, targetAsset, cached, updateNote);
    }

    private Outcome runViaShizuku(String kernel, String assetPath, File cached, String note) {
        if (shizukuService == null) return new Outcome(Result.SHIZUKU_UNAVAILABLE, kernel, "Shizuku UserService 未連線", listAvailableProfiles(), true);
        try {
            File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
            if (!bin.isFile()) return new Outcome(Result.NO_BINARY, kernel, "nativeLibraryDir 中缺少 " + BIN_NAME, listAvailableProfiles(), true);
            byte[] binBytes = readBytes(new FileInputStream(bin), 16 * 1024 * 1024);
            byte[] profileBytes = cached.isFile() ? readBytes(new FileInputStream(cached), 1024 * 1024) : readAsset(assetPath, 1024 * 1024);
            String raw = shizukuService.runGhostLock(binBytes, profileBytes);
            Result r = raw != null && raw.startsWith("exit=0\n") ? Result.SUCCESS : Result.EXEC_FAILED;
            return new Outcome(r, kernel, appendNote(raw == null ? "" : raw, note), listAvailableProfiles(), true);
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel, appendNote(e.getClass().getSimpleName() + ": " + e.getMessage(), note), listAvailableProfiles(), true);
        }
    }

    private Outcome runInProcess(String kernel, String assetPath, File cached, String note) {
        File bin = new File(context.getApplicationInfo().nativeLibraryDir, BIN_NAME);
        if (!bin.exists() || !bin.canExecute()) return new Outcome(Result.NO_BINARY, kernel, "未找到 " + BIN_NAME, listAvailableProfiles(), false);
        File profileFile = new File(context.getFilesDir(), "gl_" + kernel + ".conf");
        try {
            if (cached.isFile()) copyFile(cached, profileFile); else copyAssetTo(profileFile, assetPath);
            Process proc = new ProcessBuilder(bin.getAbsolutePath(), "--load-prebuilt-profile", profileFile.getAbsolutePath()).redirectErrorStream(true).start();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            int code = proc.waitFor();
            String output = sb.toString().trim();
            return new Outcome(code == 0 ? Result.SUCCESS : Result.EXEC_FAILED, kernel,
                    appendNote(code == 0 ? output : "exit " + code + (output.isEmpty() ? "" : ": " + output), note), listAvailableProfiles(), false);
        } catch (Exception e) {
            return new Outcome(Result.ERROR, kernel, appendNote(e.getClass().getSimpleName() + ": " + e.getMessage(), note), listAvailableProfiles(), false);
        } finally { if (profileFile.exists()) profileFile.delete(); }
    }

    /** Walks the Git tree API, filters .conf blobs, and atomically replaces cached files. */
    private String updateCloudProfiles() {
        try {
            String config = readAssetText(UPDATE_CONFIG, 64 * 1024);
            if (!"true".equalsIgnoreCase(configValue(config, "enabled", "true"))) return "雲端更新已停用";
            String treeApi = configValue(config, "tree_api", "");
            String rawBase = configValue(config, "raw_base", "");
            String directory = configValue(config, "directory", "app/src/main/assets/kernel_profiles");
            int maxFile = parseInt(configValue(config, "max_file_bytes", "1048576"), 1048576);
            int connect = parseInt(configValue(config, "connect_timeout_ms", "15000"), 15000);
            int read = parseInt(configValue(config, "read_timeout_ms", "30000"), 30000);
            if (!treeApi.startsWith("https://api.github.com/") || !rawBase.startsWith("https://raw.githubusercontent.com/")) return "雲端來源網址不安全";
            JSONObject treeJson = new JSONObject(new String(httpGet(treeApi, connect, read, MAX_TREE_BYTES), StandardCharsets.UTF_8));
            JSONArray tree = treeJson.optJSONArray("tree");
            if (tree == null) return "GitHub tree 回應缺少 tree";
            File root = cacheDir(); if (!root.exists() && !root.mkdirs()) return "無法建立 profile 快取目錄";
            int count = 0;
            String prefix = directory.endsWith("/") ? directory : directory + "/";
            for (int i = 0; i < tree.length(); i++) {
                JSONObject item = tree.optJSONObject(i); String path = item == null ? "" : item.optString("path", "");
                if (!"blob".equals(item == null ? "" : item.optString("type")) || !path.startsWith(prefix) || !path.endsWith(".conf")) continue;
                String relative = path.substring(prefix.length());
                if (!isSafeRelativePath(relative)) continue;
                byte[] data = httpGet(rawBase + relative, connect, read, maxFile);
                if (data.length == 0) continue;
                File dest = new File(root, relative); File parent = dest.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) continue;
                File tmp = new File(dest.getPath() + ".tmp");
                try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(data); out.flush(); }
                if (!tmp.renameTo(dest)) { tmp.delete(); continue; }
                count++;
            }
            return "雲端更新完成，共下載 " + count + " 個 .conf";
        } catch (Exception e) {
            Log.w(TAG, "cloud profile update failed", e);
            return "雲端更新失敗，使用內建/上次快取（" + e.getClass().getSimpleName() + "）";
        }
    }

    private static boolean isSafeRelativePath(String path) {
        return !path.isEmpty() && !path.startsWith("/") && !path.contains("\\") && !path.contains("../") && !path.contains("/..") && !path.contains("//");
    }
    private static String configValue(String text, String key, String fallback) {
        Matcher m = Pattern.compile("(?m)\\b" + Pattern.quote(key) + "\\s*=\\s*\\\"([^\\\"]*)\\\"").matcher(text);
        if (m.find()) return m.group(1);
        m = Pattern.compile("(?m)\\b" + Pattern.quote(key) + "\\s*=\\s*([^\\s,}]+)").matcher(text);
        return m.find() ? m.group(1) : fallback;
    }
    private static int parseInt(String value, int fallback) { try { return Integer.parseInt(value); } catch (Exception e) { return fallback; } }
    private static String appendNote(String detail, String note) { return note == null || note.isEmpty() ? detail : detail + "\n[profile] " + note; }

    private byte[] httpGet(String address, int connectTimeout, int readTimeout, int maxBytes) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
        conn.setConnectTimeout(connectTimeout); conn.setReadTimeout(readTimeout); conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("Accept", "application/vnd.github+json"); conn.setRequestProperty("User-Agent", "MOBAI-GhostLock-Profile-Updater/1");
        try {
            int status = conn.getResponseCode(); if (status != 200) throw new IOException("HTTP " + status);
            return readBytes(conn.getInputStream(), maxBytes);
        } finally { conn.disconnect(); }
    }
    private static byte[] readBytes(InputStream in, int maxBytes) throws IOException {
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384]; int n, total = 0;
            while ((n = input.read(buf)) != -1) { total += n; if (total > maxBytes) throw new IOException("response too large"); out.write(buf, 0, n); }
            return out.toByteArray();
        }
    }
    private byte[] readAsset(String path, int maxBytes) throws IOException { return readBytes(context.getAssets().open(path), maxBytes); }
    private String readAssetText(String path, int maxBytes) throws IOException { return new String(readAsset(path, maxBytes), StandardCharsets.UTF_8); }
    private void copyFile(File src, File dest) throws IOException { try (InputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(dest)) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n); } }
    private void copyAssetTo(File dest, String path) throws IOException { try (InputStream in = context.getAssets().open(path); FileOutputStream out = new FileOutputStream(dest)) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n); } }
    private boolean assetExists(String path) { try (InputStream ignored = context.getAssets().open(path)) { return true; } catch (IOException e) { return false; } }

    private void collectAssetProfiles(String dir, Set<String> out) {
        try { String[] list = context.getAssets().list(dir); if (list == null) return; for (String name : list) { String p = dir + "/" + name; if (name.endsWith(".conf")) out.add(name.substring(0, name.length() - 5)); else collectAssetProfiles(p, out); } } catch (IOException ignored) { }
    }
    private void collectCachedProfiles(File dir, String relative, Set<String> out) {
        File[] files = dir.listFiles(); if (files == null) return;
        for (File file : files) { String rel = relative.isEmpty() ? file.getName() : relative + "/" + file.getName(); if (file.isDirectory()) collectCachedProfiles(file, rel, out); else if (file.getName().endsWith(".conf")) out.add(rel.substring(0, rel.length() - 5)); }
    }
}
