package com.example.termiglow;

import com.example.termiglow.IShellOutputCallback;

interface IShellUserService {
    // Reserved transaction used by Shizuku to stop a UserService.
    void destroy() = 16777114;
    void exit() = 1;
    void beginScript(int totalBytes) = 2;
    void writeScriptChunk(in byte[] chunk) = 3;
    void startScript(String input, IShellOutputCallback callback) = 4;
    void abortScript() = 5;
    void writeInput(String text) = 6;
    void closeInput() = 7;
}
