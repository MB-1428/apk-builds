package com.example.termiglow;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    // Light theme palette.
    private static final int BG = Color.rgb(248, 250, 252);
    private static final int PANEL = Color.rgb(241, 245, 249);
    private static final int GREEN = Color.rgb(5, 150, 105);
    private static final int TEXT = Color.rgb(15, 23, 42);
    private static final int MUTED = Color.rgb(100, 116, 139);
    private static final int BORDER = Color.rgb(203, 213, 225);
    private static final int ERROR = Color.rgb(220, 38, 38);

    private EditText inputBox;
    private TextView inputLabel;
    private TextView output;
    private TextView status;
    private Button runButton;
    private ScrollView outputScroll;
    private final AnsiRenderer ansi = new AnsiRenderer();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile long activePtyHandle;
    private volatile boolean scriptRunning = false;
    private static final int SHIZUKU_REQUEST_CODE = 1001;
    private volatile String executionMode = "normal";
    private volatile boolean shizukuPermissionRequestPending = false;
    private volatile boolean rootFallbackStarted = false;
    private volatile boolean rootAvailable = false;
    private volatile boolean userServiceBindInProgress = false;
    private volatile boolean userServiceBound = false;
    private volatile IShellUserService shizukuShellService;
    private volatile CountDownLatch userServiceReady = new CountDownLatch(1);
    private Shizuku.UserServiceArgs userServiceArgs;

    private final IShellOutputCallback shellOutputCallback = new IShellOutputCallback.Stub() {
        @Override
        public void onOutput(String text) {
            appendOutput(text);
        }

        @Override
        public void onExit(int exitCode) {
            runOnUiThread(() -> completeScript(exitCode));
        }

        @Override
        public void onError(String message) {
            appendOutput("\n[stream error] " + message + "\n");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener =
            (requestCode, grantResult) -> {
                if (requestCode != SHIZUKU_REQUEST_CODE) return;
                shizukuPermissionRequestPending = false;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    executionMode = "shizuku";
                    appendOutput("[permission] Shizuku 已授權，正在啟動官方 UserService…\n");
                    updatePrivilegeStatus("SHIZUKU CONNECTING");
                    bindShizukuUserService();
                } else {
                    appendOutput("[permission] Shizuku 權限未授予，改為嘗試 root。\n");
                    requestRootFallback();
                }
            };

    private final Shizuku.OnBinderReceivedListener shizukuBinderListener =
            () -> runOnUiThread(this::checkShizukuPermission);

    private final ServiceConnection userServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            shizukuShellService = IShellUserService.Stub.asInterface(service);
            userServiceBindInProgress = false;
            userServiceBound = true;
            userServiceReady.countDown();
            appendOutput("[permission] Shizuku UserService 已連線。\n");
            updatePrivilegeStatus("SHIZUKU READY");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            shizukuShellService = null;
            userServiceBindInProgress = false;
            userServiceBound = false;
            userServiceReady.countDown();
            appendOutput("[permission] Shizuku UserService 連線中斷。\n");
            updatePrivilegeStatus("SHIZUKU DISCONNECTED");
        }
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        int uiFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);

        buildUi();
        appendOutput("TermiGlow v2.2  •  Native PTY Terminal\n");
        appendOutput("白色主題 · 保留原始 main.sh 與內嵌 ELF。\n");
        appendOutput("啟動時輸入會作為 $1；執行後可在底部輸入列回覆選單。\n");
        appendOutput("即時終端輸出；按「送出輸入」會把文字送進真正的 PTY 終端。\n\n");

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (shizukuShellService != null || shizukuPermissionRequestPending
                    || "shizuku".equals(executionMode)) return;
            if (Shizuku.pingBinder()) {
                checkShizukuPermission();
            } else {
                appendOutput("[permission] 未偵測到 Shizuku 服務，嘗試 root；若沒有 root，會退回一般權限。\n");
                requestRootFallback();
            }
        }, 1500);
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(14), dp(18), dp(10));
        page.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label(">_", 24, GREEN, true);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(Color.WHITE, 14, GREEN, 1));
        header.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(label("TermiGlow", 22, TEXT, true));
        titles.addView(label("BUILT-IN SHELL WORKSPACE", 10, MUTED, true));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(label("● READY", 11, GREEN, true));
        page.addView(header);

        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(18);
        page.addView(label("你的行動終端", 19, TEXT, true), introLp);
        page.addView(label("內置腳本 · 輸入參數 · 即時輸出", 12, MUTED, false));

        LinearLayout outHeader = new LinearLayout(this);
        outHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams outputHeaderLp = new LinearLayout.LayoutParams(-1, -2);
        outputHeaderLp.topMargin = dp(18);
        page.addView(outHeader, outputHeaderLp);
        outHeader.addView(label("TERMINAL OUTPUT", 11, GREEN, true),
                new LinearLayout.LayoutParams(0, -2, 1));
        status = label("● IDLE", 10, MUTED, true);
        outHeader.addView(status);

        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(round(Color.WHITE, 14, BORDER, 1));
        output = label("", 11, Color.rgb(22, 101, 52), false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(14), dp(14), dp(14), dp(14));
        output.setTextIsSelectable(true);
        // Keep terminal lines unwrapped so ASCII art / menus stay aligned; scroll sideways if needed.
        output.setHorizontallyScrolling(true);
        android.widget.HorizontalScrollView hScroll = new android.widget.HorizontalScrollView(this);
        hScroll.setFillViewport(true);
        hScroll.addView(output);
        outputScroll.addView(hScroll);
        LinearLayout.LayoutParams outLp = new LinearLayout.LayoutParams(-1, 0, 1);
        outLp.topMargin = dp(9);
        page.addView(outputScroll, outLp);

        inputLabel = label("COMMAND INPUT · $1", 11, GREEN, true);
        LinearLayout.LayoutParams inputLabelLp = new LinearLayout.LayoutParams(-1, -2);
        inputLabelLp.topMargin = dp(13);
        page.addView(inputLabel, inputLabelLp);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams inputRowLp = new LinearLayout.LayoutParams(-1, -2);
        inputRowLp.topMargin = dp(7);
        page.addView(inputRow, inputRowLp);

        TextView prompt = label("$", 21, GREEN, true);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        prompt.setGravity(Gravity.CENTER);
        inputRow.addView(prompt, new LinearLayout.LayoutParams(dp(30), dp(56)));

        inputBox = new EditText(this);
        inputBox.setTextSize(14);
        inputBox.setSingleLine(false);
        inputBox.setMinLines(1);
        inputBox.setMaxLines(3);
        inputBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        inputBox.setTypeface(Typeface.MONOSPACE);
        inputBox.setTextColor(TEXT);
        inputBox.setHintTextColor(MUTED);
        inputBox.setHint("啟動前作為 $1；執行中輸入選單選項…");
        inputBox.setPadding(dp(13), dp(8), dp(13), dp(8));
        inputBox.setBackground(round(Color.WHITE, 12, BORDER, 1));
        inputRow.addView(inputBox, new LinearLayout.LayoutParams(0, dp(56), 1));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, -2);
        actionsLp.topMargin = dp(9);
        page.addView(actions, actionsLp);
        runButton = actionButton("▶  執行內置腳本", GREEN, Color.WHITE);
        actions.addView(runButton, new LinearLayout.LayoutParams(0, dp(46), 1.25f));
        Button clear = actionButton("清除輸出", PANEL, TEXT);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, dp(46), 1);
        clearLp.leftMargin = dp(9);
        actions.addView(clear, clearLp);

        TextView footer = label("本機執行環境  •  Shizuku / Root 取決於裝置授權", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(9);
        page.addView(footer, footerLp);

        runButton.setOnClickListener(v -> {
            if (scriptRunning) sendInteractiveInput();
            else runBuiltInScript();
        });
        clear.setOnClickListener(v -> { output.setText(""); ansi.reset(); });
        setContentView(page);
    }

    private void runBuiltInScript() {
        if (scriptRunning) {
            sendInteractiveInput();
            return;
        }
        final String input = inputBox.getText().toString();
        runButton.setEnabled(false);
        status.setText("● STARTING");
        status.setTextColor(GREEN);
        appendOutput("\n$ ./main.sh\n");
        appendOutput("[stdin] 啟動參數 $1 = " + (input.isEmpty() ? "(空)" : input) + "\n");

        executor.execute(() -> {
            File localScript = null;
            long localPtyHandle = 0L;
            boolean localPtyWaitCompleted = false;
            try {
                // main.sh contains an ELF payload: keep and transfer its raw bytes.
                byte[] scriptBytes = readBuiltInScriptBytes();
                appendOutput("[script] " + validateSelfExtractingScript(scriptBytes) + "\n");
                if ("shizuku".equals(executionMode)) {
                    IShellUserService service = shizukuShellService;
                    if (service == null) {
                        CountDownLatch latch = userServiceReady;
                        latch.await(10, TimeUnit.SECONDS);
                        service = shizukuShellService;
                    }
                    if (service == null) {
                        throw new IllegalStateException(
                                "Shizuku UserService 尚未連線。請確認 Shizuku 正在執行且已授權，再重試。");
                    }

                    appendOutput("[mode] Shizuku UserService · native PTY\n");
                    service.beginScript(scriptBytes.length);
                    boolean started = false;
                    try {
                        final int chunkSize = 64 * 1024;
                        for (int offset = 0; offset < scriptBytes.length; offset += chunkSize) {
                            int end = Math.min(scriptBytes.length, offset + chunkSize);
                            service.writeScriptChunk(Arrays.copyOfRange(scriptBytes, offset, end));
                        }
                        // Queue the UI state before start: the first output or exit callback
                        // must never be overwritten by a later "running" state update.
                        runOnUiThread(() -> {
                            inputBox.setText("");
                            setInteractiveMode(true);
                        });
                        service.startScript(input, shellOutputCallback);
                        started = true;
                    } finally {
                        if (!started) {
                            try { service.abortScript(); } catch (Exception ignored) { }
                        }
                    }
                    return;
                }

                localScript = new File(getCacheDir(), "main.sh");
                try (FileOutputStream out = new FileOutputStream(localScript)) {
                    out.write(scriptBytes);
                    out.flush();
                }

                appendOutput("[mode] " + ("root".equals(executionMode)
                        ? "root（已由系統 su 授權）" : "Android 一般權限")
                        + " · native PTY\n");
                localPtyHandle = startLocalProcess(localScript, input);
                activePtyHandle = localPtyHandle;
                if ("root".equals(executionMode)) scheduleDiagnostics();
                final long runningHandle = localPtyHandle;
                runOnUiThread(() -> {
                    inputBox.setText("");
                    setInteractiveMode(true);
                });

                // Read bytes from the real PTY. This also flushes terminal prompts
                // that would remain buffered when stdout is connected to a pipe.
                try (InputStream stream = PtyBridge.openInputStream(runningHandle);
                     InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                    char[] buffer = new char[2048];
                    int count;
                    while ((count = reader.read(buffer)) != -1) {
                        if (count > 0) appendOutput(new String(buffer, 0, count));
                    }
                }
                int code = PtyBridge.waitFor(runningHandle);
                localPtyWaitCompleted = true;
                activePtyHandle = 0L;
                runOnUiThread(() -> completeScript(code));
            } catch (Exception e) {
                if (localPtyHandle > 0L && !localPtyWaitCompleted) {
                    PtyBridge.terminate(localPtyHandle);
                    try { PtyBridge.waitFor(localPtyHandle); } catch (Exception ignored) { }
                }
                activePtyHandle = 0L;
                String message = describeError(e);
                runOnUiThread(() -> finishWithError(message));
            } finally {
                if (localScript != null && localScript.exists()) localScript.delete();
            }
        });
    }


    /** Root mode only: ~7s after launch, report whether the overlay process is alive and any crash / SELinux hints. */
    private void scheduleDiagnostics() {
        new Thread(() -> {
            try {
                Thread.sleep(7000);
                String cmd = "echo '-- process'; ps -A 2>/dev/null | grep -E 'imgui|MB.sh|main.sh' | grep -v grep;"
                        + " echo '-- selinux'; getenforce 2>&1;"
                        + " echo '-- runtime dir'; ls -l /data/local/tmp 2>&1 | grep imgui;"
                        + " echo '-- logcat'; logcat -d -v brief -t 600 2>&1"
                        + " | grep -i -E 'imgui|avc: +denied|SurfaceFlinger.*(layer|surface)|Fatal signal|tombstone|vulkan|libgui' | tail -40";
                Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(
                        p.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null && sb.length() < 8000) sb.append(line).append('\n');
                }
                p.destroy();
                appendOutput("\n[diag] ====== 啟動 7 秒後診斷 ======\n" + sb + "[diag] ====== 結束 ======\n");
            } catch (Exception e) {
                appendOutput("\n[diag] 診斷失敗：" + describeError(e) + "\n");
            }
        }, "TermiGlow-Diag").start();
    }

    /** Send one line to a running script instead of starting it again. */
    private void sendInteractiveInput() {
        if (!scriptRunning) return;
        final String line = inputBox.getText().toString();
        try {
            if ("shizuku".equals(executionMode)) {
                IShellUserService service = shizukuShellService;
                if (service == null) throw new IllegalStateException("Shizuku UserService 已斷線。");
                service.writeInput(line);
            } else {
                long handle = activePtyHandle;
                if (handle == 0L) throw new IllegalStateException("目前沒有可接收輸入的 PTY。");
                PtyBridge.writeLine(handle, line);
            }
            // A real PTY supplies normal terminal echo; do not duplicate the line here.
            inputBox.setText("");
            inputBox.requestFocus();
        } catch (Exception e) {
            appendOutput("\n[input error] " + describeError(e) + "\n");
        }
    }

    private void setInteractiveMode(boolean running) {
        scriptRunning = running;
        runButton.setEnabled(true);
        if (running) {
            runButton.setText("↵  送出輸入");
            inputLabel.setText("INTERACTIVE INPUT · PTY");
            inputBox.setHint("輸入選單選項，例如 1，然後按「送出輸入」…");
            status.setText("● RUNNING · INPUT READY");
            status.setTextColor(GREEN);
        } else {
            runButton.setText("▶  執行內置腳本");
            inputLabel.setText("COMMAND INPUT · $1");
            inputBox.setHint("啟動前作為 $1；執行中輸入選單選項…");
        }
    }

    private void completeScript(int exitCode) {
        scriptRunning = false;
        activePtyHandle = 0L;
        appendOutput("\n[process exited: " + exitCode + "]\n");
        updateExitStatus(exitCode);
        setInteractiveMode(false);
    }

    private byte[] readBuiltInScriptBytes() throws Exception {
        try (InputStream in = getAssets().open("main.sh");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    /**
     * main.sh is a self-extracting script with a raw ELF appended to its text header.
     * Check the asset before execution so a packaging/editing mistake is reported clearly.
     * The script bytes are not rewritten or normalized here.
     */
    private String validateSelfExtractingScript(byte[] bytes) {
        if (bytes == null || bytes.length < 64) {
            throw new IllegalStateException("內置 main.sh 太短或讀取失敗。");
        }
        final byte[] elfMagic = new byte[] { 0x7f, 'E', 'L', 'F' };
        int actualOffset = findBytes(bytes, elfMagic);
        if (actualOffset < 0) {
            throw new IllegalStateException("內置 main.sh 找不到 ELF payload；檔案可能被文字編輯器改寫。");
        }
        String header = new String(bytes, 0, actualOffset, StandardCharsets.UTF_8);
        Matcher offsetMatcher = Pattern.compile("(?m)^PAYLOAD_OFFSET=\\$\\(\\(\\s*(\\d+)\\)\\)\\s*$").matcher(header);
        if (!offsetMatcher.find()) {
            throw new IllegalStateException("main.sh 找不到 PAYLOAD_OFFSET 標記；請使用原始檔案。");
        }
        final int declaredOffset;
        try {
            declaredOffset = Integer.parseInt(offsetMatcher.group(1));
        } catch (NumberFormatException e) {
            throw new IllegalStateException("main.sh 的 PAYLOAD_OFFSET 無效。");
        }
        if (declaredOffset != actualOffset) {
            throw new IllegalStateException("main.sh payload offset 不一致：標記=" + declaredOffset
                    + "，實際 ELF=" + actualOffset + "。請確認沒有修改原始 main.sh。");
        }
        if (actualOffset + 20 > bytes.length) {
            throw new IllegalStateException("main.sh 的 ELF payload 不完整。");
        }
        int elfClass = bytes[actualOffset + 4] & 0xff;
        int elfData = bytes[actualOffset + 5] & 0xff;
        int machineLow = bytes[actualOffset + 18] & 0xff;
        int machineHigh = bytes[actualOffset + 19] & 0xff;
        if (elfClass != 2 || elfData != 1 || machineLow != 0xb7 || machineHigh != 0x00) {
            throw new IllegalStateException(String.format(java.util.Locale.ROOT,
                    "內置 ELF 檔頭與腳本預期不符（class=%02x, data=%02x, e_machine=%02x%02x）。",
                    elfClass, elfData, machineHigh, machineLow));
        }
        return "原始 main.sh 位元組載入成功（" + bytes.length + " bytes；ELF offset="
                + actualOffset + "；AArch64）。";
    }

    private int findBytes(byte[] source, byte[] target) {
        if (target.length == 0 || source.length < target.length) return -1;
        outer: for (int i = 0; i <= source.length - target.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (source[i + j] != target[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private long startLocalProcess(File script, String input) throws Exception {
        String scriptCommand = "exec /system/bin/sh " + shellQuote(script.getAbsolutePath())
                + " " + shellQuote(input == null ? "" : input);
        String command = "root".equals(executionMode)
                ? "exec su -c " + shellQuote(scriptCommand)
                : scriptCommand;
        return PtyBridge.start(command, getFilesDir(), 48, 140);
    }

    private void checkShizukuPermission() {
        if (!Shizuku.pingBinder()) return;
        if (shizukuPermissionRequestPending || shizukuShellService != null
                || userServiceBindInProgress || "shizuku".equals(executionMode)) return;
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                executionMode = "shizuku";
                appendOutput("[permission] Shizuku 權限已存在，正在啟動 UserService。\n");
                bindShizukuUserService();
            } else {
                shizukuPermissionRequestPending = true;
                appendOutput("[permission] 正在請求 Shizuku 權限…\n");
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Exception e) {
            shizukuPermissionRequestPending = false;
            appendOutput("[permission] Shizuku 無法使用：" + describeError(e) + "\n");
            requestRootFallback();
        }
    }

    private void bindShizukuUserService() {
        if (shizukuShellService != null || userServiceBindInProgress) return;
        try {
            userServiceBindInProgress = true;
            userServiceReady = new CountDownLatch(1);
            userServiceArgs = new Shizuku.UserServiceArgs(
                    new ComponentName(this, ShellUserService.class))
                    // Shizuku API 13.1.5 requires a non-null process-name suffix.
                    .processNameSuffix("termiglow_shell")
                    .tag("termiglow-shell-user-service")
                    .version(4)
                    .daemon(false);
            Shizuku.bindUserService(userServiceArgs, userServiceConnection);
            appendOutput("[permission] 正在建立 Shizuku UserService…\n");
        } catch (Exception e) {
            userServiceBindInProgress = false;
            userServiceReady.countDown();
            appendOutput("[permission] UserService 啟動失敗：" + describeError(e) + "\n");
            executionMode = rootAvailable ? "root" : "normal";
            requestRootFallback();
        }
    }

    private void requestRootFallback() {
        if (rootFallbackStarted || "shizuku".equals(executionMode)) return;
        rootFallbackStarted = true;
        executor.execute(() -> {
            Process probe = null;
            try {
                probe = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        probe.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line).append('\n');
                }
                int code = probe.waitFor();
                if ("shizuku".equals(executionMode)) return;
                if (code == 0 && result.toString().contains("uid=0")) {
                    rootAvailable = true;
                    executionMode = "root";
                    runOnUiThread(() -> {
                        appendOutput("[permission] 已取得 root 授權。請只執行你信任的內置腳本。\n");
                        updatePrivilegeStatus("ROOT READY");
                    });
                } else {
                    rootAvailable = false;
                    executionMode = "normal";
                    runOnUiThread(() -> {
                        appendOutput("[permission] 未取得 root；將以一般 Android 權限執行。\n");
                        updatePrivilegeStatus("NORMAL MODE");
                    });
                }
            } catch (Exception e) {
                if ("shizuku".equals(executionMode)) return;
                rootAvailable = false;
                executionMode = "normal";
                runOnUiThread(() -> {
                    appendOutput("[permission] 裝置未提供可用的 su/root；使用一般權限。\n");
                    updatePrivilegeStatus("NORMAL MODE");
                });
            } finally {
                if (probe != null) probe.destroy();
            }
        });
    }

    private int extractExitCode(String transcript) {
        Matcher matcher = Pattern.compile("\\[process exited: (-?\\d+)\\]").matcher(transcript);
        int result = Integer.MIN_VALUE;
        while (matcher.find()) {
            try {
                result = Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return Integer.MIN_VALUE;
            }
        }
        return result;
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private String describeError(Throwable error) {
        Throwable deepest = error;
        while (deepest.getCause() != null && deepest.getCause() != deepest) {
            deepest = deepest.getCause();
        }
        String message = deepest.getMessage();
        if (message == null || message.trim().isEmpty()) message = deepest.getClass().getSimpleName();
        return error.getClass().getSimpleName() + ": " + message;
    }

    private void updatePrivilegeStatus(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> updatePrivilegeStatus(text));
            return;
        }
        if (status == null) return;
        status.setText("● " + text);
        status.setTextColor(GREEN);
    }

    private void updateExitStatus(int code) {
        status.setText(code == 0 ? "● SUCCESS" : "● EXIT " + code);
        status.setTextColor(code == 0 ? GREEN : ERROR);
    }

    private void finishWithError(String message) {
        appendOutput("[error] " + message + "\n");
        status.setText("● ERROR");
        status.setTextColor(ERROR);
        setInteractiveMode(false);
        runButton.setEnabled(true);
    }

    private void appendOutput(String text) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> appendOutput(text));
            return;
        }
        output.append(ansi.feed(text));
        CharSequence all = output.getText();
        if (all instanceof android.text.Editable && all.length() > 160000) {
            ((android.text.Editable) all).delete(0, all.length() - 120000);
        }
        if (outputScroll != null) {
            outputScroll.post(() -> outputScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button actionButton(String text, int bg, int fg) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(fg);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(round(bg, 13, bg == GREEN ? GREEN : BORDER, 1));
        return button;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderListener);
        if (userServiceArgs != null && userServiceBound) {
            try {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true);
            } catch (Exception ignored) {
                // Shizuku may already have been stopped while the Activity was closing.
            }
        }
        long handle = activePtyHandle;
        if (handle > 0L) PtyBridge.terminate(handle);
        if (scriptRunning && shizukuShellService != null) {
            try { shizukuShellService.abortScript(); } catch (Exception ignored) { }
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
