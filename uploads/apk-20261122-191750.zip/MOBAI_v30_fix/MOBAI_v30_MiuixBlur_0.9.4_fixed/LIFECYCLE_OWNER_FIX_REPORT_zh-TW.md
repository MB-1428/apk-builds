# MOBAI ViewTreeLifecycleOwner 修復報告

## 修復依據
本次檢查的原始 ZIP 中：
- `MainActivity.java` 原本繼承 `android.app.Activity`。
- `LiquidGlassNavigation.kt` 在 `LiquidGlassNavigationView` 中建立 `ComposeView(context)`，並呼叫 `setContent { ... }`。
- 專案沒有 `FloatingService`、`WindowManager.addView()` 或既有 `ViewTreeLifecycleOwner` 設定。

截圖中的例外為 `ViewTreeLifecycleOwner not found`。因此本次修復針對實際存在的 Activity + ComposeView 主介面，不虛構不存在的懸浮 Service。

## 修改內容
1. `MainActivity.java`
   - 將 `import android.app.Activity` 改為 `import androidx.activity.ComponentActivity`。
   - 將 `MainActivity extends Activity` 改為 `MainActivity extends ComponentActivity`。
2. `app/build.gradle`
   - 加入 `androidx.activity:activity:1.10.1`，提供 `ComponentActivity` 及其 ViewTree LifecycleOwner 整合。

## 為什麼這樣修
`ComponentActivity` 會在 Activity 的 View 樹中提供 LifecycleOwner。當 `ComposeView` 附加到 Activity 的視圖樹時，Compose 可沿 View tree 找到 LifecycleOwner，不再因缺少該 owner 而觸發截圖中的例外。

## 未修改項目
- 沒有修改 `LiquidGlassNavigation.kt` 的 UI、動畫、點擊或 Miuix Blur 邏輯。
- 沒有刪除或改動既有功能。
- 沒有新增不存在的 FloatingService。
- 沒有更動 AndroidManifest、ABI、Native/CMake 或原有 Shizuku/PTY 程式碼。

## 驗證狀態
- ZIP 結構及修改檔案已檢查。
- 尚未在 Android SDK/NDK + Gradle 環境中執行完整 APK 編譯，也未在實機驗證。
- 請以此 ZIP 編譯安裝後，確認原本的崩潰是否消失。若仍出現相同錯誤，請提供新的完整 stack trace。
