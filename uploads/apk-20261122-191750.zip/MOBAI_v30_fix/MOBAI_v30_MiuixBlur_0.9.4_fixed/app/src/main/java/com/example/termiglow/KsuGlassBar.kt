package com.example.termiglow

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sign

/*
 * KernelSU-style floating glass bottom bar.
 *
 * Behaviour follows KernelSU manager's FloatingBottomBar (design / interaction reference only,
 * written independently on top of Kyant0's Apache-2.0 "backdrop" library):
 *   1. a capsule that refracts the page behind it (vibrancy + 4dp blur + lens),
 *   2. pressing anywhere grows the capsule and a "droplet" indicator, which follows the finger,
 *   3. while pressed the droplet refracts a 1.2x accent-coloured copy of the tabs,
 *   4. the droplet squashes / stretches with its velocity, the capsule rubber-bands on drag.
 *
 * Requires Android 13+ for the lens shader; MainActivity only enables this on API 33+.
 * The Compose view must be larger than the capsule by [marginDp] on every side so the lens can
 * sample the page just outside the capsule edge; GlassLayout snapshots that whole area.
 */

private val GlassAccent = Color(0xFF248A3D)       // iOS green, readable on light glass
private val GlassLabel = Color(0xFF3A3F47)
private val GlassContainer = Color(0xFFF2F2F7).copy(alpha = 0.40f)
private val GlassTint = Color(0xFF34C759)

@Composable
internal fun KsuGlassBar(
    selectedIndex: Int,
    pagerPosition: Float?,
    backdropBitmap: ImageBitmap?,
    marginDp: Dp,
    onSelect: (Int) -> Unit
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val count = navItems.size
    val last = (count - 1).toFloat()

    // The page snapshot (from GlassLayout) is the "background" every glass layer refracts.
    val backdrop = rememberLayerBackdrop {
        drawRect(Color(0xFFF2F4F8))
        drawContent()
    }
    val tabsBackdrop = rememberLayerBackdrop()
    val combinedBackdrop = rememberCombinedBackdrop(backdrop, tabsBackdrop)

    val position = remember { Animatable(selectedIndex.toFloat()) }   // fractional tab index
    val press = remember { Animatable(0f) }                           // 0..1 press progress
    val dragOffset = remember { Animatable(0f) }                      // rubber band, px
    var dragging by remember { mutableStateOf(false) }
    var currentIndex by remember { mutableIntStateOf(selectedIndex) }
    var highlightX by remember { mutableFloatStateOf(0f) }
    val onSelectState = rememberUpdatedState(onSelect)

    val settleSpec = remember { spring<Float>(dampingRatio = 0.55f, stiffness = 300f, visibilityThreshold = 0.001f) }
    val pressSpec = remember { spring<Float>(dampingRatio = 0.5f, stiffness = 300f, visibilityThreshold = 0.001f) }
    val bandSpec = remember { spring<Float>(dampingRatio = 1f, stiffness = 300f, visibilityThreshold = 0.5f) }

    LaunchedEffect(selectedIndex) {
        currentIndex = selectedIndex
        if (!dragging && pagerPosition == null) position.animateTo(selectedIndex.toFloat(), settleSpec)
    }
    // Host page swipe: follow the pager while it is being dragged, settle on release.
    LaunchedEffect(pagerPosition) {
        if (dragging) return@LaunchedEffect
        val p = pagerPosition
        if (p != null) position.snapTo(p.coerceIn(0f, last))
        else position.animateTo(selectedIndex.toFloat(), settleSpec)
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
            if (backdropBitmap != null) {
                Image(
                    bitmap = backdropBitmap,
                    contentDescription = null,
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        BoxWithConstraints(
            modifier = Modifier.fillMaxSize().padding(horizontal = marginDp),
            contentAlignment = Alignment.Center
        ) {
            val totalWidthPx = with(density) { maxWidth.toPx() }
            val padPx = with(density) { 4.dp.toPx() }
            val rubberPx = with(density) { 4.dp.toPx() }
            val tabWidthPx = ((totalWidthPx - 2 * padPx) / count).coerceAtLeast(0f)
            val tabWidthDp = with(density) { tabWidthPx.toDp() }
            val tabWidthState = rememberUpdatedState(tabWidthPx)

            fun panelOffsetPx(): Float {
                if (totalWidthPx == 0f) return 0f
                val f = (dragOffset.value / totalWidthPx).coerceIn(-1f, 1f)
                return rubberPx * f.sign * EaseOut.transform(abs(f))
            }

            fun indexAt(x: Float): Int {
                val w = tabWidthState.value
                if (w <= 0f) return currentIndex
                return ((x - padPx) / w).toInt().coerceIn(0, count - 1)
            }

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                // 1) The capsule: refracts the page and hosts the real tabs.
                Row(
                    modifier = Modifier
                        .offset { IntOffset(panelOffsetPx().roundToInt(), 0) }
                        .shadow(
                            elevation = 12.dp,
                            shape = CircleShape,
                            clip = false,
                            ambientColor = Color.Black.copy(alpha = 0.10f),
                            spotColor = Color.Black.copy(alpha = 0.14f)
                        )
                        .drawBackdrop(
                            backdrop = backdrop,
                            shape = { CircleShape },
                            effects = {
                                vibrancy()
                                blur(4.dp.toPx())
                                lens(24.dp.toPx(), 24.dp.toPx())
                            },
                            layerBlock = {
                                val w = size.width.coerceAtLeast(1f)
                                val s = lerp(1f, 1f + 16.dp.toPx() / w, press.value)
                                scaleX = s
                                scaleY = s
                            },
                            onDrawSurface = {
                                drawRect(GlassContainer)
                                val p = press.value
                                if (p > 0.01f) {
                                    // Light that follows the finger (stand-in for KSU's interactive highlight).
                                    drawRect(
                                        Brush.radialGradient(
                                            colors = listOf(Color.White.copy(alpha = 0.30f * p), Color.Transparent),
                                            center = Offset(highlightX, size.height / 2f),
                                            radius = size.height * 1.3f
                                        )
                                    )
                                }
                            }
                        )
                        .border(
                            width = 0.75.dp,
                            brush = Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.90f),
                                    Color.White.copy(alpha = 0.15f),
                                    Color.White.copy(alpha = 0.55f)
                                )
                            ),
                            shape = CircleShape
                        )
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                val tabW = tabWidthState.value
                                var target = indexAt(down.position.x).toFloat()
                                dragging = true
                                highlightX = down.position.x
                                scope.launch { press.animateTo(1f, pressSpec) }
                                val startTarget = target
                                scope.launch { position.animateTo(startTarget, settleSpec) }

                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == down.id }
                                    if (change == null || !change.pressed) break
                                    val dx = change.position.x - change.previousPosition.x
                                    highlightX = change.position.x
                                    if (dx != 0f && tabW > 0f) {
                                        change.consume()
                                        target = (target + dx / tabW).coerceIn(0f, last)
                                        val t = target
                                        scope.launch { position.snapTo(t) }
                                        scope.launch { dragOffset.snapTo(dragOffset.value + dx) }
                                    }
                                }

                                // Released (or cancelled): settle on the nearest tab.
                                dragging = false
                                val idx = target.roundToInt().coerceIn(0, count - 1)
                                scope.launch { press.animateTo(0f, pressSpec) }
                                scope.launch { position.animateTo(idx.toFloat(), settleSpec) }
                                scope.launch { dragOffset.animateTo(0f, bandSpec) }
                                if (idx != currentIndex) {
                                    currentIndex = idx
                                    onSelectState.value(idx)
                                }
                            }
                        }
                        .fillMaxWidth()
                        .height(64.dp)
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    navItems.forEachIndexed { index, item ->
                        GlassTab(
                            item = item,
                            selected = index == selectedIndex,
                            color = GlassLabel,
                            scale = { 1f },
                            onClick = {
                                if (currentIndex != index) {
                                    currentIndex = index
                                    onSelectState.value(index)
                                }
                                scope.launch { position.animateTo(index.toFloat(), settleSpec) }
                            }
                        )
                    }
                }

                // 2) Invisible accent-coloured copy of the capsule. It is only recorded into
                //    tabsBackdrop so the droplet can refract magnified, green tabs.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clearAndSetSemantics {}
                        .alpha(0f)
                        .layerBackdrop(tabsBackdrop)
                        .offset { IntOffset(panelOffsetPx().roundToInt(), 0) }
                        .drawBackdrop(
                            backdrop = backdrop,
                            shape = { CircleShape },
                            effects = {
                                vibrancy()
                                blur(4.dp.toPx())
                                lens(24.dp.toPx(), 24.dp.toPx())
                            },
                            onDrawSurface = { drawRect(GlassContainer) }
                        )
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    navItems.forEachIndexed { index, item ->
                        GlassTab(
                            item = item,
                            selected = index == selectedIndex,
                            color = GlassAccent,
                            scale = { lerp(1f, 1.2f, press.value) },
                            onClick = {}
                        )
                    }
                }

                // 3) The droplet indicator.
                if (tabWidthPx > 0f) {
                    Box(
                        Modifier
                            .padding(horizontal = 4.dp)
                            .offset {
                                IntOffset((position.value * tabWidthPx + panelOffsetPx()).roundToInt(), 0)
                            }
                            .drawBackdrop(
                                backdrop = combinedBackdrop,
                                shape = { CircleShape },
                                effects = {
                                    val p = press.value
                                    lens(
                                        refractionHeight = 10.dp.toPx() * p,
                                        refractionAmount = 14.dp.toPx() * p,
                                        depthEffect = true,
                                        chromaticAberration = true
                                    )
                                },
                                layerBlock = {
                                    val p = press.value
                                    val s = lerp(1f, 78f / 56f, p)
                                    val v = position.velocity / last.coerceAtLeast(1f) / 10f
                                    scaleX = s / (1f - (v * 0.75f).coerceIn(-0.2f, 0.2f))
                                    scaleY = s * (1f - (v * 0.25f).coerceIn(-0.2f, 0.2f))
                                },
                                onDrawSurface = {
                                    val p = press.value
                                    drawRect(GlassTint.copy(alpha = 0.16f * (1f - p)))
                                    drawRect(Color.Black.copy(alpha = 0.03f * p))
                                }
                            )
                            .height(56.dp)
                            .width(tabWidthDp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.GlassTab(
    item: NavItem,
    selected: Boolean,
    color: Color,
    scale: () -> Float,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .semantics(mergeDescendants = true) {
                contentDescription = item.description
                this.selected = selected
                role = Role.Tab
                onClick {
                    onClick()
                    true
                }
            }
            .fillMaxHeight()
            .weight(1f)
            .graphicsLayer {
                val s = scale()
                scaleX = s
                scaleY = s
            },
        verticalArrangement = Arrangement.spacedBy(1.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BasicText(
            text = item.glyph,
            style = TextStyle(
                color = color,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
        )
        BasicText(
            text = item.title,
            style = TextStyle(
                color = color,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        )
    }
}
