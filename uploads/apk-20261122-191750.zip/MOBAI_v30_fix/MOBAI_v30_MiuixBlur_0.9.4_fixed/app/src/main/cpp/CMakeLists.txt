cmake_minimum_required(VERSION 3.22.1)
project(termiglowpty C)

add_library(termiglowpty SHARED pty_bridge.c)
find_library(log-lib log)
target_link_libraries(termiglowpty ${log-lib})
target_compile_options(termiglowpty PRIVATE -Wall -Wextra -Werror=return-type)
